// T3 参考暴力（对拍基准）：严格按定义 —— t1 = x + s1_i + z 且 t2 = x + s2_i + z
#include <bits/stdc++.h>
using namespace std;
int main() {
    int n, q;
    if (scanf("%d %d", &n, &q) != 2) return 0;
    vector<string> s1(n), s2(n);
    static char buf[5000006];
    for (int i = 0; i < n; i++) {
        scanf("%s", buf); s1[i] = buf;
        scanf("%s", buf); s2[i] = buf;
    }
    while (q--) {
        scanf("%s", buf); string t1 = buf;
        scanf("%s", buf); string t2 = buf;
        long long ans = 0;
        if (t1.size() == t2.size()) {
            int L1 = (int)t1.size();
            // 两串不同的“最小包围区间” [lo, hi]
            int lo = -1, hi = -1;
            for (int i = 0; i < L1; i++) if (t1[i] != t2[i]) { if (lo < 0) lo = i; hi = i; }
            if (lo >= 0) {
                for (int i = 0; i < n; i++) {
                    int L = (int)s1[i].size();
                    for (int p = 0; p + L <= L1; p++) {
                        if (p > lo || p + L - 1 < hi) continue;      // 窗口必须盖住差异区
                        if (t1.compare(p, L, s1[i]) == 0 && t2.compare(p, L, s2[i]) == 0) ans++;
                    }
                }
            }
        }
        printf("%lld\n", ans);
    }
    return 0;
}
