// CSP-S 2025 T3 谐音替换 (replace) —— 档1：暴力 (预期 25 分, 测试点 1~5)
// 定义：答案 = #{(i, p) : t1 = x + s1_i + z 且 t2 = x + s2_i + z}
// 等价条件（设 [lo,hi] 为 t1,t2 第一个/最后一个不同位置）：
//   (1) 窗口 [p, p+L-1] 覆盖 [lo,hi]，即 p <= lo 且 p+L-1 >= hi；
//   (2) t1[p..p+L-1] = s1_i；(3) t2[p..p+L-1] = s2_i。
// 复杂度 O(n * L2)，n 和 L2 都在 1e3~2e3 量级时可过。
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
const ull B = 131;
static char b1[5000006], b2[5000006];
static ull h1[5000006], h2[5000006], pw[5000006];

int main() {
    int n, q;
    scanf("%d %d", &n, &q);
    vector<int> len(n);
    vector<ull> H1(n), H2(n);
    for (int i = 0; i < n; i++) {
        scanf("%s %s", b1, b2);
        int m = (int)strlen(b1);
        len[i] = m;
        ull x = 0, y = 0;
        for (int j = 0; j < m; j++) { x = x * B + (ull)(b1[j] - 'a' + 1); y = y * B + (ull)(b2[j] - 'a' + 1); }
        H1[i] = x; H2[i] = y;
    }
    pw[0] = 1;
    for (int i = 1; i < 5000006; i++) pw[i] = pw[i - 1] * B;
    for (int qi = 0; qi < q; qi++) {
        scanf("%s %s", b1, b2);
        int L1 = (int)strlen(b1), L2 = (int)strlen(b2);
        long long ans = 0;
        if (L1 == L2) {
            h1[0] = 0; for (int j = 0; j < L1; j++) h1[j + 1] = h1[j] * B + (ull)(b1[j] - 'a' + 1);
            h2[0] = 0; for (int j = 0; j < L2; j++) h2[j + 1] = h2[j] * B + (ull)(b2[j] - 'a' + 1);
            int lo = -1, hi = -1;
            for (int j = 0; j < L1; j++) if (b1[j] != b2[j]) { if (lo < 0) lo = j; hi = j; }
            if (lo >= 0) {
                for (int i = 0; i < n; i++) {
                    int L = len[i];
                    int pmin = max(0, hi - L + 1), pmax = min(lo, L1 - L);
                    for (int p = pmin; p <= pmax; p++) {
                        if (h1[p + L] - h1[p] * pw[L] == H1[i] && h2[p + L] - h2[p] * pw[L] == H2[i]) ans++;
                    }
                }
            }
        }
        printf("%lld\n", ans);
    }
    return 0;
}
