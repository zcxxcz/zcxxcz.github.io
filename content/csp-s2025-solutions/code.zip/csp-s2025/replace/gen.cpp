// T3 对拍数据生成器 ./gen <mode> <seed>
// mode 0: 字母表 {a,b}          mode 1: 字母表 {a,b,c}
// mode 2: 全小写字母            mode 3: 特殊性质 B (特别串: 只有 a/b 且 b 恰好一次)
// mode 4: q = 1 (特殊性质 A)    mode 5: 全小写且强制 q=1
#include <bits/stdc++.h>
using namespace std;
int A;                                   // 字母表大小
mt19937 rng;
string rndStr(int lo, int hi) {
    int len = rng() % (hi - lo + 1) + lo;
    string s;
    for (int i = 0; i < len; i++) s += char('a' + rng() % A);
    return s;
}
string specialStr(int lo, int hi) {      // a^x b a^y, b 恰好一次
    int len = rng() % (hi - lo + 1) + lo;
    if (len < 1) len = 1;
    int pos = rng() % len;
    string s(len, 'a');
    s[pos] = 'b';
    return s;
}
int main(int argc, char** argv) {
    int mode = atoi(argv[1]);
    rng.seed((unsigned)atoi(argv[2]));
    bool special = (mode == 3);
    A = (mode == 0 || mode == 3) ? 2 : (mode == 1 ? 3 : 26);
    int n = rng() % 6 + 1;
    int q = (mode == 4 || mode == 5) ? 1 : (int)(rng() % 4 + 1);
    vector<string> s1(n), s2(n);
    for (int i = 0; i < n; i++) {
        int len = rng() % 4 + 1;
        if (special) { s1[i] = specialStr(len, len); s2[i] = specialStr(len, len); }
        else {
            s1[i] = rndStr(len, len);
            s2[i].resize(len);
            for (int j = 0; j < len; j++) s2[i][j] = char('a' + rng() % A);
        }
    }
    printf("%d %d\n", n, q);
    for (int i = 0; i < n; i++) printf("%s %s\n", s1[i].c_str(), s2[i].c_str());
    for (int j = 0; j < q; j++) {
        string t1, t2;
        if (rng() % 2 == 0) {
            // 由某条规则“构造”出来，保证有非零答案
            int i = rng() % n;
            int pre = rng() % 4, suf = rng() % 4;
            string P, S;
            if (special) { P = string(pre, 'a'); S = string(suf, 'a'); }
            else { P = rndStr(pre, pre); S = rndStr(suf, suf); }
            if (special && s1[i].find('b') != string::npos) {
                // P/S 全为 a, 保证整体仍然恰好一个 b
            }
            t1 = P + s1[i] + S;
            t2 = P + s2[i] + S;
        }
        if (t1.empty() || t1 == t2) {              // 退化为随机，重试直到两串不同
            int guard = 0;
            do {
                int len = rng() % 6 + 2;
                if (special) { t1 = specialStr(len, len); t2 = specialStr(len, len); }
                else { t1 = rndStr(len, len); t2 = rndStr(len, len); }
            } while (t1 == t2 && ++guard < 50);
            if (t1 == t2) t2[0] = (t2[0] == 'a' ? 'b' : 'a');
        }
        printf("%s %s\n", t1.c_str(), t2.c_str());
    }
    return 0;
}
