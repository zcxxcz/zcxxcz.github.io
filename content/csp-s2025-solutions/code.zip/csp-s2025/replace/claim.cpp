// 用于验证「正解的分组判据」是否等价于定义：
// 把规则拆成 (A,B,C)->(A,D,C)（A=最长公共前缀,B/D 中间,C=最长公共后缀），
// 把询问拆成 AA+Bq+CC / AA+Dq+CC。判据：B==Bq 且 D==Dq 且 A 是 AA 的后缀 且 C 是 CC 的前缀。
#include <bits/stdc++.h>
using namespace std;
int lcp(const string& a, const string& b) { int i = 0; while (i < (int)a.size() && a[i] == b[i]) i++; return i; }
int main() {
    int n, q; scanf("%d %d", &n, &q);
    vector<string> s1(n), s2(n);
    static char buf[5000006];
    for (int i = 0; i < n; i++) { scanf("%s", buf); s1[i] = buf; scanf("%s", buf); s2[i] = buf; }
    while (q--) {
        scanf("%s", buf); string t1 = buf;
        scanf("%s", buf); string t2 = buf;
        long long ans = 0;
        if (t1.size() == t2.size()) {
            int L1 = (int)t1.size(), lo = -1, hi = -1;
            for (int i = 0; i < L1; i++) if (t1[i] != t2[i]) { if (lo < 0) lo = i; hi = i; }
            if (lo >= 0) {
                string Bq = t1.substr(lo, hi - lo + 1), Dq = t2.substr(lo, hi - lo + 1);
                string AA = t1.substr(0, lo), CC = t1.substr(hi + 1);
                for (int i = 0; i < n; i++) {
                    int len = (int)s1[i].size();
                    int a = lcp(s1[i], s2[i]);
                    if (a == len) continue;                       // s1 == s2，无贡献
                    int b = lcp(string(s1[i].rbegin(), s1[i].rend()), string(s2[i].rbegin(), s2[i].rend()));
                    string B = s1[i].substr(a, len - a - b), D = s2[i].substr(a, len - a - b);
                    string A = s1[i].substr(0, a), C = s1[i].substr(len - b);
                    if (B != Bq || D != Dq) continue;
                    if (A.size() > AA.size() || AA.compare(AA.size() - A.size(), A.size(), A) != 0) continue;
                    if (C.size() > CC.size() || CC.compare(0, C.size(), C) != 0) continue;
                    ans++;
                }
            }
        }
        printf("%lld\n", ans);
    }
    return 0;
}
