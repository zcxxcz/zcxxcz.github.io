// CSP-S 2025 T3 谐音替换 (replace) —— 正解  O(L1 + L2 + (n+q) log)
// ---------------------------------------------------------------------------
// 关键转化（用定义 t1 = x + s1_i + z, t2 = x + s2_i + z 推出）
//  规则 i : s1 = A + B + C,  s2 = A + D + C   (A=最长公共前缀, C=最长公共后缀, B/D=中间段)
//  询问 j : t1 = AA + BQ + CC, t2 = AA + DQ + CC  (同样取最长公共前后缀)
//  规则 i 对询问 j 恰好贡献 1 条，当且仅当
//      B == BQ  且  D == DQ  且  A 是 AA 的后缀  且  C 是 CC 的前缀
//  （替换位置被两端唯一夹定，所以匹配的规则至多贡献 1。）
// ---------------------------------------------------------------------------
// 计数：按 (B,D) 分组。组内要数 #{ i : A_i 是 AA 的后缀, C_i 是 CC 的前缀 }。
//  · A 是 AA 的后缀 <=> rev(A) 是 rev(AA) 的前缀
//  · C 是 CC 的前缀 <=> C 是 CC 的前缀
// 两者都是「前缀」关系 —— 在 Trie 上就是「结点的祖先关系」：
//  记 nodeA(x)=x 在 TrieA 中走到的结点（走不动就停在最深处，根 = 空串）。
//  要数的是 #{ i : nodeA(revA_i) 是 nodeA(revAA_j) 的祖先 且 nodeC(C_i) 是 nodeC(CC_j) 的祖先 }。
// 经典技巧：在 TrieA 上 DFS，进入结点 u 时把「nodeA=u 的规则 i」在 TrieC 上做
//  区间加 [tinC(C_i), toutC(C_i)] += 1，离开时撤销；到询问所在结点时，BIT 里恰好是
//  「nodeA 是祖先」的那些规则，单点查 tinC(nodeC(CC_j)) 得到的就是
//  「nodeC(C_i) 是它的祖先」的个数。区间加 + 单点查用差分 BIT。
#include <bits/stdc++.h>
using namespace std;

/* ---------------- 快速输入 ---------------- */
static char ibuf[1 << 25];
static size_t ipos = 0, ilen = 0;
static inline int gc() { if (ipos == ilen) { ilen = fread(ibuf, 1, sizeof(ibuf), stdin); ipos = 0; if (!ilen) return -1; } return ibuf[ipos++]; }
static inline void readStr(string& s) {
    s.clear(); int c = gc();
    while (c != -1 && (c == ' ' || c == '\n' || c == '\r' || c == '\t')) c = gc();
    while (c != -1 && c != ' ' && c != '\n' && c != '\r' && c != '\t') { s.push_back((char)c); c = gc(); }
}
static inline int readInt() { int c = gc(); while (c < '0' || c > '9') c = gc(); int x = 0; while (c >= '0' && c <= '9') { x = x * 10 + c - '0'; c = gc(); } return x; }

/* ---------------- Trie（前向星孩子） ---------------- */
struct Trie {
    vector<int> head, nxt, to; vector<unsigned char> ch; int cnt = 0;
    void reset() { head.clear(); nxt.clear(); to.clear(); ch.clear(); cnt = 0; newNode(); }
    inline int newNode() { head.push_back(-1); return cnt++; }
    inline int getChild(int u, int c) {
        for (int e = head[u]; e != -1; e = nxt[e]) if (ch[e] == (unsigned char)c) return to[e];
        int v = newNode(); ch.push_back((unsigned char)c); to.push_back(v); nxt.push_back(head[u]); head[u] = (int)to.size() - 1; return v;
    }
    inline int findChild(int u, int c) {
        for (int e = head[u]; e != -1; e = nxt[e]) if (ch[e] == (unsigned char)c) return to[e];
        return -1;
    }
    inline int walk(const string& s) { int u = 0; for (char c : s) { int v = findChild(u, c); if (v == -1) break; u = v; } return u; }
};

/* ---------------- 差分 BIT：区间加 + 单点查 ---------------- */
static vector<long long> bitv; static int bitn = 0;
static inline void bitUpd(int i, long long v) { for (++i; i <= bitn; i += i & (-i)) bitv[i] += v; }
static inline void rangeAdd(int l, int r, long long v) { bitUpd(l, v); if (r + 1 < bitn) bitUpd(r + 1, -v); }
static inline long long pointGet(int i) { long long s = 0; for (++i; i > 0; i -= i & (-i)) s += bitv[i]; return s; }

/* ---------------- 迭代 DFS 求 tin / tout ---------------- */
static void euler(Trie& T, vector<int>& tin, vector<int>& tout) {
    int N = T.cnt; tin.assign(N, 0); tout.assign(N, 0);
    vector<int> stN, stE; int timer = 0;
    stN.push_back(0); tin[0] = timer++;
    stE.push_back(T.head[0]);
    while (!stN.empty()) {
        int u = stN.back(); int& e = stE.back();
        if (e == -1) { tout[u] = timer - 1; stN.pop_back(); stE.pop_back(); continue; }
        int v = T.to[e]; e = T.nxt[e];
        tin[v] = timer++;
        stN.push_back(v); stE.push_back(T.head[v]);
    }
}

int main() {
    int n = readInt(), q = readInt();
    unordered_map<string, int> gmap;
    gmap.reserve((size_t)n * 2 + 10);
    vector<string> ruleA, ruleC;                     // rev(A) 与 C
    vector<vector<int>> gRules, gQueries;

    string s1, s2;
    for (int i = 0; i < n; i++) {
        readStr(s1); readStr(s2);
        int len = (int)s1.size();
        int a = 0; while (a < len && s1[a] == s2[a]) a++;
        if (a == len) continue;                      // s1 == s2 不产生贡献
        int b = 0; while (b < len - a && s1[len - 1 - b] == s2[len - 1 - b]) b++;
        int blen = len - a - b;
        string key; key.reserve(2 * blen + 1);
        key.append(s1, a, blen); key.push_back('#'); key.append(s2, a, blen);
        auto it = gmap.find(key);
        int gid;
        if (it == gmap.end()) { gid = (int)gRules.size(); gmap.emplace(std::move(key), gid); gRules.push_back({}); gQueries.push_back({}); }
        else gid = it->second;
        string revA(s1.begin(), s1.begin() + a); reverse(revA.begin(), revA.end());
        string C(s1.begin() + len - b, s1.end());
        gRules[gid].push_back((int)ruleA.size());
        ruleA.push_back(std::move(revA));
        ruleC.push_back(std::move(C));
    }

    vector<int> qgid(q, -1), qNodeA(q, 0), qNodeC(q, 0);
    vector<string> qRevAA(q), qCC(q);
    for (int j = 0; j < q; j++) {
        readStr(s1); readStr(s2);
        if (s1.size() != s2.size()) continue;
        int L = (int)s1.size(), lo = -1, hi = -1;
        for (int t = 0; t < L; t++) if (s1[t] != s2[t]) { if (lo < 0) lo = t; hi = t; }
        if (lo < 0) continue;                        // t1 == t2
        string key; key.reserve(2 * (hi - lo + 1) + 1);
        key.append(s1, lo, hi - lo + 1); key.push_back('#'); key.append(s2, lo, hi - lo + 1);
        auto it = gmap.find(key);
        if (it == gmap.end()) continue;              // 该分组不存在 => 答案 0
        qgid[j] = it->second;
        gQueries[it->second].push_back(j);
        string revAA(s1.begin(), s1.begin() + lo); reverse(revAA.begin(), revAA.end());
        qRevAA[j] = std::move(revAA);
        qCC[j] = s1.substr(hi + 1);
    }

    vector<long long> ans(q, 0);
    Trie TA, TC;
    vector<int> tinA, toutA, tinC, toutC;
    vector<int> atA, nxtA, valA, atC, nxtC, valC;
    vector<int> qAtA, qNxtA, qValA;
    vector<int> nodeCof(ruleA.size(), 0);

    for (int g = 0; g < (int)gRules.size(); g++) {
        if (gQueries[g].empty()) continue;
        int m = (int)gRules[g].size();
        (void)m;
        /* ---------- 建 TrieA（rev(A)） ---------- */
        TA.reset();
        atA.assign(1, -1); nxtA.clear(); valA.clear();
        for (int id : gRules[g]) {
            int u = 0;
            for (char c : ruleA[id]) { u = TA.getChild(u, c); if ((int)atA.size() < TA.cnt) atA.resize(TA.cnt, -1); }
            if ((int)atA.size() < TA.cnt) atA.resize(TA.cnt, -1);
            valA.push_back(id); nxtA.push_back(atA[u]); atA[u] = (int)valA.size() - 1;
        }
        atA.resize(TA.cnt, -1);
        euler(TA, tinA, toutA);
        /* ---------- 建 TrieC（C） ---------- */
        TC.reset();
        atC.assign(1, -1); nxtC.clear(); valC.clear();
        for (int id : gRules[g]) {
            int u = 0;
            for (char c : ruleC[id]) { u = TC.getChild(u, c); if ((int)atC.size() < TC.cnt) atC.resize(TC.cnt, -1); }
            if ((int)atC.size() < TC.cnt) atC.resize(TC.cnt, -1);
            nodeCof[id] = u;
            valC.push_back(id); nxtC.push_back(atC[u]); atC[u] = (int)valC.size() - 1;
        }
        atC.resize(TC.cnt, -1);
        euler(TC, tinC, toutC);
        /* ---------- 询问各自走到的最深结点 ---------- */
        qAtA.assign(TA.cnt, -1); qNxtA.clear(); qValA.clear();
        for (int j : gQueries[g]) {
            qNodeA[j] = TA.walk(qRevAA[j]);
            qNodeC[j] = TC.walk(qCC[j]);
            qValA.push_back(j); qNxtA.push_back(qAtA[qNodeA[j]]); qAtA[qNodeA[j]] = (int)qValA.size() - 1;
        }
        /* ---------- TrieA 上 DFS + BIT ---------- */
        bitn = TC.cnt; bitv.assign(bitn + 1, 0);
        vector<int> stN, stE;
        // 进入结点 u：加上 nodeA=u 的规则（在 TrieC 上做子树区间加），再回答挂在 u 上的询问
        auto enterNode = [&](int u) {
            for (int e = atA[u]; e != -1; e = nxtA[e]) { int id = valA[e]; rangeAdd(tinC[nodeCof[id]], toutC[nodeCof[id]], +1); }
            for (int e = qAtA[u]; e != -1; e = qNxtA[e]) { int j = qValA[e]; ans[j] = pointGet(tinC[qNodeC[j]]); }
        };
        auto leaveNode = [&](int u) {
            for (int e = atA[u]; e != -1; e = nxtA[e]) { int id = valA[e]; rangeAdd(tinC[nodeCof[id]], toutC[nodeCof[id]], -1); }
        };
        enterNode(0);
        stN.push_back(0); stE.push_back(TA.head[0]);
        while (!stN.empty()) {
            int u = stN.back(); int& e = stE.back();
            if (e == -1) { leaveNode(u); stN.pop_back(); stE.pop_back(); continue; }
            int v = TA.to[e]; e = TA.nxt[e];
            stN.push_back(v); stE.push_back(TA.head[v]);
            enterNode(v);
        }
    }
    string out;
    for (int j = 0; j < q; j++) { out += to_string(ans[j]); out.push_back('\n'); }
    fwrite(out.data(), 1, out.size(), stdout);
    return 0;
}
