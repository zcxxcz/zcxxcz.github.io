CSP-S 2025 提高级 四题：从部分分到 AC —— 配套代码包
=====================================================

配套详解页面：https://zcxxcz.github.io/content/csp-s2025-solutions/

本包内容
--------
四题从部分分到满分的全部 23 份完整代码（按题目分目录）+ 本说明。

官方大样例（club 1~5、road 1~4、replace 1~4、employ 1~5）体积较大
（解压后约 54 MB，其中 road2/road3 各约 17 MB），未打包在内；
可在 NOI 官网 CSP-S 2025 第二轮页面下载试题与数据：
https://www.noi.cn/

编译环境
--------
所有代码在 g++ 15 下用 -O2 -std=c++14 编译并实测通过。
CCF 评测机使用 -O2 -std=c++14 -static，提交时请在 main 开头加：

    freopen("club.in", "r", stdin);      // 换成对应题目的文件名
    freopen("club.out", "w", stdout);

源文件不得超过 100 KiB。所有代码只使用 stdin/stdout。
计时用 /usr/bin/time -l，取 real 与 maximum resident set size。

本地自测
--------
    g++ -O2 -std=c++14 club/std.cpp -o club_std
    ./club_std < club1.in
    diff <(./club_std < club1.in) club1.ans

没有官方数据时，可以直接用每题的 gen.cpp 生成随机数据来自测或对拍：

    g++ -O2 -std=c++14 road/gen.cpp -o road_gen
    ./road_gen <mode> <seed> > road_big.in
    ./road_std < road_big.in > a.out
    ./road_brute_prim < road_big.in > b.out
    diff a.out b.out

目录结构
--------
club/       T1 社团招新（20 点 × 5 分）
road/       T2 道路修复（25 点 × 4 分）
replace/    T3 谐音替换（20 点 × 5 分）
employ/     T4 员工招聘（25 点 × 4 分）

每一题的档位对照
----------------

【club  社团招新】后悔贪心
  brute_dp.cpp      O(n^3) 暴力 DP —— 测试点 1~11，55 分，n <= 200
  subA.cpp          特殊性质 A（a[i][2]=a[i][3]=0）—— 测试点 12，累计 60 分
  subB.cpp          特殊性质 B（a[i][3]=0）—— 测试点 9,13,14，累计 70 分
  std.cpp           正解：后悔贪心 O(n log n) —— 100 分
  gen.cpp           数据生成器（小值域 / 中值域 / 性质 A / 性质 B / 满值域）
  要点：三个部门人数之和恒为 n，所以最多只有一个部门会超过 n/2。
        先全放部门 3，再把 (a[i][1]-a[i][2]) 最大的若干个挪到部门 2；
        若某部门超限，就用该部门里「后悔代价」loss[i] = best[i] - second[i]
        最小的若干个，把超出的名额退回去。

【road  道路修复】MST + 2^k 枚举
  level1_k0.cpp         只读原图跑 Kruskal —— 测试点 1~4，16 分
  level2_sort_each.cpp  2^k 枚举，每个集合重新排序 —— 测试点 1~8，32 分
  level3_presort.cpp    全边一次性预排序 + 跳过未改造乡镇 —— 所有 k<=5 的点，累计 64 分
  std.cpp               正解：原图只留 MST 的 n-1 条树边 + 城乡边一次性排序
                        + 2^k 线性扫描 —— 100 分
  brute_prim.cpp        独立暴力（邻接矩阵 + Prim + 2^k 枚举），用于对拍
  gen.cpp               数据生成器（含性质 A）
  要点：① 每个乡镇改造对环上所有边都有加成，但 MST 里只有 n-1 条有用的边；
        ② 2^k 枚举集合后排序序与集合无关（c_j 只按顺序累加），可以一次性排序；
        ③ 未改造乡镇的城乡边直接跳过。

【replace  谐音替换】两棵 Trie + 差分 BIT
  brute_naive.cpp   按定义暴力：先求 t1/t2 第一个、最后一个不同位置 [lo,hi]，
                    窗口必须盖住 [lo,hi]，再逐 (i,p) 用 string 比较
                    —— 测试点 1,2，10 分
  level1_hash.cpp   哈希暴力 —— 测试点 1~8、13,14，累计 50 分
  claim.cpp         验证「分组判据」与定义等价
                    （模式 (B,D) 相等 且 A 是 AA 后缀 且 C 是 CC 前缀）
  std.cpp           正解：拆 s = A+B+C / A+D+C，按 B#D 分组；
                    把「A 是 AA 后缀」转成 rev(A) 是 rev(AA) 前缀（TrieA 的祖先关系），
                    「C 是 CC 前缀」用 TrieC 的子树区间；
                    TrieA 上 DFS，进入结点时对相关规则在 TrieC 做区间加，离开时 -1，
                    询问即 TrieC 上的单点查 —— 100 分
  gen.cpp           数据生成器（含性质 B 的特别串、q=1 两种）
  易错点：窗口必须盖住 [lo,hi]。漏掉「窗口外 t1/t2 必须相同」会错 —— 官方样例 1 会输出 3 而不是 2。

【employ  员工招聘】容斥 + 贡献延后 DP
  brute_perm.cpp    O(n!·n) 全排列模拟 —— 测试点 1,2，8 分
  bitmask.cpp       状压 DP（dp[day][bad][mask]）—— 测试点 3~5，累计 20 分
  m1.cpp            m=1 专用公式 —— 测试点 12~14
  mn.cpp            m=n 专用公式 —— 测试点 15
  propA.cpp         特殊性质 A（所有 s_i=1）—— 测试点 6~8、16,17
  propB.cpp         特殊性质 B（sum s_i <= 18）—— 测试点 18~21
  std.cpp           正解：f[j][k] 表示「未录用 j 人、已确定 k 个上限位」，
                    s_i=1 时三条转移，其中 -(d_j-k) 一项来自容斥；
                    答案 sum_j sum_k f[j][k] * (n-k)!，其中 j <= n-m —— 100 分
  要点：容斥的关键恒等式
        (n-k)! - (n-k-1)!·(d_j-k) = (n-k-1)!·(n-d_j)，
        右式的 n-d_j 正是「c > j 的人数」，也就是录用位真正可选的人数。

验证方式
--------
每档程序都做了三层验证：
  ① 官方大样例逐字节比对；
  ② 与自己写的暴力/低档程序随机对拍（含小值域、特殊性质、边界值三套生成器，
     总计 1000+ 组随机数据）；
  ③ 最大规模计时与内存实测（club n=1e5 0.05s/8.8MB；road n=1e4,m=1e6,k=5 0.29s；
     replace n=1e5,q=5e4 0.06s；employ n=500 最坏 0.09s/8.9MB）。

对拍脚本（check.py / check2.py）含本机绝对路径，未打包在内。
