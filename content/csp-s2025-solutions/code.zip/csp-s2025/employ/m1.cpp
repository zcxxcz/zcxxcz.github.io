// CSP-S 2025 T4 employ —— 档位3：m=1 专用（测试点 12~14，n<=500, m=1）
// 思路：答案 = n! - (一个人都没录用的方案数)
//   "一个人都没录用" 等价于：每一天来的人都成为"未录用"（被拒或放弃），即第 i 天之前未录用数恒为 i-1。
//   - s_i = 0：该天的人必然未录用，对 c 无限制；
//   - s_i = 1：该天的人必须"放弃"，即要求 c <= i-1。
//   记 S = "1" 的个数，把 s_i=1 的天按 i 升序记为 i_1<...<i_S。
//   先给这些受约束的位置选人：第 t 个位置可选 #{c<=i_t-1} - (t-1) 人；
//   剩下 n-S 个（全是 s=0）位置自由排剩余的人，乘 (n-S)!。
//   本文件只在 m=1 时正确。
#include <bits/stdc++.h>
using namespace std;
const int MOD = 998244353;
int n, m;
char s[505];
int cnt[505], d[505];
long long fac[505];

int main() {
    scanf("%d %d", &n, &m);
    scanf("%s", s + 1);
    for (int i = 1; i <= n; i++) { int x; scanf("%d", &x); cnt[x]++; }
    for (int i = 0; i <= n; i++) d[i] = (i ? d[i - 1] : 0) + cnt[i];   // d[i]=#{c<=i}
    // d[-1] 视为 0：用 d[i-1] 时 i>=1，i=1 时 d[0]=cnt[0]，注意这里表示 #{c<=i-1}=d[i-1]
    fac[0] = 1;
    for (int i = 1; i <= n; i++) fac[i] = fac[i - 1] * i % MOD;

    int S = 0;
    for (int i = 1; i <= n; i++) if (s[i] == '1') S++;

    long long zero = 1;     // 0 人录用的方案数
    int t = 0;
    for (int i = 1; i <= n; i++) {
        if (s[i] != '1') continue;
        t++;
        long long avail = (i - 1 >= 0 ? d[i - 1] : 0) - (t - 1);   // #{c <= i-1} 中还没用的
        if (avail <= 0) { zero = 0; break; }
        zero = zero * (avail % MOD) % MOD;
    }
    zero = zero * fac[n - S] % MOD;

    long long ans = (fac[n] - zero) % MOD;
    if (ans < 0) ans += MOD;
    printf("%lld\n", ans);
    return 0;
}
