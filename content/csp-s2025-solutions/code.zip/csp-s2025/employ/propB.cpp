// CSP-S 2025 T4 employ —— 档位4：特殊性质 B 专版（测试点 18~21；n<=500 且 sum s_i <= 18）
// 关键剪枝：录用只可能发生在 s_i = 1 的天上，所以"录用人数 <= S = #s_i=1"。
//   - 若 m > S，直接输出 0；
//   - 同时"未录用人数 j >= n - S"，答案求和的下标从 n-S 起。
// 其余完全复用正解 DP。
#include <bits/stdc++.h>
using namespace std;
const int MOD = 998244353;
const int N = 505;
int n, m;
char s[N];
int cnt[N], d[N];
int f[N][N], g[N][N];
long long fac[N];

int main() {
    scanf("%d %d", &n, &m);
    scanf("%s", s + 1);
    int S = 0;
    for (int i = 1; i <= n; i++) if (s[i] == '1') S++;
    for (int i = 1; i <= n; i++) { int x; scanf("%d", &x); cnt[x]++; }

    if (m > S) { printf("0\n"); return 0; }      // 录用数上界就是 S

    d[0] = cnt[0];
    for (int i = 1; i <= n; i++) d[i] = d[i - 1] + cnt[i];
    fac[0] = 1;
    for (int i = 1; i <= n; i++) fac[i] = fac[i - 1] * i % MOD;

    f[0][0] = 1;
    for (int i = 1; i <= n; i++) {
        memset(g, 0, sizeof(g));
        for (int j = 0; j <= n; j++)
            for (int k = 0; k <= n; k++) {
                int cur = f[j][k];
                if (!cur) continue;
                if (s[i] == '0') {
                    int &to = g[j + 1][k];
                    to += cur; if (to >= MOD) to -= MOD;
                } else {
                    int avail = d[j] - k; if (avail < 0) avail = 0;
                    long long w = (long long)cur * avail % MOD;
                    int &a1 = g[j + 1][k + 1]; a1 += (int)w; if (a1 >= MOD) a1 -= MOD;
                    int &a2 = g[j][k];         a2 += cur;   if (a2 >= MOD) a2 -= MOD;
                    int &a3 = g[j][k + 1];     a3 -= (int)w; if (a3 < 0) a3 += MOD;
                }
            }
        memcpy(f, g, sizeof(f));
    }
    long long ans = 0;
    int jlo = max(0, n - S);                 // 未录用人数至少 n-S
    for (int j = jlo; j <= n - m; j++)
        for (int k = 0; k <= n; k++)
            ans = (ans + (long long)f[j][k] * fac[n - k]) % MOD;
    printf("%lld\n", ans);
    return 0;
}
