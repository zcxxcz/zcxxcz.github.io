// CSP-S 2025 T4 employ —— 档位4：m=n 专用（测试点 15，n<=500, m=n）
// 思路：要录用全部 n 人，必须每一天都成功录用。
//   - 只要有某个 s_i = 0，第 i 天的人必然被拒 -> 不可能，答案 0；
//   - 于是 s 全为 1；此时只要所有 c_i >= 1，就永远不会有人放弃
//     （未录用数恒为 0 < c_i，每个人都参加面试且做出题），全部 n! 种排列都合法；
//   - 若存在 c_i = 0，该人轮到时"未录用数 0 >= 0"必然放弃 -> 答案 0。
// 结论：answer = n!  当且仅当 (s 全为 '1' 且 min c_i >= 1)，否则 0。
#include <bits/stdc++.h>
using namespace std;
const int MOD = 998244353;
int main() {
    int n, m;
    static char s[505];
    scanf("%d %d", &n, &m);
    scanf("%s", s + 1);
    int mnc = INT_MAX;
    for (int i = 1; i <= n; i++) { int x; scanf("%d", &x); mnc = min(mnc, x); }
    bool ok = (mnc >= 1);
    for (int i = 1; i <= n; i++) if (s[i] != '1') ok = false;
    long long ans = 0;
    if (ok) {
        ans = 1;
        for (int i = 1; i <= n; i++) ans = ans * i % MOD;
    }
    printf("%lld\n", ans);
    return 0;
}
