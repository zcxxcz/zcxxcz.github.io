// CSP-S 2025 T4 employ —— 档位3：特殊性质 A 专版（测试点 6~8、16,17；所有 s_i = 1）
// 说明：性质 A 不需要新算法，正解 DP 在 s 全为 1 时只剩"录用/不录用"三个转移。
//       本文件即把 std 中 s=0 的分支删去的版本（仅当 s 全为 1 时保证正确）。
#include <bits/stdc++.h>
using namespace std;
const int MOD = 998244353;
const int N = 505;
int n, m;
char s[N];
int cnt[N], d[N];
int f[N][N], g[N][N];
long long fac[N];

int main() {
    scanf("%d %d", &n, &m);
    scanf("%s", s + 1);
    for (int i = 1; i <= n; i++) { int x; scanf("%d", &x); cnt[x]++; }
    d[0] = cnt[0];
    for (int i = 1; i <= n; i++) d[i] = d[i - 1] + cnt[i];
    fac[0] = 1;
    for (int i = 1; i <= n; i++) fac[i] = fac[i - 1] * i % MOD;

    f[0][0] = 1;
    for (int i = 1; i <= n; i++) {          // s[i] 恒为 '1'
        memset(g, 0, sizeof(g));
        for (int j = 0; j <= n; j++)
            for (int k = 0; k <= n; k++) {
                int cur = f[j][k];
                if (!cur) continue;
                int avail = d[j] - k; if (avail < 0) avail = 0;
                long long w = (long long)cur * avail % MOD;
                int &a1 = g[j + 1][k + 1]; a1 += (int)w; if (a1 >= MOD) a1 -= MOD;   // 不录用：真上限
                int &a2 = g[j][k];         a2 += cur;   if (a2 >= MOD) a2 -= MOD;   // 录用，不钦定
                int &a3 = g[j][k + 1];     a3 -= (int)w; if (a3 < 0) a3 += MOD;     // 录用但钦定违反
            }
        memcpy(f, g, sizeof(f));
    }
    long long ans = 0;
    for (int j = 0; j <= n - m; j++)
        for (int k = 0; k <= n; k++)
            ans = (ans + (long long)f[j][k] * fac[n - k]) % MOD;
    printf("%lld\n", ans);
    return 0;
}
