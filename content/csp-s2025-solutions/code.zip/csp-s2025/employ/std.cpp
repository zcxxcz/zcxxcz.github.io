// CSP-S 2025 T4 employ —— 档位5：正解（容斥 + 贡献延后 DP）
// 覆盖全部测试点 1~25  n<=500  100 分
// 复杂度 O(n^3)，内存 O(n^2)
//
// 思路：
//   设 a_i 表示第 i 天的人是否被录用，b_i 表示前 i-1 天里"未录用(被拒/放弃)"的人数。
//   第 i 天的人耐心为 c 时：
//     s_i=0              -> 必不录用                    （对 c 无限制）
//     s_i=1 且不录用      -> 放弃，要求 c <= b_i        （上限约束）
//     s_i=1 且录用        -> 参加并录用，要求 c > b_i   （下限约束）
//   "只有上限"的排列计数：把每个位置的上限排成非降序列 up_1..up_n，
//    方案数 = prod (cnt_{up_t} - (t-1))，cnt_x = 人数中 c<=x 的个数。
//   下限用容斥去掉：钦定某些"录用"位违反下限（改成上限 c<=b_i），系数 -1。
//   DP: f[j][k] = 处理到当前位置，b=j（未录用 j 人），已确定 k 个"上限位"（含真上限与钦定违反的）方案数。
//     s_i=0 : f[j+1][k]   += f[j][k]
//     s_i=1 : f[j+1][k+1] += f[j][k] * (cnt_j - k)      // 不录用（真上限 c<=j）
//             f[j  ][k  ] += f[j][k]                    // 录用，且不钦定（下限留到末尾一起算）
//             f[j  ][k+1] -= f[j][k] * (cnt_j - k)      // 录用但钦定违反下限（容斥，负号）
//   答案 = sum_{j=0}^{n-m} sum_k f[j][k] * (n-k)!
//   其中 (n-k)! 是给"没有上限约束的 n-k 个位置"自由分配剩余人的方案数（把它们的上限视作 n）。
#include <bits/stdc++.h>
using namespace std;
const int MOD = 998244353;
const int N = 505;

int n, m;
char s[N];
int cnt[N], d[N];
int f[N][N], g[N][N];
long long fac[N];

int main() {
    scanf("%d %d", &n, &m);
    scanf("%s", s + 1);
    for (int i = 1; i <= n; i++) { int x; scanf("%d", &x); cnt[x]++; }
    d[0] = cnt[0];
    for (int i = 1; i <= n; i++) d[i] = d[i - 1] + cnt[i];   // d[i] = #{c<=i}

    fac[0] = 1;
    for (int i = 1; i <= n; i++) fac[i] = fac[i - 1] * i % MOD;

    f[0][0] = 1;
    for (int i = 1; i <= n; i++) {
        memset(g, 0, sizeof(g));
        for (int j = 0; j <= n; j++)
            for (int k = 0; k <= n; k++) {
                int cur = f[j][k];
                if (!cur) continue;
                if (s[i] == '0') {
                    int &to = g[j + 1][k];
                    to += cur; if (to >= MOD) to -= MOD;
                } else {
                    int avail = d[j] - k;
                    if (avail < 0) avail = 0;
                    long long w = (long long)cur * avail % MOD;   // 真正可选的 c<=j 的人数
                    // 1) 不录用：真上限，系数 +1
                    int &a1 = g[j + 1][k + 1];
                    a1 += (int)w; if (a1 >= MOD) a1 -= MOD;
                    // 2) 录用且不钦定：无约束
                    int &a2 = g[j][k];
                    a2 += cur; if (a2 >= MOD) a2 -= MOD;
                    // 3) 录用但钦定"违反下限"（等于强行给它一个上限 c<=j），系数 -1
                    int &a3 = g[j][k + 1];
                    a3 -= (int)w; if (a3 < 0) a3 += MOD;
                }
            }
        memcpy(f, g, sizeof(f));
    }

    long long ans = 0;
    for (int j = 0; j <= n - m; j++)
        for (int k = 0; k <= n; k++)
            ans = (ans + (long long)f[j][k] * fac[n - k]) % MOD;
    printf("%lld\n", ans);
    return 0;
}
