// CSP-S 2025 T4 employ —— 档位1：全排列暴力
// 覆盖测试点 1,2 (n<=10)  预期 8 分
// 复杂度 O(n! * n)
#include <bits/stdc++.h>
using namespace std;
int n, m;
char s[32];
int c[32];
int main() {
    scanf("%d %d", &n, &m);
    scanf("%s", s + 1);
    for (int i = 1; i <= n; i++) scanf("%d", &c[i]);

    vector<int> p(n);
    iota(p.begin(), p.end(), 1);   // p[j] = 第 j+1 天来面试的人
    long long ans = 0;
    do {
        int bad = 0, hire = 0;
        for (int i = 1; i <= n; i++) {
            int u = p[i - 1];
            if (bad >= c[u]) {
                // 之前已有 >= c_u 人被拒绝或放弃 -> 他放弃
                bad++;
            } else if (s[i] == '0') {
                // 参加但做不出题 -> 被拒绝
                bad++;
            } else {
                // 做出题 -> 录用
                hire++;
            }
        }
        if (hire >= m) ans++;
    } while (next_permutation(p.begin(), p.end()));

    printf("%lld\n", ans);
    return 0;
}
