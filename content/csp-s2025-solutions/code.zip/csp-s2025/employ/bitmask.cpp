// CSP-S 2025 T4 employ —— 档位2：状压 DP
// 覆盖测试点 3~5 (n<=18)  累计 20 分
// dp[mask][h] : 已面试集合 mask，其中录用 h 人
//   由 mask 可得已过天数 i=popcount(mask)，未录用(=被拒/放弃)人数 bad = popcount(mask)-h
// 复杂度 O(2^n * n^2)，内存 O(2^n * n)
#include <bits/stdc++.h>
using namespace std;
const int MOD = 998244353;
int n, m;
char s[32];
int c[32];

int main() {
    scanf("%d %d", &n, &m);
    scanf("%s", s + 1);
    for (int i = 1; i <= n; i++) scanf("%d", &c[i]);

    int full = 1 << n;
    vector<int> dp((size_t)full * (n + 1), 0);
    auto at = [&](int mask, int h) -> int& { return dp[(size_t)mask * (n + 1) + h]; };
    at(0, 0) = 1;

    for (int mask = 0; mask < full; mask++) {
        int pc = __builtin_popcount(mask);
        int day = pc + 1;                 // 下一天
        if (day > n) continue;
        char sd = s[day];
        for (int h = 0; h <= pc; h++) {
            int cur = dp[(size_t)mask * (n + 1) + h];
            if (!cur) continue;
            int bad = pc - h;
            for (int u = 1; u <= n; u++) {
                if (mask >> (u - 1) & 1) continue;
                int nh;
                if (bad >= c[u]) nh = h;          // 放弃
                else if (sd == '0') nh = h;       // 参加但被拒
                else nh = h + 1;                  // 录用
                int &to = dp[(size_t)(mask | (1 << (u - 1))) * (n + 1) + nh];
                to += cur;
                if (to >= MOD) to -= MOD;
            }
        }
    }

    long long ans = 0;
    for (int h = m; h <= n; h++) ans += at(full - 1, h);
    printf("%lld\n", ans % MOD);
    return 0;
}
