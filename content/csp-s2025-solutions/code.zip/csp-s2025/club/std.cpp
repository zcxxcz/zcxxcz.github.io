// CSP-S 2025 T1 社团招新 (club) —— 正解：反悔贪心  O(n log n)
// 适用：全部测试点，100 分
//
// 引理1：按“每人先去自己最满意的部门”得到的三个部门人数 c1,c2,c3，
//        至多只有一个部门 > n/2（因为三者之和为 n）。
// 引理2：若部门 d 超载 e = c_d - n/2 人，只需从“最满意为 d”的人中挑 e 个改去自己的次优部门，
//        且一定不会让别的部门再次超载（因为另两部门的前缀和 <= n/2 - c_others）。
// 引理3：为了让损失最小，按 (最优值 - 次优值) 升序取前 e 个。
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
    int T; scanf("%d", &T);
    while (T--) {
        int n; scanf("%d", &n);
        int half = n / 2;
        long long base = 0;
        int cnt[3] = {0, 0, 0};
        vector<ll> loss[3];
        for (int i = 1; i <= n; i++) {
            ll a[3];
            scanf("%lld %lld %lld", &a[0], &a[1], &a[2]);
            int mx = 0;                            // 满意度最高的部门
            if (a[1] > a[mx]) mx = 1;
            if (a[2] > a[mx]) mx = 2;
            ll second = 0;                         // 其余两个部门中的较大值
            for (int j = 0; j < 3; j++)
                if (j != mx) second = max(second, a[j]);
            base += a[mx];
            cnt[mx]++;
            loss[mx].push_back(a[mx] - second);    // 改去次优部门的损失
        }
        for (int d = 0; d < 3; d++) {
            if (cnt[d] > half) {
                sort(loss[d].begin(), loss[d].end());
                int need = cnt[d] - half;
                for (int i = 0; i < need; i++) base -= loss[d][i];
            }
        }
        printf("%lld\n", base);
    }
    return 0;
}
