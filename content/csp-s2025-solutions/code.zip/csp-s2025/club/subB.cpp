// CSP-S 2025 T1 社团招新 (club) —— 档3：特殊性质 B (a[i][3]=0)
// 适用：测试点 13,14，累计 70 分
// 结论：a[i][3]=0 时最优解里 n 个人必然全被分完（部门1、2 各恰好 n/2 人）。
//       答案 = sum a[i][2] + (a[i][1]-a[i][2]) 中最大的 n/2 个之和。
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
    int T; scanf("%d", &T);
    while (T--) {
        int n; scanf("%d", &n);
        int half = n / 2;
        vector<ll> d;
        ll base = 0;
        for (int i = 1; i <= n; i++) {
            ll a, b, c; scanf("%lld %lld %lld", &a, &b, &c);
            base += b;                     // 先假设所有人都去部门2
            d.push_back(a - b);            // 改成去部门1 的“增量”
        }
        sort(d.begin(), d.end(), greater<ll>());
        for (int i = 0; i < half; i++) base += d[i];
        printf("%lld\n", base);
    }
    return 0;
}
