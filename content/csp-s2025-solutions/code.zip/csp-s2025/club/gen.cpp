// T1 对拍数据生成器
// 用法: ./gen <mode> <seed>
//   mode 0 = 一般数据(小值域, 制造大量并列)
//   mode 1 = 一般数据(中等值域)
//   mode 2 = 特殊性质 A (a2=a3=0)
//   mode 3 = 特殊性质 B (a3=0)
//   mode 4 = 一般数据(满值域 0..20000)
#include <bits/stdc++.h>
using namespace std;
int main(int argc, char** argv) {
    int mode = atoi(argv[1]);
    unsigned seed = (unsigned)atoi(argv[2]);
    mt19937 rng(seed);
    int T = rng() % 3 + 1;
    printf("%d\n", T);
    for (int t = 0; t < T; t++) {
        int n = (rng() % 6 + 1) * 2;          // 2..12
        printf("%d\n", n);
        int V;
        switch (mode) {
            case 0: V = 3; break;
            case 1: V = 10; break;
            case 2: V = 10; break;
            case 3: V = 10; break;
            default: V = 20000; break;
        }
        for (int i = 0; i < n; i++) {
            int a, b, c;
            if (mode == 2) { b = 0; c = 0; a = rng() % (V + 1); }
            else if (mode == 3) { c = 0; a = rng() % (V + 1); b = rng() % (V + 1); }
            else { a = rng() % (V + 1); b = rng() % (V + 1); c = rng() % (V + 1); }
            printf("%d %d %d\n", a, b, c);
        }
    }
    return 0;
}
