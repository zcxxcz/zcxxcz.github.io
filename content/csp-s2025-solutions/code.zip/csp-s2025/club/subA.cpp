// CSP-S 2025 T1 社团招新 (club) —— 档2：特殊性质 A (a[i][2]=a[i][3]=0)
// 适用：测试点 12，累计 60 分
// 结论：只有部门1有分，把 a[i][1] 最大的 n/2 个人放进部门1，其余随便丢（贡献 0）。
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
    int T; scanf("%d", &T);
    while (T--) {
        int n; scanf("%d", &n);
        int half = n / 2;
        vector<ll> v;
        for (int i = 1; i <= n; i++) {
            ll a, b, c; scanf("%lld %lld %lld", &a, &b, &c);
            v.push_back(a);                 // 只用第一列
        }
        sort(v.begin(), v.end(), greater<ll>());
        ll ans = 0;
        for (int i = 0; i < half; i++) ans += v[i];
        printf("%lld\n", ans);
    }
    return 0;
}
