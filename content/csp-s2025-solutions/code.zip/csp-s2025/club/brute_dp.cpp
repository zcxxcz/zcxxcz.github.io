// CSP-S 2025 T1 社团招新 (club) —— 档1：O(n^3) 暴力 DP
// 适用：测试点 1~11（n<=30 及 n=200），共 55 分
// 编译：g++-15 -O2 -std=c++14 club.cpp -o club
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll NEG = LLONG_MIN / 4;

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    while (T--) {
        int n; scanf("%d", &n);
        int half = n / 2;
        // dp[j][k]：已处理若干人，其中 j 人在部门1、k 人在部门2（其余在部门3）
        static ll dp[2][205][205];
        for (int j = 0; j <= half; j++)
            for (int k = 0; k <= half; k++) dp[0][j][k] = NEG;
        dp[0][0][0] = 0;
        int cur = 0;
        for (int i = 1; i <= n; i++) {
            ll a[3]; scanf("%lld %lld %lld", &a[0], &a[1], &a[2]);
            for (int j = 0; j <= half; j++)
                for (int k = 0; k <= half; k++) dp[cur ^ 1][j][k] = NEG;
            for (int j = 0; j <= half; j++)
                for (int k = 0; k <= half; k++) {
                    ll v = dp[cur][j][k];
                    if (v == NEG) continue;
                    int l = (i - 1) - j - k;          // 部门3人数
                    if (l < 0 || l > half) continue;
                    if (j + 1 <= half) dp[cur ^ 1][j + 1][k] = max(dp[cur ^ 1][j + 1][k], v + a[0]);
                    if (k + 1 <= half) dp[cur ^ 1][j][k + 1] = max(dp[cur ^ 1][j][k + 1], v + a[1]);
                    if (l + 1 <= half) dp[cur ^ 1][j][k]     = max(dp[cur ^ 1][j][k],     v + a[2]);
                }
            cur ^= 1;
        }
        ll ans = 0;
        for (int j = 0; j <= half; j++)
            for (int k = 0; k <= half; k++) {
                int l = n - j - k;
                if (l < 0 || l > half) continue;
                if (dp[cur][j][k] != NEG) ans = max(ans, dp[cur][j][k]);
            }
        printf("%lld\n", ans);
    }
    return 0;
}
