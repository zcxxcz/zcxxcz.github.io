// CSP-S 2025 T2 道路修复 (road) —— 正解 (100 分)
// 关键两步：
//   1) 原图先跑一遍 Kruskal，只保留 n-1 条树边：任何一条非树边在任何改造方案下都不会被选中。
//   2) 把这 n-1 条树边 + 所有 k*n 条城乡边一次性排序，枚举 2^k 个改造集合时只做线性扫描，
//      跳过“没被改造的乡镇”所对应的边。
// 复杂度 O(m log m + (nk) log(nk) + 2^k * (n + k) * α)
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct Edge { int u, v, w, town; };   // town=0 表示城市边, 否则为 1..k

static inline int rd() {
    int x = 0; char c = getchar();
    while (c < '0' || c > '9') c = getchar();
    while (c >= '0' && c <= '9') { x = x * 10 + (c - '0'); c = getchar(); }
    return x;
}

int n, m, k;
vector<Edge> base;
vector<int> c;                       // 改造费用
int fa[10015];
int find(int x) { while (fa[x] != x) { fa[x] = fa[fa[x]]; x = fa[x]; } return x; }

int main() {
    n = rd(); m = rd(); k = rd();
    vector<Edge> orig(m);
    for (int i = 0; i < m; i++) {
        int u = rd(), v = rd(), w = rd();
        orig[i] = {u, v, w, 0};
    }
    // ---- 第 1 步：原图 Kruskal，只留树边 ----
    sort(orig.begin(), orig.end(), [](const Edge& a, const Edge& b) { return a.w < b.w; });
    for (int i = 1; i <= n; i++) fa[i] = i;
    base.reserve(n - 1 + (size_t)k * n);
    for (const Edge& e : orig) {
        int u = find(e.u), v = find(e.v);
        if (u != v) { fa[u] = v; base.push_back(e); }
    }
    // ---- 读入乡镇, 生成城乡边 ----
    c.assign(k + 1, 0);
    for (int j = 1; j <= k; j++) {
        c[j] = rd();
        for (int i = 1; i <= n; i++) base.push_back({n + j, i, rd(), j});
    }
    // ---- 第 2 步：一次性排序 ----
    sort(base.begin(), base.end(), [](const Edge& a, const Edge& b) { return a.w < b.w; });

    ll ans = LLONG_MAX;
    for (int mask = 0; mask < (1 << k); mask++) {
        for (int i = 1; i <= n + k; i++) fa[i] = i;
        ll cost = 0;
        for (int j = 1; j <= k; j++) if (mask >> (j - 1) & 1) cost += c[j];
        if (cost >= ans) continue;                    // 小剪枝
        for (const Edge& e : base) {
            if (e.town && !(mask >> (e.town - 1) & 1)) continue;
            int u = find(e.u), v = find(e.v);
            if (u != v) { fa[u] = v; cost += e.w; }
        }
        if (cost < ans) ans = cost;
    }
    printf("%lld\n", ans);
    return 0;
}
