// CSP-S 2025 T2 道路修复 (road) —— 档1 (预期 16 分, 测试点 1~4: k=0)
// 只有原图 m 条边, 直接跑一遍 Kruskal 输出即可。
// 注意：k>0 时它忽略乡镇, 答案会偏大 —— 这正是它只有 16 分的原因。
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
static inline int rd() {
    int x = 0; char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    while (ch >= '0' && ch <= '9') { x = x * 10 + (ch - '0'); ch = getchar(); }
    return x;
}
struct Edge { int u, v, w; };
int fa[10015];
int find(int x) { return fa[x] == x ? x : fa[x] = find(fa[x]); }
int main() {
    int n = rd(), m = rd(), k = rd();
    vector<Edge> e(m);
    for (int i = 0; i < m; i++) { e[i].u = rd(); e[i].v = rd(); e[i].w = rd(); }
    for (int j = 1; j <= k; j++) { rd(); for (int i = 1; i <= n; i++) rd(); }  // 读掉但不使用
    for (int i = 1; i <= n; i++) fa[i] = i;
    sort(e.begin(), e.end(), [](const Edge& a, const Edge& b) { return a.w < b.w; });
    ll ans = 0; int cnt = 0;
    for (const Edge& x : e) {
        int u = find(x.u), v = find(x.v);
        if (u != v) { fa[u] = v; ans += x.w; if (++cnt == n - 1) break; }
    }
    printf("%lld\n", ans);
    return 0;
}
