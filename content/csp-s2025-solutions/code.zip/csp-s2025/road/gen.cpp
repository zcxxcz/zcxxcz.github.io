// T2 对拍数据生成器  ./gen <mode> <seed>
// mode 0: 小值域 0..3 (大量并列/零权)   mode 1: 值域 0..10
// mode 2: 满值域 0..1e9              mode 3: 特殊性质 A (c_j=0 且存在 a[j][i]=0)
#include <bits/stdc++.h>
using namespace std;
int main(int argc, char** argv) {
    int mode = atoi(argv[1]); unsigned seed = (unsigned)atoi(argv[2]);
    mt19937 rng(seed);
    int n = rng() % 6 + 2;                       // 2..7
    int kmax = n * (n - 1) / 2;
    int m = (int)(rng() % (kmax - (n - 1) + 1)) + (n - 1);   // n-1 .. kmax
    while (m < n - 1) m++;
    int k = rng() % 4;                           // 0..3
    long long V = (mode == 0 ? 3 : mode == 1 ? 10 : 1000000000LL);
    // 生成连通图：先树，再补边
    vector<pair<int,int>> es;
    for (int v = 2; v <= n; v++) es.push_back({(int)(rng() % (v - 1)) + 1, v});
    set<pair<int,int>> used;
    for (auto& e : es) used.insert({min(e.first, e.second), max(e.first, e.second)});
    while ((int)es.size() < m) {
        int u = rng() % n + 1, v = rng() % n + 1;
        if (u == v) continue;
        pair<int,int> p = {min(u,v), max(u,v)};
        if (used.count(p)) continue;
        used.insert(p); es.push_back(p);
    }
    printf("%d %d %d\n", n, m, k);
    for (auto& e : es) printf("%d %d %lld\n", e.first, e.second, (long long)(rng() % (V + 1)));
    for (int j = 1; j <= k; j++) {
        long long cj = (mode == 3) ? 0 : (long long)(rng() % (V + 1));
        printf("%lld", cj);
        for (int i = 1; i <= n; i++) {
            long long w;
            if (mode == 3 && i == 1) w = 0;                  // 保证存在 a[j][i]=0
            else w = (long long)(rng() % (V + 1));
            printf(" %lld", w);
        }
        printf("\n");
    }
    return 0;
}
