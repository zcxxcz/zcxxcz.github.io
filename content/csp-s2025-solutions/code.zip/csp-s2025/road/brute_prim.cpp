// T2 独立暴力：枚举 2^k 个集合，用 Prim 求 (n + 选中乡镇数) 个点的最小生成树
// 与正解的实现方式完全不同（邻接矩阵 + Prim，不做任何边缩减），用于对拍。
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll INF = (ll)4e18;
int n, m, k;
int eu[105], ev[105], ew[105];
int c[12], a[12][12];
int main() {
    scanf("%d %d %d", &n, &m, &k);
    for (int i = 0; i < m; i++) scanf("%d %d %d", &eu[i], &ev[i], &ew[i]);
    for (int j = 1; j <= k; j++) { scanf("%d", &c[j]); for (int i = 1; i <= n; i++) scanf("%d", &a[j][i]); }
    ll ans = INF;
    for (int mask = 0; mask < (1 << k); mask++) {
        vector<int> town;
        ll cost = 0;
        for (int j = 1; j <= k; j++) if (mask >> (j - 1) & 1) { town.push_back(j); cost += c[j]; }
        int N = n + (int)town.size();
        static ll g[20][20];
        for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) g[i][j] = INF;
        for (int i = 0; i < m; i++) {
            int u = eu[i] - 1, v = ev[i] - 1;
            g[u][v] = min(g[u][v], (ll)ew[i]); g[v][u] = g[u][v];
        }
        for (int t = 0; t < (int)town.size(); t++)
            for (int i = 1; i <= n; i++) {
                int u = n + t, v = i - 1;
                g[u][v] = min(g[u][v], (ll)a[town[t]][i]); g[v][u] = g[u][v];
            }
        // Prim
        static ll d[20]; static bool vis[20];
        for (int i = 0; i < N; i++) { d[i] = INF; vis[i] = false; }
        d[0] = 0;
        for (int it = 0; it < N; it++) {
            int x = -1;
            for (int i = 0; i < N; i++) if (!vis[i] && (x == -1 || d[i] < d[x])) x = i;
            vis[x] = true; cost += d[x];
            for (int i = 0; i < N; i++) if (!vis[i] && g[x][i] < d[i]) d[i] = g[x][i];
        }
        ans = min(ans, cost);
    }
    printf("%lld\n", ans);
    return 0;
}
