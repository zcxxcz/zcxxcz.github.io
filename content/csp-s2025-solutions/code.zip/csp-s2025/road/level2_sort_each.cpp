// CSP-S 2025 T2 道路修复 (road) —— 档2 (预期 32 分, 测试点 1~8: m<=1e5, k<=5)
// 枚举 2^k 个改造集合, 每个集合把「原图 m 条边 + 选中乡镇的 k*n 条边」合并后重新排序跑 Kruskal。
// 复杂度 O(2^k * (m + kn) log(m + kn))，m 到 1e6 就会被卡。
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
static inline int rd() {
    int x = 0; char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    while (ch >= '0' && ch <= '9') { x = x * 10 + (ch - '0'); ch = getchar(); }
    return x;
}
struct Edge { int u, v, w; };
int n, m, k;
vector<Edge> orig;
vector<vector<Edge>> townEdge;
int c[12];
int fa[10015];
int find(int x) { return fa[x] == x ? x : fa[x] = find(fa[x]); }

int main() {
    n = rd(); m = rd(); k = rd();
    orig.resize(m);
    for (int i = 0; i < m; i++) { orig[i].u = rd(); orig[i].v = rd(); orig[i].w = rd(); }
    townEdge.assign(k + 1, {});
    for (int j = 1; j <= k; j++) {
        c[j] = rd();
        for (int i = 1; i <= n; i++) townEdge[j].push_back({n + j, i, rd()});
    }
    ll ans = LLONG_MAX;
    vector<Edge> cur;
    for (int mask = 0; mask < (1 << k); mask++) {
        cur = orig;                                     // 每次重新拷贝 m 条边
        ll cost = 0;
        for (int j = 1; j <= k; j++)
            if (mask >> (j - 1) & 1) { cost += c[j]; cur.insert(cur.end(), townEdge[j].begin(), townEdge[j].end()); }
        sort(cur.begin(), cur.end(), [](const Edge& a, const Edge& b) { return a.w < b.w; });
        for (int i = 1; i <= n + k; i++) fa[i] = i;
        for (const Edge& e : cur) {
            int u = find(e.u), v = find(e.v);
            if (u != v) { fa[u] = v; cost += e.w; }
        }
        ans = min(ans, cost);
    }
    printf("%lld\n", ans);
    return 0;
}
