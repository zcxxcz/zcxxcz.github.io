// CSP-S 2025 T2 道路修复 (road) —— 档3 (预期 48 分, 测试点 1~12: k<=5)
// 把排序提到枚举外面：所有 m + k*n 条边只排一次, 枚举集合时线性扫描并跳过未改造乡镇的边。
// 复杂度 O(m log m + (kn) log(kn) + 2^k * (m + kn))，k=10 时 2^k*m 会炸。
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct Edge { int u, v, w, town; };
static inline int rd() {
    int x = 0; char ch = getchar();
    while (ch < '0' || ch > '9') ch = getchar();
    while (ch >= '0' && ch <= '9') { x = x * 10 + (ch - '0'); ch = getchar(); }
    return x;
}
int n, m, k;
vector<Edge> all;
int c[12];
int fa[10015];
int find(int x) { while (fa[x] != x) { fa[x] = fa[fa[x]]; x = fa[x]; } return x; }

int main() {
    n = rd(); m = rd(); k = rd();
    all.reserve(m + (size_t)k * n);
    for (int i = 0; i < m; i++) { int u = rd(), v = rd(), w = rd(); all.push_back({u, v, w, 0}); }
    for (int j = 1; j <= k; j++) {
        c[j] = rd();
        for (int i = 1; i <= n; i++) all.push_back({n + j, i, rd(), j});
    }
    sort(all.begin(), all.end(), [](const Edge& a, const Edge& b) { return a.w < b.w; });
    ll ans = LLONG_MAX;
    for (int mask = 0; mask < (1 << k); mask++) {
        for (int i = 1; i <= n + k; i++) fa[i] = i;
        ll cost = 0;
        for (int j = 1; j <= k; j++) if (mask >> (j - 1) & 1) cost += c[j];
        for (const Edge& e : all) {
            if (e.town && !(mask >> (e.town - 1) & 1)) continue;
            int u = find(e.u), v = find(e.v);
            if (u != v) { fa[u] = v; cost += e.w; }
        }
        ans = min(ans, cost);
    }
    printf("%lld\n", ans);
    return 0;
}
