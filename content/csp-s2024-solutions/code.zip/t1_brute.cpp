// T1 决斗 P11231 -- 20分档：n<=10 暴力搜索攻击顺序（记忆化）
#include <bits/stdc++.h>
using namespace std;
int n, r[12];
unordered_map<int, int> memo;          // key = aliveMask*1024 + atkMask
const int INF = 1e9;

// alive: 存活集合; atk: 已发起过攻击的集合
int dfs(int alive, int atk) {
    if ((alive & ~atk) == 0) return __builtin_popcount(alive);   // 存活者都已攻击
    int key = alive * 1024 + atk;
    auto it = memo.find(key);
    if (it != memo.end()) return it->second;
    int best = __builtin_popcount(alive);   // 无人可攻击时游戏直接结束（n=1 等）
    for (int i = 0; i < n; i++) {
        if (!(alive >> i & 1) || (atk >> i & 1)) continue;       // i 必须存活且未攻击
        for (int j = 0; j < n; j++) {
            if (i == j || !(alive >> j & 1)) continue;           // 目标 j 存活
            int na = alive, nat = atk | (1 << i);
            if (r[i] > r[j]) na &= ~(1 << j);                    // 打破防御 -> j 退出
            best = min(best, dfs(na, nat));
        }
    }
    return memo[key] = best;
}

int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) scanf("%d", &r[i]);
    printf("%d\n", dfs((1 << n) - 1, 0));
    return 0;
}
