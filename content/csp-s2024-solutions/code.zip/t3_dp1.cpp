// T3 染色 P11233 -- 50分档：观察到"每个状态必有一维等于 a_i"，把 A^2 的网格压成一维 D[v]
// D[v] = 上一个数与 v 配成 (最后红=a_i, 最后蓝=v) 的最大得分（红蓝对称，行列相同）
// 转移: D_i[v] = max( D_{i-1}[v] + (a_{i-1}==a_i ? a_i : 0),  (v==a_{i-1} ? M : -inf) )
//       M = max( max_{u!=a_i} D_{i-1}[u],  D_{i-1}[a_i] + a_i )
// 复杂度 O(n * A)，适合 A<=2000 的点
#include <bits/stdc++.h>
using namespace std;
const long long NEG = -1e18;
int n; int a[200005];
int main() {
    int T; scanf("%d", &T);
    while (T--) {
        scanf("%d", &n);
        int A = 0;
        for (int i = 1; i <= n; i++) { scanf("%d", &a[i]); A = max(A, a[i]); }
        vector<long long> D(A + 1, NEG), nD(A + 1);
        D[0] = 0;
        int prev = 0;                               // 虚拟的 a_0 = 0
        for (int i = 1; i <= n; i++) {
            int c = a[i];
            long long add = (prev == c) ? c : 0;
            // M = max( max_{u!=c} D[u], D[c] + c )；用全局最大值 G 代替"去掉 c 的最大值"即可
            long long G = NEG;
            for (int v = 0; v <= A; v++) G = max(G, D[v]);
            long long M = max(G, D[c] + c);
            for (int v = 0; v <= A; v++) nD[v] = D[v] + add;
            if (nD[prev] < M) nD[prev] = M;          // 单点 chmax (index = prev)
            D.swap(nD);
            prev = c;
        }
        long long ans = 0;
        for (int v = 0; v <= A; v++) ans = max(ans, D[v]);
        printf("%lld\n", ans);
    }
    return 0;
}
