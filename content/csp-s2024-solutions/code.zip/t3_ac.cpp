// T3 染色 P11233 -- 100分正解：在 O(n*A) 的基础上把"全局加 + 单点chmax + 全局max"
// 用惰性标记 tag 维护，A 只作为数组下标上界 -> O(n) 时间
#include <bits/stdc++.h>
using namespace std;
const long long NEG = -1e18;
static long long D[(int)1e6 + 5];        // D[v] - tag 的"原始值"
int n; static int a[(int)1e6 + 5];
int main() {
    int T; scanf("%d", &T);
    while (T--) {
        scanf("%d", &n);
        int A = 0;
        for (int i = 1; i <= n; i++) { scanf("%d", &a[i]); A = max(A, a[i]); }
        for (int v = 0; v <= A; v++) D[v] = NEG;   // 只需清 0..A
        D[0] = 0;
        long long tag = 0, G = 0;                  // tag: 全局偏移; G: 当前全局最大值(真实值)
        int prev = 0;                              // a_0 = 0
        for (int i = 1; i <= n; i++) {
            int c = a[i];
            long long add = (prev == c) ? c : 0;
            long long Dc = D[c] + tag;             // 真实 D_{i-1}[c]
            long long M = max(G, Dc + c);          // = max(max_{u!=c} D[u], D[c]+c)
            tag += add;                            // 全局加 add
            long long t = M - tag;                 // 单点 chmax at index prev
            if (D[prev] < t) D[prev] = t;
            G = max(G + add, M);                   // 新全局最大
            prev = c;
        }
        printf("%lld\n", G);
    }
    return 0;
}
