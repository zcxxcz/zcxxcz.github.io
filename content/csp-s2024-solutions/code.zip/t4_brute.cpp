// T4 擂台游戏 P11234 -- 12分档：n<=8 暴力枚举所有"补充选手"的能力值
// 关键: 能力值只需在 {0,1,...,k} 中取值（所有比较只与轮数 r<=k 有关）
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n, m, K;
ll a[12], b[12], c[300];
char D[30][(1 << 20) + 5];
int ab[20];                                  // 每个叶子的能力（已 clamp 到 [0,k]）
ll solve(int cq) {
    int k = 0; while ((1 << k) < cq) k++;
    int M = 1 << k;
    for (int p = 1; p <= M; p++)
        ab[p] = (p <= cq) ? (int)min(b[p], (ll)k) : 0;
    vector<int> freePos;
    for (int p = cq + 1; p <= M; p++) freePos.push_back(p);
    set<int> winners;
    int F = freePos.size();
    ll total = 1; for (int i = 0; i < F; i++) total *= (k + 1);
    for (ll code = 0; code < total; code++) {
        ll t = code;
        for (int i = 0; i < F; i++) { ab[freePos[i]] = t % (k + 1); t /= (k + 1); }
        vector<int> cur(M);
        for (int p = 0; p < M; p++) cur[p] = p + 1;
        for (int r = 1; r <= k; r++) {
            vector<int> nxt;
            int cnt = 1 << (k - r);
            for (int g = 0; g < cnt; g++) {
                int L = cur[2 * g], R = cur[2 * g + 1];
                int host = (D[r][g] == '0') ? L : R;
                int win = (ab[host] >= r) ? host : (host == L ? R : L);
                nxt.push_back(win);
            }
            cur = nxt;
        }
        winners.insert(cur[0]);
    }
    ll s = 0; for (int w : winners) s += w;
    return s;
}
int main() {
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= n; i++) scanf("%lld", &a[i]);
    for (int i = 1; i <= m; i++) scanf("%lld", &c[i]);
    for (K = 0; (1 << K) < n; K++);
    for (int r = 1; r <= K; r++) scanf("%s", D[r]);
    int T; scanf("%d", &T);
    while (T--) {
        ll X[4];
        for (int i = 0; i < 4; i++) scanf("%lld", &X[i]);
        for (int i = 1; i <= n; i++) b[i] = a[i] ^ X[i % 4];
        ll out = 0;
        for (int i = 1; i <= m; i++) out ^= (ll)i * solve((int)c[i]);
        printf("%lld\n", out);
    }
    return 0;
}
