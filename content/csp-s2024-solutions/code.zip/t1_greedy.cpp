// T1 决斗 P11231 -- 75分档：排序 + 双指针求最大消灭数（O(n log n)）
// 消灭数 = 二分图最大匹配(L=攻击者, R=受害者, 边 i->j 当 r_i>r_j)
// 贪婪：受害者从小到大，给每个受害者配"能杀它的最小攻击者"
#include <bits/stdc++.h>
using namespace std;
int main() {
    int n; scanf("%d", &n);
    vector<int> r(n);
    for (int i = 0; i < n; i++) scanf("%d", &r[i]);
    sort(r.begin(), r.end());
    int i = 0, killed = 0;                  // i: 攻击者指针
    for (int j = 0; j < n; j++) {           // j: 受害者指针，从小到大
        while (i < n && r[i] <= r[j]) i++;  // 找到"能杀 r[j] 的最小攻击者"
        if (i < n) { killed++; i++; }
    }
    printf("%d\n", n - killed);
    return 0;
}
