// T3 染色 P11233 -- 20分档：n<=20 枚举 2^n 种染色
#include <bits/stdc++.h>
using namespace std;
int n, a[25];
int main() {
    int T; scanf("%d", &T);
    while (T--) {
        scanf("%d", &n);
        for (int i = 0; i < n; i++) scanf("%d", &a[i]);
        long long best = 0;
        for (int m = 0; m < (1 << n); m++) {
            long long s = 0; int last[2] = {0, 0};      // 0 表示该颜色还没出现过（a_i>=1）
            for (int i = 0; i < n; i++) {
                int c = (m >> i) & 1;
                if (last[c] == a[i]) s += a[i];
                last[c] = a[i];
            }
            best = max(best, s);
        }
        printf("%lld\n", best);
    }
    return 0;
}
