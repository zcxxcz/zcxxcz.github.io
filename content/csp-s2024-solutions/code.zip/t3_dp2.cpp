// T3 染色 P11233 -- 35分档：朴素三维 DP 的滚动版 dp[x][y]（x=最后红色值, y=最后蓝色值）
// 复杂度 O(n * A^2)，只适合 A<=100 的点
#include <bits/stdc++.h>
using namespace std;
const long long NEG = -1e18;
int n, a[205];
int main() {
    int T; scanf("%d", &T);
    while (T--) {
        scanf("%d", &n);
        int A = 0;
        for (int i = 1; i <= n; i++) { scanf("%d", &a[i]); A = max(A, a[i]); }
        vector<vector<long long> > dp(A + 1, vector<long long>(A + 1, NEG));
        dp[0][0] = 0;
        for (int i = 1; i <= n; i++) {
            int c = a[i];
            vector<vector<long long> > nd(A + 1, vector<long long>(A + 1, NEG));
            for (int x = 0; x <= A; x++) for (int y = 0; y <= A; y++) {
                long long v = dp[x][y];
                if (v == NEG) continue;
                // 染红: 新的 (最后红, 最后蓝) = (c, y)
                nd[c][y] = max(nd[c][y], v + (x == c ? c : 0));
                // 染蓝: 新的 = (x, c)
                nd[x][c] = max(nd[x][c], v + (y == c ? c : 0));
            }
            dp.swap(nd);
        }
        long long ans = 0;
        for (int x = 0; x <= A; x++) for (int y = 0; y <= A; y++) ans = max(ans, dp[x][y]);
        printf("%lld\n", ans);
    }
    return 0;
}
