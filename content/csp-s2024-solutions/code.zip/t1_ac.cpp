// T1 决斗 P11231 -- 100分正解：答案 = 众数的出现次数
#include <bits/stdc++.h>
using namespace std;
int main() {
    int n; scanf("%d", &n);
    map<int, int> cnt; int ans = 0;
    for (int i = 0, x; i < n; i++) { scanf("%d", &x); ans = max(ans, ++cnt[x]); }
    printf("%d\n", ans);
    return 0;
}
