// T2 超速检测 P11232 -- 20分档：n,m<=20 暴力
// 问题1: 每辆车逐个测速仪用"整数精确比较"判断是否超速
// 问题2: 每辆车求出"能拍到它的测速仪"位掩码，枚举保留集合取最小 popcount
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll d[25], v[25], a[25], p[25];
int main() {
    int T; scanf("%d", &T);
    while (T--) {
        int n, m; ll L, V;
        scanf("%d %d %lld %lld", &n, &m, &L, &V);
        for (int i = 0; i < n; i++) scanf("%lld %lld %lld", &d[i], &v[i], &a[i]);
        for (int j = 0; j < m; j++) scanf("%lld", &p[j]);
        int ans1 = 0, mask[25];
        for (int i = 0; i < n; i++) {
            int mk = 0;
            for (int j = 0; j < m; j++) {
                if (p[j] < d[i]) continue;                       // 车从 d 向北行驶
                ll vsq = v[i] * v[i] + 2 * a[i] * (p[j] - d[i]);  // 该处速度平方
                if (vsq > V * V) mk |= 1 << j;
            }
            mask[i] = mk;
            if (mk) ans1++;
        }
        int best = m + 1;
        for (int s = 0; s < (1 << m); s++) {
            int c = __builtin_popcount(s);
            if (c >= best) continue;
            bool ok = true;
            for (int i = 0; i < n && ok; i++) if (mask[i] && !(s & mask[i])) ok = false;
            if (ok) best = c;
        }
        if (best > m) best = 0;
        printf("%d %d\n", ans1, m - best);
    }
    return 0;
}
