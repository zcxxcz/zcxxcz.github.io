// T1 决斗 P11231 -- 50分档：特殊性质 r_i <= 2（只可能是 1 或 2）
// 只有 1 和 2 两种数值：2 能杀 1，同值互杀不掉 -> 答案 = max(个数1, 个数2)
#include <bits/stdc++.h>
using namespace std;
int main() {
    int n; scanf("%d", &n);
    int c1 = 0, c2 = 0;
    for (int i = 0, x; i < n; i++) { scanf("%d", &x); (x == 1 ? c1 : c2)++; }
    printf("%d\n", max(c1, c2));
    return 0;
}
