// T2 超速检测 P11232 -- 100分正解
// 关键: 全程用整数比较 v^2+2a(p-d) > V^2，彻底避开浮点误差
// 每辆超速车"能拍到它的测速仪"是一个连续下标区间，问题2 化为"最少点覆盖区间"贪心
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 100005;
ll d[MAXN], v[MAXN], a[MAXN], p[MAXN];

int main() {
    int T; scanf("%d", &T);
    while (T--) {
        int n, m; ll L, V;
        scanf("%d %d %lld %lld", &n, &m, &L, &V);
        for (int i = 0; i < n; i++) scanf("%lld %lld %lld", &d[i], &v[i], &a[i]);
        for (int j = 0; j < m; j++) scanf("%lld", &p[j]);
        ll Vsq = V * V;
        vector<pair<int,int> > seg;               // (右端点, 左端点)
        int ans1 = 0;
        for (int i = 0; i < n; i++) {
            int st = lower_bound(p, p + m, d[i]) - p;      // 第一个 >= d_i 的测速仪
            if (st == m) continue;                          // 车前方没有测速仪
            ll v2 = v[i] * v[i];
            // 取区间 [st, m-1] 内满足 v2+2a(p-d) > V^2 的下标范围
            int lo = -1, hi = -1;
            if (a[i] >= 0) {                                // 单调不减 -> 找第一个 true
                int l = st, r = m - 1, res = -1;
                while (l <= r) {
                    int mid = (l + r) >> 1;
                    if (v2 + 2 * a[i] * (p[mid] - d[i]) > Vsq) res = mid, r = mid - 1;
                    else l = mid + 1;
                }
                if (res != -1) lo = res, hi = m - 1;
            } else {                                        // 单调不增 -> 找最后一个 true
                int l = st, r = m - 1, res = -1;
                while (l <= r) {
                    int mid = (l + r) >> 1;
                    if (v2 + 2 * a[i] * (p[mid] - d[i]) > Vsq) res = mid, l = mid + 1;
                    else r = mid - 1;
                }
                if (res != -1) lo = st, hi = res;
            }
            if (lo != -1) { ans1++; seg.push_back(make_pair(hi, lo)); }
        }
        sort(seg.begin(), seg.end());                      // 按右端点升序
        int cover = 0, last = -1;
        for (size_t k = 0; k < seg.size(); k++)
            if (last < seg[k].second) { cover++; last = seg[k].first; }
        printf("%d %d\n", ans1, m - cover);
    }
    return 0;
}
