// T4 擂台游戏 P11234 -- 中间档：拆"条件一/条件二" + 子树可达胜者能力集合 S
// 条件一: p 在其为擂主的每一轮 r 都有 a_p >= r
// 条件二: p 在其不为擂主的每一轮 r，兄弟子树能产出一个能力 < r 的胜者
// S(u) = u 子树"可能出现的胜者能力"集合(bitmask, 值域 0..k)
//   内部节点: 擂主一侧 { x in S(host) : x >= level } 并 (另一侧 if min(S(host)) < level)
// 复杂度 O(T * m * 2^k * k)
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n, m, K;
ll a[200005], b[200005], c[200005];
static char D[30][1 << 20];
int Sarr[1 << 19];                          // 节点 bitmask（k<=17 -> 18 bit）
int main() {
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= n; i++) scanf("%lld", &a[i]);
    for (int i = 1; i <= m; i++) scanf("%lld", &c[i]);
    for (K = 0; (1 << K) < n; K++);
    for (int r = 1; r <= K; r++) scanf("%s", D[r]);
    int T; scanf("%d", &T);
    while (T--) {
        ll X[4];
        for (int i = 0; i < 4; i++) scanf("%lld", &X[i]);
        for (int i = 1; i <= n; i++) b[i] = a[i] ^ X[i % 4];
        ll out = 0;
        for (int qi = 1; qi <= m; qi++) {
            int cq = (int)c[qi];
            int k = 0; while ((1 << k) < cq) k++;
            int M = 1 << k;
            for (int d = k; d >= 0; d--) {           // 自底向上
                int st = 1 << d;
                for (int u = st; u < (st << 1); u++) {
                    if (d == k) {                    // 叶子
                        int p = u - st + 1;          // 选手编号
                        if (p <= cq) Sarr[u] = 1 << (int)min(b[p], (ll)k);
                        else Sarr[u] = (2 << k) - 1; // 自由: {0..k}
                    } else {
                        int lev = k - d;
                        int g = u - st;
                        int SL = Sarr[u << 1], SR = Sarr[u << 1 | 1];
                        int lowL = __builtin_ctz(SL), lowR = __builtin_ctz(SR);
                        int hiMask = ((2 << k) - 1) ^ ((1 << lev) - 1);
                        int A, B = 0;
                        if (D[lev][g] == '0') {      // 左为擂主
                            A = SL & hiMask;
                            if (lowL < lev) B = SR;
                        } else {                     // 右为擂主
                            A = SR & hiMask;
                            if (lowR < lev) B = SL;
                        }
                        Sarr[u] = A | B;
                    }
                }
            }
            ll s = 0;
            for (int p = 1; p <= M; p++) {
                bool ok = true;
                int u = M + (p - 1);
                ll ap = (p <= cq) ? b[p] : (ll)k;
                for (int d = k - 1; d >= 0 && ok; d--) {
                    int lev = k - d, parent = u >> 1;
                    int g = parent - (1 << d);
                    int isLeft = ((u & 1) == 0);
                    int sib = isLeft ? (u + 1) : (u - 1);
                    bool pHost = (isLeft && D[lev][g] == '0') || (!isLeft && D[lev][g] == '1');
                    if (pHost) { if (ap < lev) ok = false; }
                    else       { if (__builtin_ctz(Sarr[sib]) >= lev) ok = false; }
                    u = parent;
                }
                if (ok) s += p;
            }
            out ^= (ll)qi * s;
        }
        printf("%lld\n", out);
    }
    return 0;
}
