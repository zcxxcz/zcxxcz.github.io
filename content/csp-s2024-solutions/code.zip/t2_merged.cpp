// ============================================================
// T2 超速检测 P11232 —— 把「特殊性质 A / B / C」三份部分分
// 拼成【一份可以真正提交】的程序
//
// 为什么必须拼：正式评测是「一道题只交一份程序」，判题机
// 不会告诉你这份数据属于哪个子任务。单独交 t2_a.cpp，只有
// 数据恰好满足 a_i=0 的测试点能得分，其它测试点会输出错误
// 答案（连暴力分都拿不到）。
//
// 拼法：先【探测】本题数据满足哪条特殊性质，满足就调对应的
// 快解，三条都不满足就退回暴力兜底（保证不输出错误答案）。
// ============================================================
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 100005;

ll d[MAXN], v[MAXN], a[MAXN], p[MAXN];

// ---------- 档 2：特殊性质 A（a_i = 0） ----------
// 匀速：超标位置是一段「后缀」（要么全程都不超，要么从某点起一直超）
ll solveA(int n, int m, ll V) {
    ll Vsq = V * V, lastp = p[m - 1];
    int ans1 = 0;
    for (int i = 0; i < n; i++)
        if (d[i] <= lastp && v[i] * v[i] > Vsq) ans1++;
    return ((ll)ans1 << 32) | (m - (ans1 > 0 ? 1 : 0));
}

// ---------- 档 3：特殊性质 B（a_i > 0） ----------
// 加速：速度单调不减，超标位置同样是「后缀」，
//       只需要看【最靠北】的那个测速仪就行
ll solveB(int n, int m, ll V) {
    ll Vsq = V * V, lastp = p[m - 1];
    int ans1 = 0;
    for (int i = 0; i < n; i++)
        if (d[i] <= lastp && v[i] * v[i] + 2 * a[i] * (lastp - d[i]) > Vsq) ans1++;
    return ((ll)ans1 << 32) | (m - (ans1 > 0 ? 1 : 0));
}

// ---------- 档 4：特殊性质 C（a_i < 0 且不驶出北端） ----------
// 减速：超标位置是一段「前缀」，能拍到它的测速仪下标连续，
//       问题 2 化为「最少点覆盖区间」贪心（按右端点排序）
ll solveC(int n, int m, ll V) {
    ll Vsq = V * V;
    vector<pair<int, int> > seg;                  // (右端点, 左端点)
    int ans1 = 0;
    for (int i = 0; i < n; i++) {
        int st = lower_bound(p, p + m, d[i]) - p;
        if (st == m) continue;                    // 车前方没有测速仪
        ll v2 = v[i] * v[i];
        int l = st, r = m - 1, res = -1;          // a<0：值单调不增 -> 找最后一个 true
        while (l <= r) {
            int mid = (l + r) >> 1;
            if (v2 + 2 * a[i] * (p[mid] - d[i]) > Vsq) res = mid, l = mid + 1;
            else r = mid - 1;
        }
        if (res != -1) { ans1++; seg.push_back(make_pair(res, st)); }
    }
    sort(seg.begin(), seg.end());
    int cover = 0, last = -1;
    for (size_t k = 0; k < seg.size(); k++)
        if (last < seg[k].second) cover++, last = seg[k].first;
    return ((ll)ans1 << 32) | (m - cover);
}

// ---------- 档 1：暴力兜底（不满足任何性质时用，仅 m 小时安全） ----------
ll solveBrute(int n, int m, ll V) {
    ll Vsq = V * V;
    int ans1 = 0; static int mask[105];
    for (int i = 0; i < n; i++) {
        int mk = 0;
        for (int j = 0; j < m; j++) {
            if (p[j] < d[i]) continue;
            if (v[i] * v[i] + 2 * a[i] * (p[j] - d[i]) > Vsq) mk |= 1 << j;
        }
        mask[i] = mk;
        if (mk) ans1++;
    }
    int best = m + 1;
    for (int s = 0; s < (1 << m); s++) {
        int c = __builtin_popcount(s);
        if (c >= best) continue;
        bool ok = true;
        for (int i = 0; i < n && ok; i++)
            if (mask[i] && !(s & mask[i])) ok = false;
        if (ok) best = c;
    }
    if (best > m) best = 0;
    return ((ll)ans1 << 32) | (m - best);
}

int main() {
    int T; scanf("%d", &T);
    while (T--) {
        int n, m; ll L, V;
        scanf("%d %d %lld %lld", &n, &m, &L, &V);
        for (int i = 0; i < n; i++) scanf("%lld %lld %lld", &d[i], &v[i], &a[i]);
        for (int j = 0; j < m; j++) scanf("%lld", &p[j]);

        // ---------- 探测输入满足哪条特殊性质 ----------
        bool propA = true, propB = true, propC = true;
        for (int i = 0; i < n; i++) {
            if (a[i] != 0) propA = false;
            if (!(a[i] > 0)) propB = false;
            if (!(a[i] < 0)) propC = false;
        }
        if (propC)                                 // C 还要求「不在最北端驶离」
            for (int i = 0; i < n; i++)
                if (v[i] * v[i] + 2 * a[i] * (L - d[i]) < 0) { propC = false; break; }

        ll res;
        if (propA)       res = solveA(n, m, V);
        else if (propB)  res = solveB(n, m, V);
        else if (propC)  res = solveC(n, m, V);
        else             res = solveBrute(n, m, V);

        printf("%d %d\n", (int)(res >> 32), (int)(res & 0xffffffffLL));
    }
    return 0;
}
