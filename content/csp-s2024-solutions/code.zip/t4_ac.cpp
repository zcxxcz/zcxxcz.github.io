// T4 擂台游戏 P11234 -- 100分正解（O(T(n+m)) 拆贡献）
// 思路（详细推导见文档）：
//   1) 建"胜负树"：2^K 个叶子，每个内部节点代表一场比赛；HOST[u] 表示 u 是否是这场比赛的擂主。
//   2) 关键点 kernel：从叶子往根，第一个"自己是擂主、但轮数已超过自己能力"的位置。
//      对手只要能"可能输"（子树里存在方案让对方这一场输掉），这个叶子就还能继续往上走。
//   3) 一个叶子的贡献区间是 [1, maxc]；用 BUCKET[level] + 并查式的 DEAD/LIVE 标记做到
//      "每个点只被删除一次"，扫描 i=1..n 增量维护 ans（当前 c=i 的答案）。
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int LIM = 200100;                 // 数组上界（n,m<=1e5）
const int ANC = 10010;                  // 一个不会被用到的"哨兵层号"
int n, m, K, T;
ll A0[LIM], AB[LIM], Q[LIM], Xv[4];
ll LV[LIM << 2], KEY[LIM << 2], KP[LIM << 2], CNT[LIM << 2];
bool HOST[LIM << 2], DEAD[LIM << 2], LIVE[LIM << 2], USED[LIM << 2];
char D[32][LIM << 2];
int LAST;                               // 叶子编号区间 = [LAST+1, 2*LAST+1]
ll ans, out, SAVE[LIM], B;              // B: 当前扫描到的 k(c)
vector<ll> BUCKET[LIM];                 // BUCKET[level] = 关键点层号为 level 的叶子列表

// 建树：计算每个节点的层号 LV，以及它是否是父节点那场比赛的擂主
void build(int u) {
    LV[u] = 1; LIVE[u] = 1; USED[u] = CNT[u] = DEAD[u] = 0;
    if (u <= LAST) { build(u << 1); build(u << 1 | 1); LV[u] = LV[u << 1] + 1; }
    int g = (u - (1 << (K - LV[u] + 1))) >> 1;      // 这场比赛的编号 g
    if (u & 1) HOST[u] = (D[LV[u]][g] == '1');      // 右儿子当擂主 <-> d=1
    else       HOST[u] = (D[LV[u]][g] == '0');      // 左儿子当擂主 <-> d=0
}

// 预处理"关键点"：KEY[l] = 当前路径上"层号>=l 的最近的擂主祖先"
void dfs(int u) {
    if (HOST[u]) KEY[LV[u]] = u;
    else         KEY[LV[u]] = KEY[LV[u] + 1];
    if (u > LAST) { KP[u] = KEY[min(AB[u - LAST] + 1, (ll)LIM + 1)]; return; }
    dfs(u << 1); dfs(u << 1 | 1);
}

// 删掉一整棵子树（它的叶子都不再可能是"可能胜者"）
void Remove(int u, ll id) {
    if (DEAD[u]) return;
    DEAD[u] = 1; LIVE[u] = 0;
    if (u > LAST) {
        ll kp = KP[u];
        if (u - LAST <= (1 << B) && !USED[u]) ans -= (u - LAST);
        if (u - LAST <= id) CNT[kp]--;
    }
    if (u <= LAST) Remove(u << 1, id), Remove(u << 1 | 1, id);
}

// 自底向上维护 LIVE/CNT，若某个"擂主子树"整棵都无法再产出可输的对手，就删掉它
void update(int u, ll id) {
    if (!LIVE[u] || !u) return;
    LIVE[u] = LIVE[u << 1] | LIVE[u << 1 | 1];
    if (!LIVE[u] && !CNT[u] && HOST[u] && !DEAD[u]) Remove(u ^ 1, id);   // 删兄弟
    if (!LIVE[u]) update(u >> 1, id);
}

int main() {
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= n; i++) scanf("%lld", &A0[i]);
    for (int i = 1; i <= m; i++) scanf("%lld", &Q[i]);
    for (K = 0; (1 << K) < n; K++);
    LAST = (1 << K) - 1;
    for (int r = 1; r <= K; r++)
        for (int g = 0; g < (1 << (K - r)); g++) scanf(" %c", &D[r][g]);
    scanf("%d", &T);
    LV[0] = ANC;
    while (T--) {
        build(1);
        for (int i = 0; i < 4; i++) scanf("%lld", &Xv[i]);
        for (int i = 1; i <= n; i++) AB[i] = A0[i] ^ Xv[i % 4];
        B = 0; ans = 1;
        dfs(1);
        for (int i = 1; i <= n; i++) {
            if ((1 << B) < i) {                        // c 跨过 2 的幂：新叶子先全部算进来
                B++;
                for (int j = i; j <= (1 << B); j++) ans += (ll)j * (!DEAD[LAST + j]);
                for (size_t t = 0; t < BUCKET[B].size(); t++) {
                    ll v = BUCKET[B][t];
                    if (!DEAD[v] && !USED[v]) { ans -= v - LAST; USED[v] = DEAD[v] = 1; }
                }
            }
            if (!DEAD[LAST + i]) {
                ll kp = KP[LAST + i];
                BUCKET[LV[kp]].push_back(LAST + i); CNT[kp]++;
                update(LAST + i, i);
                if (LV[kp] <= B) { ans -= i; USED[LAST + i] = 1; }
            }
            SAVE[i] = ans;
        }
        for (int i = 1; i <= K; i++) vector<ll>().swap(BUCKET[i]);
        vector<ll>().swap(BUCKET[ANC]);
        out = 0;
        for (int i = 1; i <= m; i++) out ^= (ll)i * SAVE[Q[i]];
        printf("%lld\n", out);
    }
    return 0;
}
