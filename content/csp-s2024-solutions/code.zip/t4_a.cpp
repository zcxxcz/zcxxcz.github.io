// T4 擂台游戏 P11234 -- 特殊性质 A 档 (所有询问的 c_i 均为 2 的幂次)
// c 是 2 的幂 => 恰好不需要补充选手，所有人的能力值都已知，比赛结果唯一确定
// 于是"可能胜者"只有一个，答案就是那个胜者的编号
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n, m, K;
ll a[200005], b[200005], c[200005];
char D[30][1 << 20];
int winOf[200005];                       // winOf[2^j] = 该规模下的冠军
int main() {
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= n; i++) scanf("%lld", &a[i]);
    for (int i = 1; i <= m; i++) scanf("%lld", &c[i]);
    for (K = 0; (1 << K) < n; K++);
    for (int r = 1; r <= K; r++) scanf("%s", D[r]);
    int T; scanf("%d", &T);
    while (T--) {
        ll X[4];
        for (int i = 0; i < 4; i++) scanf("%lld", &X[i]);
        for (int i = 1; i <= n; i++) b[i] = a[i] ^ X[i % 4];
        for (int j = 0; (1 << j) <= n; j++) {
            int M = 1 << j;
            vector<int> cur(M);
            for (int p = 0; p < M; p++) cur[p] = p + 1;
            for (int r = 1; r <= j; r++) {
                vector<int> nxt;
                for (int g = 0; g < (1 << (j - r)); g++) {
                    int L = cur[2 * g], R = cur[2 * g + 1];
                    int host = (D[r][g] == '0') ? L : R;
                    nxt.push_back(b[host] >= r ? host : (host == L ? R : L));
                }
                cur = nxt;
            }
            winOf[M] = cur[0];
        }
        ll out = 0;
        for (int i = 1; i <= m; i++) out ^= (ll)i * winOf[c[i]];
        printf("%lld\n", out);
    }
    return 0;
}
