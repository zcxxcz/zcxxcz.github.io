// T2 超速检测 P11232 -- 特殊性质 C (a_i < 0 且都不在最北端驶离) 档
// 全部减速: 超速区间是 [d_i, x0) 形状 -> 能拍到的测速仪是连续区间
// 问题2 = 最少点覆盖区间 (贪心按右端点)
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 100005;
ll d[MAXN], v[MAXN], a[MAXN], p[MAXN];
int main() {
    int T; scanf("%d", &T);
    while (T--) {
        int n, m; ll L, V;
        scanf("%d %d %lld %lld", &n, &m, &L, &V);
        for (int i = 0; i < n; i++) scanf("%lld %lld %lld", &d[i], &v[i], &a[i]);
        for (int j = 0; j < m; j++) scanf("%lld", &p[j]);
        ll Vsq = V * V;
        vector<pair<int,int> > seg;
        int ans1 = 0;
        for (int i = 0; i < n; i++) {
            int st = lower_bound(p, p + m, d[i]) - p;
            if (st == m) continue;
            ll v2 = v[i] * v[i];
            int l = st, r = m - 1, res = -1;              // a<0: 值单调不增，找最后一个 true
            while (l <= r) {
                int mid = (l + r) >> 1;
                if (v2 + 2 * a[i] * (p[mid] - d[i]) > Vsq) res = mid, l = mid + 1;
                else r = mid - 1;
            }
            if (res != -1) { ans1++; seg.push_back(make_pair(res, st)); }  // (右, 左)
        }
        sort(seg.begin(), seg.end());
        int cover = 0, last = -1;
        for (size_t k = 0; k < seg.size(); k++)
            if (last < seg[k].second) { cover++; last = seg[k].first; }
        printf("%d %d\n", ans1, m - cover);
    }
    return 0;
}
