// T2 超速检测 P11232 -- 特殊性质 A (a_i = 0) 档
// 全部匀速: 超速车一定能被"最靠北的测速仪"抓到
//   -> 问题2 = m-1 (存在超速车) 或 m (没有超速车)
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main() {
    int T; scanf("%d", &T);
    while (T--) {
        int n, m; ll L, V;
        scanf("%d %d %lld %lld", &n, &m, &L, &V);
        vector<ll> dd(n), vv(n);
        for (int i = 0; i < n; i++) { ll a; scanf("%lld %lld %lld", &dd[i], &vv[i], &a); }
        ll lastp = -1;
        for (int j = 0; j < m; j++) { ll x; scanf("%lld", &x); lastp = x; }
        int ans1 = 0;
        for (int i = 0; i < n; i++)
            if (vv[i] > V && dd[i] <= lastp) ans1++;   // 匀速超速 + 前方有测速仪
        printf("%d %d\n", ans1, m - (ans1 > 0 ? 1 : 0));
    }
    return 0;
}
