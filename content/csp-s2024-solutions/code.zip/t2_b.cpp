// T2 超速检测 P11232 -- 特殊性质 B (a_i > 0) 档
// 全部加速: 速度单调增 -> 最靠北的测速仪最容易抓到
//   问题2 答案 = m-1 (存在超速车) 或 m
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main() {
    int T; scanf("%d", &T);
    while (T--) {
        int n, m; ll L, V;
        scanf("%d %d %lld %lld", &n, &m, &L, &V);
        vector<ll> dd(n), vv(n), aa(n);
        for (int i = 0; i < n; i++) scanf("%lld %lld %lld", &dd[i], &vv[i], &aa[i]);
        ll lastp = -1;
        for (int j = 0; j < m; j++) { ll x; scanf("%lld", &x); lastp = x; }
        int ans1 = 0;
        for (int i = 0; i < n; i++)
            if (dd[i] <= lastp && vv[i] * vv[i] + 2 * aa[i] * (lastp - dd[i]) > V * V) ans1++;
        printf("%d %d\n", ans1, m - (ans1 > 0 ? 1 : 0));
    }
    return 0;
}
