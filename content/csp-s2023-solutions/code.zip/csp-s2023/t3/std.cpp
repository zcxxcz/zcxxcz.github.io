// P9754 结构体 —— 大模拟（满分写法）
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct Member { string name; int type; ll off; };
struct Type {
    ll size = 0, align = 1;
    vector<Member> mem;
    unordered_map<string, int> idx;
};
struct Elem { string name; int type; ll start; };

static inline ll alignUp(ll x, ll a) { return (x + a - 1) / a * a; }

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    if (!(cin >> n)) return 0;

    vector<Type> T(4);
    const char *bn[4] = {"byte", "short", "int", "long"};
    ll bs[4] = {1, 2, 4, 8};
    unordered_map<string, int> tid;
    for (int i = 0; i < 4; i++) { T[i].size = T[i].align = bs[i]; tid[bn[i]] = i; }

    vector<Elem> elems;
    ll curMem = 0;

    while (n--) {
        int op; cin >> op;
        if (op == 1) {                       // 定义结构体类型
            string s; int k; cin >> s >> k;
            Type t; t.align = 1; ll used = 0; // used = 下一个空闲字节
            for (int j = 0; j < k; j++) {
                string tn, mn; cin >> tn >> mn;
                int ti = tid[tn];
                ll off = alignUp(used, T[ti].align);   // 只按成员自身的对齐要求对齐
                t.mem.push_back({mn, ti, off});
                used = off + T[ti].size;
                t.align = max(t.align, T[ti].align);
            }
            t.size = alignUp(used, t.align);  // 整体大小对齐到结构体对齐要求
            for (int j = 0; j < k; j++) t.idx[t.mem[j].name] = j;
            tid[s] = (int)T.size(); T.push_back(t);
            cout << t.size << ' ' << t.align << '\n';
        } else if (op == 2) {                // 定义元素
            string tn, mn; cin >> tn >> mn;
            int ti = tid[tn];
            ll start = alignUp(curMem, T[ti].align);
            elems.push_back({mn, ti, start});
            curMem = start + T[ti].size;
            cout << start << '\n';
        } else if (op == 3) {                // 按 a.b.c 访问
            string s; cin >> s;
            vector<string> tok; string cw;
            for (char c : s) { if (c == '.') { tok.push_back(cw); cw.clear(); } else cw.push_back(c); }
            tok.push_back(cw);
            int ei = 0;
            for (int i = 0; i < (int)elems.size(); i++)
                if (elems[i].name == tok[0]) { ei = i; break; }
            int ti = elems[ei].type; ll addr = elems[ei].start;
            for (int j = 1; j < (int)tok.size(); j++) {
                int mi = T[ti].idx[tok[j]];
                addr += T[ti].mem[mi].off;
                ti = T[ti].mem[mi].type;
            }
            cout << addr << '\n';
        } else {                             // 由地址反查
            ll addr; cin >> addr;
            int ei = -1;
            for (int i = 0; i < (int)elems.size(); i++) {
                ll st = elems[i].start, en = st + T[elems[i].type].size - 1;
                if (addr < st) break;        // 落在元素之间的空洞
                if (addr <= en) { ei = i; break; }
            }
            if (ei < 0) { cout << "ERR\n"; continue; }
            ll local = addr - elems[ei].start;
            int ti = elems[ei].type;
            string path = elems[ei].name;
            bool ok = true;
            while (ti >= 4) {                // 0~3 是基本类型，即叶子
                int mi = -1;
                for (int j = 0; j < (int)T[ti].mem.size(); j++) {
                    ll o = T[ti].mem[j].off, sz = T[T[ti].mem[j].type].size;
                    if (local < o) break;            // 洞
                    if (local <= o + sz - 1) { mi = j; break; }
                }
                if (mi < 0) { ok = false; break; }
                path += "." + T[ti].mem[mi].name;
                local -= T[ti].mem[mi].off;
                ti = T[ti].mem[mi].type;
            }
            cout << (ok ? path : string("ERR")) << '\n';
        }
    }
    return 0;
}
