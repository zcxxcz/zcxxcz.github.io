// 小数据爆搜（用于对拍）：枚举所有合法种树顺序（拓扑序），取最优
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 lll;

int n;
vector<ll> a, b, c;
vector<vector<int>> g;
vector<int> fa, planted, order;
ll best = (ll)4e18;

static lll gain(int i, ll x, ll t) {
    ll bi = b[i], ci = c[i];
    if (ci >= 0) return (lll)(2 * bi + ci * (lll)(x + t)) * (t - x + 1) / 2;
    ll ti = (bi - 1) / (-ci);
    if (x > ti) return t - x + 1;
    ll hi = min(ti, t);
    lll s = (lll)(2 * bi + ci * (lll)(x + hi)) * (hi - x + 1) / 2;
    s += (t - hi);
    return s;
}
// 第 x 天种下，最少多少天长够 a_i
static ll needDay(int i, ll x) {
    ll lo = x, hi = (ll)4e18;
    while (lo < hi) { ll mid = lo + (hi - lo) / 2; if (gain(i, x, mid) >= a[i]) hi = mid; else lo = mid + 1; }
    return lo;
}

void dfs(int cnt, ll curMax) {
    if (curMax >= best) return;
    if (cnt == n) { best = min(best, curMax); return; }
    int day = cnt + 1;
    for (int u = 1; u <= n; u++) {
        if (planted[u]) continue;
        if (u != 1 && !planted[fa[u]]) continue;   // 父亲必须先种
        planted[u] = 1;
        dfs(cnt + 1, max(curMax, needDay(u, day)));
        planted[u] = 0;
    }
}

int main() {
    if (!(cin >> n)) return 0;
    a.assign(n + 1, 0); b.assign(n + 1, 0); c.assign(n + 1, 0);
    for (int i = 1; i <= n; i++) cin >> a[i] >> b[i] >> c[i];
    g.assign(n + 1, {});
    for (int i = 1; i < n; i++) { int u, v; cin >> u >> v; g[u].push_back(v); g[v].push_back(u); }
    fa.assign(n + 1, 0); planted.assign(n + 1, 0);
    // 以 1 为根求父亲（BFS）
    vector<int> q = {1}; fa[1] = 0;
    for (size_t h = 0; h < q.size(); h++) { int u = q[h]; for (int v : g[u]) if (v != fa[u]) { fa[v] = u; q.push_back(v); } }
    dfs(0, 0);
    cout << best << '\n';
    return 0;
}
