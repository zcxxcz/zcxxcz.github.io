import random, sys
n = random.randint(1,7)
lines = [str(n)]
for i in range(1, n+1):
    a = random.randint(1, 300)
    b = random.randint(1, 10)
    c = random.randint(-6, 6)
    lines.append(f"{a} {b} {c}")
# 随机树：先造一棵以1为根的结构，再随机给结点重标号（保证1是根）
perm = list(range(2, n+1)); random.shuffle(perm)
par = {}
nodes = [1]
for i in range(2, n+1):
    p = random.choice(nodes)
    par[i] = p
    nodes.append(i)
# 重标号：把根1留下，其它结点随机打乱映射
labels = list(range(2, n+1)); random.shuffle(labels)
mp = {1:1}
for i in range(2, n+1):
    mp[i] = labels[i-2]
for i in range(2, n+1):
    lines.append(f"{mp[par[i]]} {mp[i]}")
print("\n".join(lines))
