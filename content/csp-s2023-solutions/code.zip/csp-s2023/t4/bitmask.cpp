// P9755 种树 —— n <= 20 一档：状压 DP（测试点 1~4 写法）
// dp[S] = 已种下集合 S（占用前 |S| 天）时，「完成天数」的最小值
// 第 |S| 天选一个父亲已种的结点 u 种下，完成天数取 max(dp[S\{u}], need(u, |S|))
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 lll;
int n;
vector<ll> a, b, c;
vector<int> fa;

static lll gain(int i, ll x, ll t) {
    ll bi = b[i], ci = c[i];
    if (ci >= 0) return (lll)(2 * bi + ci * (lll)(x + t)) * (t - x + 1) / 2;
    ll ti = (bi - 1) / (-ci);
    if (x > ti) return t - x + 1;
    ll hi = min(ti, t);
    return (lll)(2 * bi + ci * (lll)(x + hi)) * (hi - x + 1) / 2 + (t - hi);
}
static ll need(int i, ll x) {
    ll lo = x, hi = (ll)4e18;
    while (lo < hi) { ll mid = lo + (hi - lo) / 2; if (gain(i, x, mid) >= a[i]) hi = mid; else lo = mid + 1; }
    return lo;
}
int main() {
    if (!(cin >> n)) return 0;
    a.assign(n + 1, 0); b.assign(n + 1, 0); c.assign(n + 1, 0);
    for (int i = 1; i <= n; i++) cin >> a[i] >> b[i] >> c[i];
    vector<vector<int>> g(n + 1);
    for (int i = 1; i < n; i++) { int u, v; cin >> u >> v; g[u].push_back(v); g[v].push_back(u); }
    fa.assign(n + 1, 0);
    vector<int> q = {1};
    for (size_t h = 0; h < q.size(); h++) { int u = q[h]; for (int v : g[u]) if (v != fa[u]) { fa[v] = u; q.push_back(v); } }

    const ll INF = (ll)4e18;
    vector<ll> dp(1u << n, INF);
    dp[0] = 0;
    for (unsigned S = 1; S < (1u << n); S++) {
        int day = __builtin_popcount(S);
        for (int u = 1; u <= n; u++) {
            if (!(S >> (u - 1) & 1)) continue;
            if (u != 1 && !((S >> (fa[u] - 1)) & 1)) continue;   // 父亲必须先种
            unsigned P = S ^ (1u << (u - 1));
            if (dp[P] == INF) continue;
            ll v = max(dp[P], need(u, day));
            if (v < dp[S]) dp[S] = v;
        }
    }
    cout << dp[(1u << n) - 1] << '\n';
    return 0;
}
