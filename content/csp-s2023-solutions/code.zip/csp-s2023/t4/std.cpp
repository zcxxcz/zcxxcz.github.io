// P9755 种树 —— 二分答案 + 最晚种植时间 + 拓扑传播 + Hall 计数（满分写法）
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 lll;

int n;
vector<ll> a, b, c;
vector<vector<int>> g;
vector<int> fa, ord;   // ord = 后序遍历序
vector<int> d, cnt;

// 若结点 i 在第 x 天种下，到第 t 天（t >= x）一共长了多少米
static lll gain(int i, ll x, ll t) {
    ll bi = b[i], ci = c[i];
    if (ci >= 0) {
        // 每项都是 bi + k*ci（恒 >= 1）
        return (lll)(2 * bi + ci * (lll)(x + t)) * (t - x + 1) / 2;
    }
    ll ti = (bi - 1) / (-ci);            // 最后一个满足 bi + k*ci >= 1 的 k
    if (x > ti) return t - x + 1;        // 全程每项都是 1
    ll hi = min(ti, t);
    lll s = (lll)(2 * bi + ci * (lll)(x + hi)) * (hi - x + 1) / 2;
    s += (t - hi);
    return s;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    if (!(cin >> n)) return 0;
    a.assign(n + 1, 0); b.assign(n + 1, 0); c.assign(n + 1, 0);
    for (int i = 1; i <= n; i++) cin >> a[i] >> b[i] >> c[i];
    g.assign(n + 1, {});
    for (int i = 1; i < n; i++) {
        int u, v; cin >> u >> v;
        g[u].push_back(v); g[v].push_back(u);
    }

    // 以 1 为根，求后序（儿子先于父亲处理）
    fa.assign(n + 1, 0); ord.clear(); ord.reserve(n);
    vector<int> stk; stk.push_back(1); fa[1] = 0;
    vector<int> it(n + 1, 0);
    while (!stk.empty()) {
        int u = stk.back();
        if (it[u] < (int)g[u].size()) {
            int v = g[u][it[u]++];
            if (v == fa[u]) continue;
            fa[v] = u; stk.push_back(v);
        } else {
            ord.push_back(u); stk.pop_back();
        }
    }
    // ord 现在就是后序：儿子一定排在父亲前面

    d.assign(n + 1, 0); cnt.assign(n + 2, 0);

    // 判定：能否在 t 天内完成
    auto chk = [&](ll t) -> bool {
        for (int i = 1; i <= n; i++) {
            // 二分出「最晚在第几天种下，才能在 t 天内长够」
            int lo = 1, hi = n, res = 0;
            while (lo <= hi) {
                int mid = (lo + hi) >> 1;
                if (gain(i, mid, t) >= a[i]) { res = mid; lo = mid + 1; }
                else hi = mid - 1;
            }
            if (res == 0) return false;
            d[i] = res;
        }
        for (int k = 0; k < n; k++) {          // 后序：父亲必须在儿子之前种
            int u = ord[k];
            for (int v : g[u]) if (v != fa[u]) d[u] = min(d[u], d[v] - 1);
            if (d[u] <= 0) return false;
        }
        for (int i = 1; i <= n; i++) cnt[i] = 0;
        for (int i = 1; i <= n; i++) cnt[d[i]]++;
        int s = 0;
        for (int i = 1; i <= n; i++) { s += cnt[i]; if (s > i) return false; }
        return true;
    };

    ll lo = n, hi = 1000000000LL;
    while (lo < hi) {
        ll mid = lo + (hi - lo) / 2;
        if (chk(mid)) hi = mid; else lo = mid + 1;
    }
    cout << lo << '\n';
    return 0;
}
