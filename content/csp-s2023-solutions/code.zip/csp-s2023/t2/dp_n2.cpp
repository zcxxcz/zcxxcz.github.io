// P9753 消消乐 —— O(n^2) DP 档（50~60 分写法，为满分做铺垫）
// f[i] = 以 i 结尾的可消除子串个数
// 从右往左扫 j，维护 reduced(s[j+1..i])；第一次变空的那个 j 就是「最短可消后缀的左边」，
// 于是 f[i] = f[j] + 1；整个扫描都没空过则 f[i] = 0。
#include <bits/stdc++.h>
using namespace std;
int main() {
    int n; string s;
    if (!(cin >> n)) return 0;
    cin >> s;
    vector<long long> f(n + 1, 0);
    long long ans = 0;
    for (int i = 1; i <= n; i++) {
        vector<char> st;                 // 倒序存 reduced(s[j+1..i])
        f[i] = 0;
        for (int j = i - 1; j >= 0; j--) {
            if (!st.empty() && st.back() == s[j]) st.pop_back();
            else st.push_back(s[j]);
            if (st.empty()) { f[i] = f[j] + 1; break; }
        }
        ans += f[i];
    }
    cout << ans << "\n";
    return 0;
}
