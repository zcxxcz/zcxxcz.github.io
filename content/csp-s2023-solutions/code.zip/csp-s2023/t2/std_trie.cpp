// P9753 消消乐 —— O(n) 正解：前缀归约状态 + Trie 编号 + 最近出现位置
#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    string s;
    if (!(cin >> n)) return 0;
    cin >> s;

    vector<int> par(1, -1);      // 每个 Trie 结点 = 一个归约状态，par 指上去掉末尾字符后的状态
    vector<char> chr(1, 0);      // 到达该状态所压入的字符 = 栈顶字符
    vector<int> lastSeen(1, 0);  // 该状态最近一次出现的前缀下标（结点 0 在 i=0 出现过）
    vector<long long> f(n + 1, 0);
    unordered_map<long long, int> to;
    to.reserve((size_t)n * 2 + 16);
    to.max_load_factor(0.7);

    int cur = 0;                 // 当前栈状态编号
    long long ans = 0;
    for (int i = 1; i <= n; i++) {
        int c = s[i - 1] - 'a';
        if (cur != 0 && chr[cur] == s[i - 1]) {
            cur = par[cur];                       // 与栈顶相同 -> 弹出
        } else {
            long long key = (long long)cur * 26 + c;
            auto it = to.find(key);
            if (it == to.end()) {                 // 压入并新建结点
                int id = (int)par.size();
                par.push_back(cur);
                chr.push_back(s[i - 1]);
                lastSeen.push_back(-1);
                to.emplace(key, id);
                cur = id;
            } else {
                cur = it->second;
            }
        }
        int p = lastSeen[cur];
        long long fi = (p >= 0 ? f[p] + 1 : 0);   // 以 i 结尾的可消除子串个数
        f[i] = fi;
        ans += fi;
        lastSeen[cur] = i;
    }
    cout << ans << "\n";
    return 0;
}
