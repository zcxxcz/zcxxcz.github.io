// P9753 消消乐 —— O(n^2) 部分分暴力（枚举右端点，向左扩展）
#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    string s;
    if (!(cin >> n)) return 0;
    cin >> s;
    long long ans = 0;
    vector<char> st;              // st 里存的是 reduced(l..r) 的「倒序」
    for (int r = 0; r < n; r++) {
        st.clear();
        for (int l = r; l >= 0; l--) {
            if (!st.empty() && st.back() == s[l]) st.pop_back();
            else st.push_back(s[l]);
            if (st.empty()) ans++;      // s[l..r] 可完全消除
        }
    }
    cout << ans << "\n";
    return 0;
}
