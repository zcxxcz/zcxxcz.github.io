// CSP-S 2022 T1 假期计划 —— 100 分：每个点只保留分数最高的 3 个"与家相邻"的候选
#include <cstdio>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int n, m, k;
long long s[2505];
vector<int> g[2505];
vector<int> adj[2505];       // 与 b 距离 <= k+1 的点（不含 1、b），用于枚举 c
int best[2505][3], cnt[2505];// 其中与家也相邻的、分数最高的 3 个，用于挑 a / d
vector<char> reach1;

int main() {
    scanf("%d %d %d", &n, &m, &k);
    for (int i = 2; i <= n; ++i) scanf("%lld", &s[i]);
    for (int i = 0; i < m; ++i) {
        int x, y; scanf("%d %d", &x, &y);
        g[x].push_back(y); g[y].push_back(x);
    }
    int lim = k + 1;
    reach1.assign(n + 1, 0);
    vector<int> dist(n + 1, -1);

    queue<int> q; q.push(1); dist[1] = 0;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        if (dist[u] >= lim) continue;
        for (int v : g[u]) if (dist[v] < 0) { dist[v] = dist[u] + 1; q.push(v); }
    }
    for (int v = 1; v <= n; ++v) reach1[v] = (dist[v] >= 0);

    for (int b = 2; b <= n; ++b) {
        fill(dist.begin(), dist.end(), -1);
        queue<int> qq; qq.push(b); dist[b] = 0;
        while (!qq.empty()) {
            int u = qq.front(); qq.pop();
            if (dist[u] >= lim) continue;
            for (int v : g[u]) if (dist[v] < 0) { dist[v] = dist[u] + 1; qq.push(v); }
        }
        vector<int> ok;
        for (int v = 2; v <= n; ++v) {
            if (v == b || dist[v] < 0) continue;
            adj[b].push_back(v);
            if (reach1[v]) ok.push_back(v);
        }
        int sz = (int)ok.size();
        cnt[b] = min(sz, 3);
        vector<int> idx(sz);
        for (int i = 0; i < sz; ++i) idx[i] = i;
        partial_sort(idx.begin(), idx.begin() + cnt[b], idx.end(),
                     [&](int x, int y) { return s[ok[x]] > s[ok[y]]; });
        for (int i = 0; i < cnt[b]; ++i) best[b][i] = ok[idx[i]];
    }

    long long ans = -1;
    for (int b = 2; b <= n; ++b) {
        for (int c : adj[b]) {
            for (int i = 0; i < cnt[b]; ++i) {
                int a = best[b][i];
                if (a == c) continue;
                for (int j = 0; j < cnt[c]; ++j) {
                    int d = best[c][j];
                    if (d == b || d == a) continue;
                    long long cur = s[a] + s[b] + s[c] + s[d];
                    if (cur > ans) ans = cur;
                }
            }
        }
    }
    printf("%lld\n", ans);
    return 0;
}
