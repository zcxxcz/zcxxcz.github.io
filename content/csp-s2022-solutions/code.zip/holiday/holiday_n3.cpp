// CSP-S 2022 T1 假期计划 —— 70 分：枚举 b、c、a，O(1) 取 d，总 O(n^2 * 候选数)
// 覆盖测试点 1~14（n <= 300）；k = 0 的 15~17 因为候选很少通常也能过
//
// 关键：行程是 1 -> a -> b -> c -> d -> 1，只有 a 和 d 必须与家 1 相邻，
//       b、c 只是"中转站"，与家是否可达无关。
#include <cstdio>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int n, m, k;
long long s[2505];
vector<int> g[2505];
vector<int> adj[2505];   // adj[b]: 与 b 的距离 <= k+1 的点（不含 1、b），用于枚举 c
vector<int> srt[2505];   // srt[b]: 上面再筛出"与家也相邻"的点，按分数降序，用于挑 a / d
vector<char> reach1;

int main() {
    scanf("%d %d %d", &n, &m, &k);
    for (int i = 2; i <= n; ++i) scanf("%lld", &s[i]);
    for (int i = 0; i < m; ++i) {
        int x, y; scanf("%d %d", &x, &y);
        g[x].push_back(y); g[y].push_back(x);
    }
    int lim = k + 1;
    reach1.assign(n + 1, 0);
    vector<int> dist(n + 1, -1);

    queue<int> q; q.push(1); dist[1] = 0;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        if (dist[u] >= lim) continue;
        for (int v : g[u]) if (dist[v] < 0) { dist[v] = dist[u] + 1; q.push(v); }
    }
    for (int v = 1; v <= n; ++v) reach1[v] = (dist[v] >= 0);

    for (int b = 2; b <= n; ++b) {
        fill(dist.begin(), dist.end(), -1);
        queue<int> qq; qq.push(b); dist[b] = 0;
        while (!qq.empty()) {
            int u = qq.front(); qq.pop();
            if (dist[u] >= lim) continue;
            for (int v : g[u]) if (dist[v] < 0) { dist[v] = dist[u] + 1; qq.push(v); }
        }
        for (int v = 2; v <= n; ++v) {
            if (v == b || dist[v] < 0) continue;
            adj[b].push_back(v);
            if (reach1[v]) srt[b].push_back(v);
        }
        sort(srt[b].begin(), srt[b].end(), [](int x, int y) { return s[x] > s[y]; });
    }

    long long ans = -1;
    for (int b = 2; b <= n; ++b) {
        for (int c : adj[b]) {                   // b -> c 这一段可行
            for (int a : srt[b]) {               // a 必须与家相邻
                if (a == c) continue;
                for (int d : srt[c]) {           // 取第一个可用的 d（降序）
                    if (d == b || d == a) continue;
                    long long cur = s[a] + s[b] + s[c] + s[d];
                    if (cur > ans) ans = cur;
                    break;
                }
            }
        }
    }
    printf("%lld\n", ans);
    return 0;
}
