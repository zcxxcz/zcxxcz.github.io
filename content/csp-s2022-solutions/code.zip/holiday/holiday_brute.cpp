// CSP-S 2022 T1 假期计划 —— 40 分：O(n^4) 四重枚举 + BFS
// 覆盖测试点 1~8（n <= 20）
#include <cstdio>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int n, m, k;
long long s[2505];
vector<int> g[2505];
vector<vector<short>> d;   // d[u][v]: 最短路边数，-1 表示距离 > k+1

int main() {
    scanf("%d %d %d", &n, &m, &k);
    for (int i = 2; i <= n; ++i) scanf("%lld", &s[i]);
    for (int i = 1; i <= n; ++i) g[i].clear();
    for (int i = 0; i < m; ++i) {
        int x, y; scanf("%d %d", &x, &y);
        g[x].push_back(y); g[y].push_back(x);
    }
    int lim = k + 1;
    d.assign(n + 1, vector<short>(n + 1, -1));
    for (int src = 1; src <= n; ++src) {
        queue<int> q;
        q.push(src); d[src][src] = 0;
        while (!q.empty()) {
            int u = q.front(); q.pop();
            if (d[src][u] >= lim) continue;
            for (int v : g[u])
                if (d[src][v] < 0) { d[src][v] = (short)(d[src][u] + 1); q.push(v); }
        }
    }
    long long ans = -1;
    for (int a = 2; a <= n; ++a) {
        if (d[1][a] < 0) continue;
        for (int b = 2; b <= n; ++b) {
            if (b == a || d[a][b] < 0) continue;
            for (int c = 2; c <= n; ++c) {
                if (c == a || c == b || d[b][c] < 0) continue;
                for (int x = 2; x <= n; ++x) {
                    if (x == a || x == b || x == c) continue;
                    if (d[c][x] < 0 || d[x][1] < 0) continue;
                    ans = max(ans, s[a] + s[b] + s[c] + s[x]);
                }
            }
        }
    }
    printf("%lld\n", ans);
    return 0;
}
