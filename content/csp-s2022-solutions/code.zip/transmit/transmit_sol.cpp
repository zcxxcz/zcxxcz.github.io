// CSP-S 2022 T4 数据传输 —— 100 分：三状态 DP + (min,+) 矩阵 + 树上倍增
//
// 把 s->t 的路径展成 p0=s, p1, ..., pL=t。设
//   dp[i][0] = 落点就在 p_i 的最小代价
//   dp[i][1] = 落点距 p_i 为 1 的最小代价（p_{i-1} 或 p_i 最便宜的邻居）
//   dp[i][2] = 落点距 p_i 为 2 的最小代价（= dp[i-1][1]）
// 转移（num_i = p_i 的邻居中最小权值）：
//   dp[i][0] = min(dp[i-1][0..2]) + v_i
//   dp[i][1] = min(dp[i-1][0], dp[i-1][1] + num_i)
//   dp[i][2] = dp[i-1][1]
// 写成 (min,+) 矩阵：
//   [ v_i   v_i        v_i       ]
//   [ 0     num_i      INF       ]
//   [ INF   0          INF       ]
// 路径上相邻两点距离为 1，所以"跳两步"要检查 k，k=2 时最后一行/列要关掉。
#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;

const int N = 200005, LOG = 18;
const long long INF = (long long)4e18;
int n, Q, k;
long long v[N], numv[N], pre[N];
vector<int> g[N];
int dep[N], up[N][LOG];

struct Mat { long long a[3][3]; };

inline Mat ident() {
    Mat z;
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j) z.a[i][j] = (i == j ? 0 : INF);
    return z;
}
inline Mat mul(const Mat &x, const Mat &y) {
    Mat z;
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j) {
            long long b0 = x.a[i][0] + y.a[0][j];
            long long b1 = x.a[i][1] + y.a[1][j];
            long long b2 = x.a[i][2] + y.a[2][j];
            z.a[i][j] = min(b0, min(b1, b2));
        }
    return z;
}
// 由点 u 构造转移矩阵
inline Mat nodeMat(int u) {
    Mat z;
    z.a[0][0] = v[u];
    z.a[0][1] = (k >= 2 ? v[u] : INF);
    z.a[0][2] = (k >= 3 ? v[u] : INF);
    z.a[1][0] = 0;
    z.a[1][1] = (k >= 3 ? numv[u] : INF);   // 旁支之间要走 3 步
    z.a[1][2] = INF;
    z.a[2][0] = INF;
    z.a[2][1] = 0;
    z.a[2][2] = INF;
    return z;
}

static Mat A[N][LOG];   // A[u][j]：从 u 向上走 2^j 步的乘积（含终点，不含 u）
static Mat D[N][LOG];   // D[u][j]：从 u 的 2^j 级祖先走到 u 的乘积（含 u，不含祖先）

int lcaOf(int a, int b) {
    if (dep[a] < dep[b]) swap(a, b);
    int d = dep[a] - dep[b];
    for (int j = 0; j < LOG; ++j) if (d >> j & 1) a = up[a][j];
    if (a == b) return a;
    for (int j = LOG - 1; j >= 0; --j)
        if (up[a][j] != up[b][j]) { a = up[a][j]; b = up[b][j]; }
    return up[a][0];
}

int main() {
    scanf("%d %d %d", &n, &Q, &k);
    for (int i = 1; i <= n; ++i) scanf("%lld", &v[i]);
    for (int i = 1; i < n; ++i) {
        int a, b; scanf("%d %d", &a, &b);
        g[a].push_back(b); g[b].push_back(a);
    }
    for (int i = 1; i <= n; ++i) {
        numv[i] = INF;
        for (int w : g[i]) numv[i] = min(numv[i], v[w]);
    }
    // 迭代建树
    vector<int> ord; ord.reserve(n); ord.push_back(1);
    dep[1] = 1; up[1][0] = 1; pre[1] = v[1];
    for (size_t h = 0; h < ord.size(); ++h) {
        int u = ord[h];
        for (int w : g[u]) if (w != up[u][0]) {
            up[w][0] = u; dep[w] = dep[u] + 1; pre[w] = pre[u] + v[w];
            ord.push_back(w);
        }
    }
    for (int j = 1; j < LOG; ++j)
        for (int u = 1; u <= n; ++u) up[u][j] = up[up[u][j - 1]][j - 1];

    if (k == 1) {                    // 只能沿边逐跳：路径点权和
        while (Q--) {
            int s, t; scanf("%d %d", &s, &t);
            int l = lcaOf(s, t);
            printf("%lld\n", pre[s] + pre[t] - 2 * pre[l] + v[l]);
        }
        return 0;
    }

    for (int u = 1; u <= n; ++u) {
        A[u][0] = (u == 1 ? ident() : nodeMat(up[u][0]));
        D[u][0] = nodeMat(u);
    }
    for (int j = 1; j < LOG; ++j)
        for (int u = 1; u <= n; ++u) {
            int mid = up[u][j - 1];
            A[u][j] = mul(A[mid][j - 1], A[u][j - 1]);
            D[u][j] = mul(D[u][j - 1], D[mid][j - 1]);
        }

    while (Q--) {
        int s, t; scanf("%d %d", &s, &t);
        int l = lcaOf(s, t);
        int len1 = dep[s] - dep[l], len2 = dep[t] - dep[l];

        Mat Up = ident();
        int cur = s;
        for (int j = LOG - 1; j >= 0; --j)
            if (len1 >> j & 1) { Up = mul(A[cur][j], Up); cur = up[cur][j]; }

        Mat Down = ident();
        cur = t;
        for (int j = LOG - 1; j >= 0; --j)
            if (len2 >> j & 1) { Down = mul(Down, D[cur][j]); cur = up[cur][j]; }

        Mat tot = mul(Down, Up);
        printf("%lld\n", tot.a[0][0] + v[s]);
    }
    return 0;
}
