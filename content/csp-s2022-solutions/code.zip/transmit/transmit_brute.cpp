// CSP-S 2022 T4 数据传输 —— 44 分：最短路暴力
// 把"一次跳 <= k 条边"建成边，从 s 跑到 t 的 Dijkstra，代价为目标点权值
// 覆盖测试点 1~11（n, Q <= 2000）
#include <cstdio>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

const int N = 200005;
const long long INF = (long long)4e18;
int n, Q, k;
long long v[N];
vector<int> g[N];
vector<int> reach[N];      // 与 i 距离在 [1, k] 内的点

int main() {
    scanf("%d %d %d", &n, &Q, &k);
    for (int i = 1; i <= n; ++i) scanf("%lld", &v[i]);
    for (int i = 1; i < n; ++i) {
        int a, b; scanf("%d %d", &a, &b);
        g[a].push_back(b); g[b].push_back(a);
    }
    vector<int> dist(n + 1), que(n + 1);
    for (int s = 1; s <= n; ++s) {
        fill(dist.begin(), dist.end(), -1);
        int head = 0, tail = 0;
        dist[s] = 0; que[tail++] = s;
        while (head < tail) {
            int u = que[head++];
            if (dist[u] == k) continue;
            for (int w : g[u]) if (dist[w] < 0) { dist[w] = dist[u] + 1; que[tail++] = w; }
        }
        for (int w = 1; w <= n; ++w) if (dist[w] > 0) reach[s].push_back(w);
    }
    while (Q--) {
        int s, t; scanf("%d %d", &s, &t);
        vector<long long> d(n + 1, INF);
        priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<>> pq;
        d[s] = v[s]; pq.push({v[s], s});
        while (!pq.empty()) {
            auto pr = pq.top(); pq.pop();
            long long du = pr.first; int u = pr.second;
            if (du != d[u]) continue;
            if (u == t) break;
            for (int w : reach[u]) {
                long long nd = du + v[w];
                if (nd < d[w]) { d[w] = nd; pq.push({nd, w}); }
            }
        }
        printf("%lld\n", d[t]);
    }
    return 0;
}
