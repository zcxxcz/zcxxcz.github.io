// CSP-S 2022 T4 数据传输 —— 52 分：k = 1 用前缀和，其余仍走暴力最短路
// 覆盖测试点 1~13（12~13 是 k = 1 的满数据）
#include <cstdio>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

const int N = 200005, LOG = 18;
const long long INF = (long long)4e18;
int n, Q, k;
long long v[N], pre[N];
vector<int> g[N];
int dep[N], up[N][LOG];
vector<int> reach[N];

int lcaOf(int a, int b) {
    if (dep[a] < dep[b]) swap(a, b);
    int d = dep[a] - dep[b];
    for (int j = 0; j < LOG; ++j) if (d >> j & 1) a = up[a][j];
    if (a == b) return a;
    for (int j = LOG - 1; j >= 0; --j)
        if (up[a][j] != up[b][j]) { a = up[a][j]; b = up[b][j]; }
    return up[a][0];
}

int main() {
    scanf("%d %d %d", &n, &Q, &k);
    for (int i = 1; i <= n; ++i) scanf("%lld", &v[i]);
    for (int i = 1; i < n; ++i) {
        int a, b; scanf("%d %d", &a, &b);
        g[a].push_back(b); g[b].push_back(a);
    }
    vector<int> ord; ord.reserve(n); ord.push_back(1);
    dep[1] = 1; up[1][0] = 1; pre[1] = v[1];
    for (size_t h = 0; h < ord.size(); ++h) {
        int u = ord[h];
        for (int w : g[u]) if (w != up[u][0]) {
            up[w][0] = u; dep[w] = dep[u] + 1; pre[w] = pre[u] + v[w];
            ord.push_back(w);
        }
    }
    for (int j = 1; j < LOG; ++j)
        for (int u = 1; u <= n; ++u) up[u][j] = up[up[u][j - 1]][j - 1];

    if (k == 1) {                        // 只能沿边逐跳
        while (Q--) {
            int s, t; scanf("%d %d", &s, &t);
            int l = lcaOf(s, t);
            printf("%lld\n", pre[s] + pre[t] - 2 * pre[l] + v[l]);
        }
        return 0;
    }
    // k >= 2：暴力建"距离 <= k"的边，逐次询问跑 Dijkstra
    vector<int> dist(n + 1), que(n + 1);
    for (int s = 1; s <= n; ++s) {
        fill(dist.begin(), dist.end(), -1);
        int head = 0, tail = 0;
        dist[s] = 0; que[tail++] = s;
        while (head < tail) {
            int u = que[head++];
            if (dist[u] == k) continue;
            for (int w : g[u]) if (dist[w] < 0) { dist[w] = dist[u] + 1; que[tail++] = w; }
        }
        for (int w = 1; w <= n; ++w) if (dist[w] > 0) reach[s].push_back(w);
    }
    while (Q--) {
        int s, t; scanf("%d %d", &s, &t);
        vector<long long> d(n + 1, INF);
        priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<>> pq;
        d[s] = v[s]; pq.push({v[s], s});
        while (!pq.empty()) {
            auto pr = pq.top(); pq.pop();
            long long du = pr.first; int u = pr.second;
            if (du != d[u]) continue;
            if (u == t) break;
            for (int w : reach[u]) {
                long long nd = du + v[w];
                if (nd < d[w]) { d[w] = nd; pq.push({nd, w}); }
            }
        }
        printf("%lld\n", d[t]);
    }
    return 0;
}
