// CSP-S 2022 T2 策略游戏 —— 100 分：ST 表 + 符号分类讨论
//
// 给定 x 后小 Q 只能让分变最小：
//   x > 0  ->  x * min(B 区间)
//   x < 0  ->  x * max(B 区间)
//   x = 0  ->  0
// 于是小 L 只需要在 A 区间里挑：正数里 x*ymin 最大 / 负数里 x*ymax 最大 / 0
//   ymin > 0 时正数取最大的，ymin < 0 时正数取最小的
//   ymax > 0 时负数取最大的（最接近 0），ymax < 0 时负数取最小的（最负）
#include <cstdio>
#include <algorithm>
using namespace std;

const int MAXN = 100005, LOGN = 18;
const int INF = 2100000000;
int n, m, q, lg[MAXN];
int A[MAXN], B[MAXN];

int mxPos[LOGN][MAXN], mnPos[LOGN][MAXN];   // A 区间：最大正数 / 最小正数
int mxNeg[LOGN][MAXN], mnNeg[LOGN][MAXN];   // A 区间：最大负数（最接近 0）/ 最小负数（最负）
int has0[LOGN][MAXN];
int mxB[LOGN][MAXN], mnB[LOGN][MAXN];

int main() {
    scanf("%d %d %d", &n, &m, &q);
    for (int i = 1; i <= n; ++i) scanf("%d", &A[i]);
    for (int i = 1; i <= m; ++i) scanf("%d", &B[i]);
    lg[1] = 0;
    for (int i = 2; i <= max(n, m); ++i) lg[i] = lg[i >> 1] + 1;

    for (int i = 1; i <= n; ++i) {
        mxPos[0][i] = (A[i] > 0 ? A[i] : -INF);
        mnPos[0][i] = (A[i] > 0 ? A[i] : INF);
        mxNeg[0][i] = (A[i] < 0 ? A[i] : -INF);
        mnNeg[0][i] = (A[i] < 0 ? A[i] : INF);
        has0[0][i]  = (A[i] == 0);
    }
    for (int i = 1; i <= m; ++i) { mxB[0][i] = mnB[0][i] = B[i]; }

    for (int j = 1; j < LOGN; ++j) {
        for (int i = 1; i + (1 << j) - 1 <= n; ++i) {
            int p = i + (1 << (j - 1));
            mxPos[j][i] = max(mxPos[j - 1][i], mxPos[j - 1][p]);
            mnPos[j][i] = min(mnPos[j - 1][i], mnPos[j - 1][p]);
            mxNeg[j][i] = max(mxNeg[j - 1][i], mxNeg[j - 1][p]);
            mnNeg[j][i] = min(mnNeg[j - 1][i], mnNeg[j - 1][p]);
            has0[j][i]  = has0[j - 1][i] | has0[j - 1][p];
        }
        for (int i = 1; i + (1 << j) - 1 <= m; ++i) {
            int p = i + (1 << (j - 1));
            mxB[j][i] = max(mxB[j - 1][i], mxB[j - 1][p]);
            mnB[j][i] = min(mnB[j - 1][i], mnB[j - 1][p]);
        }
    }

    while (q--) {
        int l1, r1, l2, r2;
        scanf("%d %d %d %d", &l1, &r1, &l2, &r2);
        int k1 = lg[r1 - l1 + 1], k2 = lg[r2 - l2 + 1];
        int u1 = l1, v1 = r1 - (1 << k1) + 1;
        int u2 = l2, v2 = r2 - (1 << k2) + 1;

        int bp = max(mxPos[k1][u1], mxPos[k1][v1]);
        int sp = min(mnPos[k1][u1], mnPos[k1][v1]);
        int bn = max(mxNeg[k1][u1], mxNeg[k1][v1]);
        int sn = min(mnNeg[k1][u1], mnNeg[k1][v1]);
        bool zero = has0[k1][u1] | has0[k1][v1];
        int ymax = max(mxB[k2][u2], mxB[k2][v2]);
        int ymin = min(mnB[k2][u2], mnB[k2][v2]);

        long long ans = -(1LL << 62);
        if (bp != -INF) {                          // 有正数可选
            long long x = (ymin > 0 ? bp : sp);    // ymin = 0 时乘出来也是 0
            ans = max(ans, x * ymin);
        }
        if (bn != -INF) {                          // 有负数可选
            long long x = (ymax > 0 ? bn : sn);
            ans = max(ans, x * ymax);
        }
        if (zero) ans = max(ans, 0LL);
        printf("%lld\n", ans);
    }
    return 0;
}
