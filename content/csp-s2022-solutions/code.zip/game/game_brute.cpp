// CSP-S 2022 T2 策略游戏 —— 20 分：每轮 O(n*m) 暴力
// 覆盖测试点 1~5
#include <cstdio>
#include <algorithm>
using namespace std;

const int MAXN = 100005;
int n, m, q;
long long A[MAXN], B[MAXN];

int main() {
    scanf("%d %d %d", &n, &m, &q);
    for (int i = 1; i <= n; ++i) scanf("%lld", &A[i]);
    for (int i = 1; i <= m; ++i) scanf("%lld", &B[i]);
    while (q--) {
        int l1, r1, l2, r2;
        scanf("%d %d %d %d", &l1, &r1, &l2, &r2);
        long long ans = -(1LL << 60);
        for (int x = l1; x <= r1; ++x) {          // 小 L 选的行
            long long mn = (1LL << 60);           // 小 Q 在该行的最优（最小）取值
            for (int y = l2; y <= r2; ++y) mn = min(mn, A[x] * B[y]);
            ans = max(ans, mn);
        }
        printf("%lld\n", ans);
    }
    return 0;
}
