// CSP-S 2022 T2 策略游戏 —— 40 分（特殊性质 2：每轮 l1=r1 或 l2=r2）
// 一方的下标被固定，函数退化成单调，只需区间最值
// 覆盖测试点 1,3,6,9,10,13,16,17
#include <cstdio>
#include <algorithm>
using namespace std;

const int MAXN = 100005, LOGN = 18;
const int INF = 2100000000;
int n, m, q, lg[MAXN];
int mxA[LOGN][MAXN], mnA[LOGN][MAXN], mxB[LOGN][MAXN], mnB[LOGN][MAXN];
int A[MAXN], B[MAXN];

void build(int *a, int len, int st[LOGN][MAXN], bool isMax) {
    for (int i = 1; i <= len; ++i) st[0][i] = a[i];
    for (int j = 1; j < LOGN; ++j)
        for (int i = 1; i + (1 << j) - 1 <= len; ++i)
            st[j][i] = isMax ? max(st[j - 1][i], st[j - 1][i + (1 << (j - 1))])
                             : min(st[j - 1][i], st[j - 1][i + (1 << (j - 1))]);
}
int qry(int st[LOGN][MAXN], int l, int r, bool isMax) {
    int k = lg[r - l + 1];
    return isMax ? max(st[k][l], st[k][r - (1 << k) + 1])
                 : min(st[k][l], st[k][r - (1 << k) + 1]);
}

int main() {
    scanf("%d %d %d", &n, &m, &q);
    for (int i = 1; i <= n; ++i) scanf("%d", &A[i]);
    for (int i = 1; i <= m; ++i) scanf("%d", &B[i]);
    lg[1] = 0;
    for (int i = 2; i <= max(n, m); ++i) lg[i] = lg[i >> 1] + 1;
    build(A, n, mxA, true);  build(A, n, mnA, false);
    build(B, m, mxB, true);  build(B, m, mnB, false);
    while (q--) {
        int l1, r1, l2, r2;
        scanf("%d %d %d %d", &l1, &r1, &l2, &r2);
        long long ans;
        if (l1 == r1) {                       // A 固定：小 L 已无选择
            int a = A[l1];
            if (a > 0)       ans = 1LL * a * qry(mnB, l2, r2, false);
            else if (a < 0)  ans = 1LL * a * qry(mxB, l2, r2, true);
            else             ans = 0;
        } else {                              // 此时必有 l2 == r2，B 固定
            int b = B[l2];
            if (b > 0)       ans = 1LL * qry(mxA, l1, r1, true) * b;
            else if (b < 0)  ans = 1LL * qry(mnA, l1, r1, false) * b;
            else             ans = 0;
        }
        printf("%lld\n", ans);
    }
    return 0;
}
