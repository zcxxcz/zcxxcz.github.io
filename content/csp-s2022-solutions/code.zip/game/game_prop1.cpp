// CSP-S 2022 T2 策略游戏 —— 40 分（特殊性质 1：A_i, B_i 全为正）
// 答案 = max(A[l1..r1]) * min(B[l2..r2])
// 覆盖测试点 1,2,6,7,8,13,14,15
#include <cstdio>
#include <algorithm>
using namespace std;

const int MAXN = 100005, LOGN = 18;
int n, m, q, lg[MAXN];
int mxA[LOGN][MAXN], mnB[LOGN][MAXN];
int A[MAXN], B[MAXN];

int main() {
    scanf("%d %d %d", &n, &m, &q);
    for (int i = 1; i <= n; ++i) scanf("%d", &A[i]);
    for (int i = 1; i <= m; ++i) scanf("%d", &B[i]);
    lg[1] = 0;
    for (int i = 2; i <= max(n, m); ++i) lg[i] = lg[i >> 1] + 1;
    for (int i = 1; i <= n; ++i) mxA[0][i] = A[i];
    for (int i = 1; i <= m; ++i) mnB[0][i] = B[i];
    for (int j = 1; j < LOGN; ++j) {
        for (int i = 1; i + (1 << j) - 1 <= n; ++i)
            mxA[j][i] = max(mxA[j - 1][i], mxA[j - 1][i + (1 << (j - 1))]);
        for (int i = 1; i + (1 << j) - 1 <= m; ++i)
            mnB[j][i] = min(mnB[j - 1][i], mnB[j - 1][i + (1 << (j - 1))]);
    }
    while (q--) {
        int l1, r1, l2, r2;
        scanf("%d %d %d %d", &l1, &r1, &l2, &r2);
        int k1 = lg[r1 - l1 + 1], k2 = lg[r2 - l2 + 1];
        int ma = max(mxA[k1][l1], mxA[k1][r1 - (1 << k1) + 1]);
        int mb = min(mnB[k2][l2], mnB[k2][r2 - (1 << k2) + 1]);
        printf("%lld\n", 1LL * ma * mb);
    }
    return 0;
}
