// CSP-S 2022 T3 星战 —— 60 分：只维护"出度为 0 的点数"和活跃边数
// 覆盖测试点 1~12（11~12 有 t=2 但没有 t=4）
// 核心：若每个点出度恰为 1，则沿唯一出边走必然进环，第二个条件自动成立
#include <cstdio>
#include <vector>
#include <unordered_map>
using namespace std;

const int MAXN = 1000005;
int n, m, q;
int U[MAXN];
char alive[MAXN];
int outdeg[MAXN];
int zeroCnt;      // 出度为 0 的点数
long long cnt;    // 活跃边数
vector<int> inE[MAXN];
unordered_map<long long, int> eid;

static inline int readInt() {
    int x = 0, c = getchar_unlocked();
    while (c < '0' || c > '9') c = getchar_unlocked();
    while (c >= '0' && c <= '9') { x = x * 10 + (c - '0'); c = getchar_unlocked(); }
    return x;
}

int main() {
    n = readInt(); m = readInt();
    eid.reserve(m * 2 + 10);
    for (int i = 1; i <= m; ++i) {
        int u = readInt(), v = readInt();
        U[i] = u;
        alive[i] = 1;
        ++outdeg[u];
        inE[v].push_back(i);
        eid[1LL * u * (n + 1) + v] = i;
    }
    zeroCnt = 0;
    for (int i = 1; i <= n; ++i) if (outdeg[i] == 0) ++zeroCnt;
    cnt = m;
    q = readInt();
    while (q--) {
        int t = readInt(), u, v;
        if (t == 1 || t == 3) {
            u = readInt(); v = readInt();
            int id = eid[1LL * u * (n + 1) + v];
            if (t == 1) {
                alive[id] = 0; --cnt;
                if (--outdeg[u] == 0) ++zeroCnt;
            } else {
                alive[id] = 1; ++cnt;
                if (outdeg[u]++ == 0) --zeroCnt;
            }
        } else if (t == 2) {                 // 摧毁据点：删掉所有仍活着的入边
            u = readInt();
            for (int id : inE[u])
                if (alive[id]) {
                    alive[id] = 0; --cnt;
                    if (--outdeg[U[id]] == 0) ++zeroCnt;
                }
        } else {                             // 修复据点：所有被毁的入边一起回来
            u = readInt();
            for (int id : inE[u])
                if (!alive[id]) {
                    alive[id] = 1; ++cnt;
                    if (outdeg[U[id]]++ == 0) --zeroCnt;
                }
        }
        puts((zeroCnt == 0 && cnt == n) ? "YES" : "NO");
    }
    return 0;
}
