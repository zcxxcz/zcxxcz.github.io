// CSP-S 2022 T3 星战 —— 40 分：每次操作后 O(n) 重数出度
// 覆盖测试点 1~8（n <= 1000, q <= 1000）
#include <cstdio>
#include <vector>
#include <unordered_map>
using namespace std;

const int MAXN = 1000005;
int n, m, q;
int U[MAXN], V[MAXN];
char alive[MAXN];
int outdeg[MAXN];
vector<int> inE[MAXN];
unordered_map<long long, int> eid;

int main() {
    scanf("%d %d", &n, &m);
    eid.reserve(m * 2);
    for (int i = 1; i <= m; ++i) {
        int u, v; scanf("%d %d", &u, &v);
        U[i] = u; V[i] = v;
        alive[i] = 1;
        ++outdeg[u];
        inE[v].push_back(i);
        eid[1LL * u * (n + 1) + v] = i;
    }
    scanf("%d", &q);
    while (q--) {
        int t, u, v;
        scanf("%d", &t);
        if (t == 1 || t == 3) {
            scanf("%d %d", &u, &v);
            int id = eid[1LL * u * (n + 1) + v];
            if (t == 1) { alive[id] = 0; --outdeg[u]; }
            else        { alive[id] = 1; ++outdeg[u]; }
        } else if (t == 2) {          // 摧毁据点 u：所有指向 u 的边一起毁掉
            scanf("%d", &u);
            for (int id : inE[u])
                if (alive[id]) { alive[id] = 0; --outdeg[U[id]]; }
        } else {                      // 修复据点 u
            scanf("%d", &u);
            for (int id : inE[u])
                if (!alive[id]) { alive[id] = 1; ++outdeg[U[id]]; }
        }
        bool ok = true;
        for (int i = 1; i <= n; ++i)
            if (outdeg[i] != 1) { ok = false; break; }
        puts(ok ? "YES" : "NO");
    }
    return 0;
}
