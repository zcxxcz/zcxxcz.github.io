// CSP-S 2022 T3 星战 —— 100 分：随机权值哈希，把"每点出度 = 1"压成一个等式
//
// 判据：活跃边数 cnt == n 且 S == sum{w[i]}，其中 S = sum{ w[u] : u->v 当前可用 }
// 四种操作全部 O(1)：t=2 / t=4 是对"终点"的整批操作，用 curIn / delSum 做懒更新；
// 用"据点代数" genv 区分"被 t=1 单独删"和"被 t=2 整批摧毁"的入边。
#include <cstdio>
#include <cstdint>
#include <unordered_map>
using namespace std;

const int MAXN = 1000005;
int n, m, q;
int U[MAXN];
char del1[MAXN];             // 这条边是否被 t=1 单独删掉
int gen[MAXN];               // 它被删时所属的"据点代数"
uint64_t w[MAXN];            // 按起点计的随机权值
uint64_t sumW;
uint64_t S;
int inDeg[MAXN];             // 静态：指向 i 的边数
uint64_t sumIn[MAXN];        // 静态：指向 i 的边权值和
uint64_t curIn[MAXN];        // 当前活跃入边的权值和
int curCnt[MAXN];
uint64_t delSum[MAXN];       // 当前代里被 t=1 删掉的入边权值和
int delCnt[MAXN];
int genv[MAXN];              // 据点代数，t=2 / t=4 时自增，用来作废旧账本
unordered_map<long long, int> eid;

static inline int readInt() {
    int x = 0, c = getchar_unlocked();
    while (c < '0' || c > '9') c = getchar_unlocked();
    while (c >= '0' && c <= '9') { x = x * 10 + (c - '0'); c = getchar_unlocked(); }
    return x;
}

int main() {
    n = readInt(); m = readInt();
    uint64_t seed = 0x9E3779B97F4A7C15ULL;
    for (int i = 1; i <= n; ++i) {                 // splitmix64 随机权值
        seed += 0x9E3779B97F4A7C15ULL;
        uint64_t z = seed;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
        w[i] = (z ^ (z >> 31)) | 1ULL;
        sumW += w[i];
    }
    eid.reserve(m * 2 + 10);
    for (int i = 1; i <= m; ++i) {
        int u = readInt(), v = readInt();
        U[i] = u;
        ++inDeg[v]; sumIn[v] += w[u];
        curIn[v] += w[u]; ++curCnt[v];
        S += w[u];
        eid[1LL * u * (n + 1) + v] = i;
    }
    long long cnt = m;
    q = readInt();
    while (q--) {
        int t = readInt(), u, v, id;
        if (t == 1) {
            u = readInt(); v = readInt();
            id = eid[1LL * u * (n + 1) + v];
            del1[id] = 1; gen[id] = genv[v];
            S -= w[u]; --cnt;
            curIn[v] -= w[u]; --curCnt[v];
            delSum[v] += w[u]; ++delCnt[v];
        } else if (t == 3) {
            u = readInt(); v = readInt();
            id = eid[1LL * u * (n + 1) + v];
            S += w[u]; ++cnt;
            curIn[v] += w[u]; ++curCnt[v];
            if (del1[id] && gen[id] == genv[v]) {   // 只有本代账本里的才要销账
                del1[id] = 0;
                delSum[v] -= w[u]; --delCnt[v];
            }
        } else if (t == 2) {                        // 摧毁据点 v
            u = readInt();
            S -= curIn[u]; cnt -= curCnt[u];
            curIn[u] = 0; curCnt[u] = 0;
            delSum[u] = 0; delCnt[u] = 0;
            ++genv[u];                              // 旧账本作废
        } else {                                    // 修复据点 v：恢复所有入边
            u = readInt();
            S += sumIn[u] - curIn[u];
            cnt += inDeg[u] - curCnt[u];
            curIn[u] = sumIn[u]; curCnt[u] = inDeg[u];
            delSum[u] = 0; delCnt[u] = 0;
            ++genv[u];
        }
        puts((cnt == n && S == sumW) ? "YES" : "NO");
    }
    return 0;
}
