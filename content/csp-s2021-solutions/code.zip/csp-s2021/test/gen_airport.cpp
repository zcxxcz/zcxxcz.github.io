#include <bits/stdc++.h>
using namespace std;
int main(int argc, char** argv){
    int seed = argc>1? atoi(argv[1]) : 1;
    int MAXN = argc>2? atoi(argv[2]) : 20;
    mt19937 rng(seed);
    int n = rng()%MAXN + 1;
    int m1 = rng()%MAXN + 1;
    int m2 = rng()%MAXN + 1;
    int tot = m1+m2;
    // 生成 2*tot 个互不相同的时刻
    int LIM = 4*tot+10;
    vector<int> t(LIM);
    for(int i=0;i<LIM;i++) t[i]=i+1;
    shuffle(t.begin(), t.end(), rng);
    vector<pair<int,int>> fl(tot);
    for(int i=0;i<tot;i++){
        int x=t[2*i], y=t[2*i+1];
        if(x>y) swap(x,y);
        fl[i]={x,y};
    }
    shuffle(fl.begin(), fl.end(), rng);
    printf("%d %d %d\n", n, m1, m2);
    for(int i=0;i<m1;i++) printf("%d %d\n", fl[i].first, fl[i].second);
    for(int i=m1;i<tot;i++) printf("%d %d\n", fl[i].first, fl[i].second);
    return 0;
}
