// CSP-S 2021 T4 交通规划 —— 暴力（枚举 2^(n*m) 种染色），仅用于对拍 n,m<=4
#include <bits/stdc++.h>
using namespace std;
int n, m, T;
int X1[12][12], X2[12][12];
int ray2node(int p) {           // 射线编号 1-indexed -> 格点编号 0-indexed
    if (p <= m) return (p - 1);                                  // 上边 (1,p)
    if (p <= m + n) return (p - m - 1) * m + (m - 1);            // 右边 (p-m,m)
    if (p <= 2 * m + n) { int i = p - (m + n); return (n - 1) * m + (m - i); }  // 下边 (n,m-i+1)
    int i = p - (2 * m + n); return (n - i) * m + 0;             // 左边 (n-i+1,1)
}
int main() {
    scanf("%d %d %d", &n, &m, &T);
    for (int i = 1; i <= n - 1; i++) for (int j = 1; j <= m; j++) scanf("%d", &X1[i][j]);
    for (int i = 1; i <= n; i++) for (int j = 1; j <= m - 1; j++) scanf("%d", &X2[i][j]);
    while (T--) {
        int k; scanf("%d", &k);
        vector<int> nd(k), w(k), c(k);
        for (int i = 0; i < k; i++) {
            int x3, p, t; scanf("%d %d %d", &x3, &p, &t);
            nd[i] = ray2node(p); w[i] = x3; c[i] = t;
        }
        int N = n * m;
        long long ans = LLONG_MAX;
        for (long long mask = 0; mask < (1LL << N); mask++) {
            long long cost = 0;
            for (int i = 1; i <= n - 1; i++) for (int j = 1; j <= m; j++) {
                int u = (i - 1) * m + (j - 1), v = i * m + (j - 1);
                if (((mask >> u) & 1) != ((mask >> v) & 1)) cost += X1[i][j];
            }
            for (int i = 1; i <= n; i++) for (int j = 1; j <= m - 1; j++) {
                int u = (i - 1) * m + (j - 1), v = (i - 1) * m + j;
                if (((mask >> u) & 1) != ((mask >> v) & 1)) cost += X2[i][j];
            }
            for (int i = 0; i < k; i++)
                if (((mask >> nd[i]) & 1) != c[i]) cost += w[i];
            if (cost < ans) ans = cost;
        }
        printf("%lld\n", ans);
    }
    return 0;
}
