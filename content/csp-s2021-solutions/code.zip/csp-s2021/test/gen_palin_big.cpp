#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
    int seed=argc>1?atoi(argv[1]):1;
    int n=argc>2?atoi(argv[2]):500000;
    mt19937 rng(seed);
    vector<int> v; v.reserve(2*n);
    for(int i=1;i<=n;i++){ v.push_back(i); v.push_back(i); }
    shuffle(v.begin(),v.end(),rng);
    printf("1\n%d\n",n);
    for(int i=0;i<2*n;i++) printf("%d%c",v[i], i==2*n-1?'\n':' ');
}
