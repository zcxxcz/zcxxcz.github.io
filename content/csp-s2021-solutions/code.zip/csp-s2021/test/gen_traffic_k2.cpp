#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
    int seed=argc>1?atoi(argv[1]):1;
    int MAXNM=argc>2?atoi(argv[2]):4;
    int MAXW=argc>3?atoi(argv[3]):20;
    int Tn=argc>4?atoi(argv[4]):1;
    mt19937 rng(seed);
    int n=rng()%MAXNM+2, m=rng()%MAXNM+2;
    if(n*m>16){ n=2;m=2; }
    printf("%d %d %d\n",n,m,Tn);
    for(int i=1;i<=n-1;i++){ for(int j=1;j<=m;j++) printf("%d%c",(int)(rng()%MAXW), j==m?'\n':' '); }
    for(int i=1;i<=n;i++){ for(int j=1;j<=m-1;j++) printf("%d%c",(int)(rng()%MAXW), j==m-1?'\n':' '); }
    int R=2*n+2*m;
    for(int t=0;t<Tn;t++){
        vector<int> p(R); for(int i=0;i<R;i++) p[i]=i+1;
        shuffle(p.begin(),p.end(),rng);
        printf("2\n");
        printf("%d %d %d\n",(int)(rng()%MAXW), p[0], (int)(rng()%2));
        printf("%d %d %d\n",(int)(rng()%MAXW), p[1], (int)(rng()%2));
    }
}
