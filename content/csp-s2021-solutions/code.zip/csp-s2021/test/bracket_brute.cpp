// CSP-S 2021 T2 暴力：枚举所有 '?' 的填法，用题面 3 条规则直接判定合法性
#include <bits/stdc++.h>
using namespace std;
int n, K;
string s;
char t[64];
long long ans = 0;
long long nodes = 0;

bool isStar(int l, int r) {
    if (l > r) return false;
    if (r - l + 1 > K) return false;
    for (int i = l; i <= r; i++) if (t[i] != '*') return false;
    return true;
}
int vis[64][64]; bool val[64][64];
bool V(int l, int r) {
    if (l > r) return false;
    if (vis[l][r]) return val[l][r];
    vis[l][r] = 1;
    bool res = false;
    if (r == l + 1 && t[l] == '(' && t[r] == ')') res = true;                 // ()
    if (!res && t[l] == '(' && t[r] == ')' && isStar(l + 1, r - 1)) res = true; // (S)
    if (!res) for (int m = l; m < r; m++) if (V(l, m) && V(m + 1, r)) { res = true; break; } // AB
    if (!res) {                                                              // ASB
        for (int m1 = l; m1 < r && !res; m1++) {
            if (!V(l, m1)) continue;
            for (int m2 = m1 + 1; m2 < r; m2++)
                if (isStar(m1 + 1, m2 - 1) && V(m2, r)) { res = true; break; }
        }
    }
    if (!res && t[l] == '(' && t[r] == ')' && V(l + 1, r - 1)) res = true;    // (A)
    if (!res && t[l] == '(' && t[r] == ')') {                                 // (SA)
        for (int m = l + 1; m < r; m++) if (isStar(l + 1, m) && V(m + 1, r - 1)) { res = true; break; }
    }
    if (!res && t[l] == '(' && t[r] == ')') {                                 // (AS)
        for (int m = l + 1; m < r; m++) if (V(l + 1, m) && isStar(m + 1, r - 1)) { res = true; break; }
    }
    val[l][r] = res; return res;
}
void dfs(int p) {
    if (p == n) {
        nodes++;
        memset(vis, 0, sizeof vis);
        if (V(0, n - 1)) ans++;
        return;
    }
    if (s[p] != '?') { t[p] = s[p]; dfs(p + 1); return; }
    for (char c : string("()*")) { t[p] = c; dfs(p + 1); }
}
int main() {
    ios::sync_with_stdio(false);
    cin >> n >> K >> s;
    dfs(0);
    cout << ans % 1000000007LL << "\n";
    return 0;
}
