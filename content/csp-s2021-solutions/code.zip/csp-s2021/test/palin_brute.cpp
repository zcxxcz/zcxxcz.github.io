// CSP-S 2021 T3 回文 —— 暴力（枚举全部 2^(2n-1) 种操作串，取字典序最小的合法解）
#include <bits/stdc++.h>
using namespace std;
int n, a[40];
string best;
bool has = false;

void simulate(const string &ops) {
    int l = 0, r = 2 * n - 1;
    static int b[40];
    for (int i = 0; i < 2 * n; i++) {
        if (ops[i] == 'L') b[i] = a[l++];
        else b[i] = a[r--];
    }
    for (int i = 0; i < n; i++) if (b[i] != b[2 * n - 1 - i]) return;
    if (!has || ops < best) { best = ops; has = true; }
}

void dfs(int p, string &ops) {
    if (p == 2 * n) { simulate(ops); return; }
    ops[p] = 'L'; dfs(p + 1, ops);
    ops[p] = 'R'; dfs(p + 1, ops);
}

int main() {
    int T; scanf("%d", &T);
    while (T--) {
        scanf("%d", &n);
        for (int i = 0; i < 2 * n; i++) scanf("%d", &a[i]);
        has = false; best.clear();
        string ops(2 * n, 'L');
        dfs(0, ops);
        if (!has) puts("-1");
        else puts(best.c_str());
    }
    return 0;
}
