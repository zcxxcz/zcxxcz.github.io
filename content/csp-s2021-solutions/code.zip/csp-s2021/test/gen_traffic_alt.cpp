// 颜色严格交替的最坏情况
#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
    int seed=argc>1?atoi(argv[1]):1;
    int n=argc>2?atoi(argv[2]):500;
    int m=argc>3?atoi(argv[3]):500;
    int Tn=argc>4?atoi(argv[4]):1;
    int K=argc>5?atoi(argv[5]):50;
    mt19937 rng(seed);
    printf("%d %d %d\n",n,m,Tn);
    for(int i=1;i<=n-1;i++){ for(int j=1;j<=m;j++) printf("%d%c",(int)(rng()%1000000), j==m?'\n':' '); }
    for(int i=1;i<=n;i++){ for(int j=1;j<=m-1;j++) printf("%d%c",(int)(rng()%1000000), j==m-1?'\n':' '); }
    int R=2*n+2*m;
    for(int t=0;t<Tn;t++){
        int k=min(K,R);
        vector<int> p(R); for(int i=0;i<R;i++) p[i]=i+1;
        shuffle(p.begin(),p.end(),rng);
        vector<int> sel(p.begin(), p.begin()+k);
        sort(sel.begin(), sel.end());
        printf("%d\n",k);
        for(int i=0;i<k;i++) printf("%d %d %d\n",(int)(rng()%1000000), sel[i], i%2);
    }
}
