#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
    int seed=argc>1?atoi(argv[1]):1;
    int MAXN=argc>2?atoi(argv[2]):10;
    int QP=argc>3?atoi(argv[3]):60;   // 问号百分比
    mt19937 rng(seed);
    int n = rng()%MAXN + 2;
    int k = rng()%n + 1;
    string s;
    for(int i=0;i<n;i++){
        int r=rng()%100;
        if(r<QP) s+='?';
        else if(r<QP+(100-QP)/3) s+='(';
        else if(r<QP+2*(100-QP)/3) s+=')';
        else s+='*';
    }
    printf("%d %d\n%s\n",n,k,s.c_str());
}
