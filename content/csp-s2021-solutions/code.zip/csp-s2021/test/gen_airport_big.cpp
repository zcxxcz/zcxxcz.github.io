// 大测试生成：n / m1 / m2 由参数给定，时刻为 1e8 内互不相同的随机正整数
#include <bits/stdc++.h>
using namespace std;
int main(int argc, char** argv){
    int seed = argc>1? atoi(argv[1]) : 1;
    int n  = argc>2? atoi(argv[2]) : 100000;
    int m1 = argc>3? atoi(argv[3]) : 50000;
    int m2 = argc>4? atoi(argv[4]) : 50000;
    mt19937_64 rng(seed);
    int tot = m1+m2;
    vector<long long> t;
    t.reserve(2LL*tot);
    unordered_set<long long> used;
    used.reserve(4LL*tot);
    while((int)t.size() < 2*tot){
        long long x = rng()%100000000 + 1;
        if(used.insert(x).second) t.push_back(x);
    }
    vector<pair<long long,long long>> fl(tot);
    for(int i=0;i<tot;i++){
        long long x=t[2*i], y=t[2*i+1];
        if(x>y) swap(x,y);
        fl[i]={x,y};
    }
    shuffle(fl.begin(), fl.end(), rng);
    printf("%d %d %d\n", n, m1, m2);
    for(int i=0;i<m1;i++) printf("%lld %lld\n", fl[i].first, fl[i].second);
    for(int i=m1;i<tot;i++) printf("%lld %lld\n", fl[i].first, fl[i].second);
    return 0;
}
