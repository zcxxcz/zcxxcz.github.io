#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
    int seed=argc>1?atoi(argv[1]):1;
    int MAXN=argc>2?atoi(argv[2]):6;
    int TN=argc>3?atoi(argv[3]):1;
    mt19937 rng(seed);
    printf("%d\n",TN);
    for(int t=0;t<TN;t++){
        int n=rng()%MAXN+1;
        vector<int> v;
        for(int i=1;i<=n;i++){ v.push_back(i); v.push_back(i); }
        shuffle(v.begin(),v.end(),rng);
        printf("%d\n",n);
        for(int i=0;i<2*n;i++) printf("%d%c",v[i], i==2*n-1?'\n':' ');
    }
}
