// 构造必然有解的数据：先随机生成操作串，按剥离顺序得到位置序列 p，
// 再令 a[p[i]] = a[p[2n-1-i]] = i+1
#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
    int seed=argc>1?atoi(argv[1]):1;
    int n=argc>2?atoi(argv[2]):500000;
    mt19937 rng(seed);
    vector<int> p; p.reserve(2*n);
    int l=0,r=2*n-1;
    // 随机决定每步取左还是取右
    vector<char> ops(2*n);
    for(int i=0;i<2*n;i++){
        if(l>=r) ops[i]='L';
        else ops[i] = (rng()%2) ? 'L':'R';
        if(ops[i]=='L') p.push_back(l++); else p.push_back(r--);
    }
    vector<int> a(2*n,0);
    for(int i=0;i<n;i++){ a[p[i]]=i+1; a[p[2*n-1-i]]=i+1; }
    printf("1\n%d\n",n);
    for(int i=0;i<2*n;i++) printf("%d%c",a[i], i==2*n-1?'\n':' ');
}
