#include <bits/stdc++.h>
using namespace std;
int main(){ int T; scanf("%d",&T);
 while(T--){ int n; scanf("%d",&n); vector<int> a(2*n); for(auto&x:a) scanf("%d",&x);
  static char s[2000005]; scanf("%s",s);
  if(s[0]=='-'){ printf("NO-SOL\n"); continue; }
  int l=0,r=2*n-1; vector<int> b; b.reserve(2*n);
  for(int i=0;i<2*n;i++){ if(s[i]=='L') b.push_back(a[l++]); else b.push_back(a[r--]); }
  bool ok=true; for(int i=0;i<n;i++) if(b[i]!=b[2*n-1-i]) ok=false;
  printf("%s len=%zu\n", ok?"PALINDROME OK":"BAD", strlen(s));
 }}
