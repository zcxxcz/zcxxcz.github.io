#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
    int seed=argc>1?atoi(argv[1]):1; int n=argc>2?atoi(argv[2]):10; int Tn=argc>3?atoi(argv[3]):10;
    mt19937 rng(seed); printf("%d\n",Tn);
    for(int t=0;t<Tn;t++){
        vector<int> v; for(int i=1;i<=n;i++){v.push_back(i);v.push_back(i);} shuffle(v.begin(),v.end(),rng);
        printf("%d\n",n); for(int i=0;i<2*n;i++) printf("%d%c",v[i], i==2*n-1?'\n':' ');
    }
}
