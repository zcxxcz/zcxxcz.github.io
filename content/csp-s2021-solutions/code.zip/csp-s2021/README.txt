CSP-S 2021（第二轮）四题「部分分 → AC」配套代码
================================================

对应文章：《CSP-S 2021 四题详解：从部分分到 AC》

编译：全部代码用 g++ -O2 -std=c++14 编写，只用标准库，不需要任何扩展。
    g++ -O2 -std=c++14 -o t code/traffic_100.cpp
（本机验证用的是 Homebrew g++-15；CCF 评测机为 g++ -O2，代码不依赖编译器版本特性。）

目录
----
code/  各档位实现，文件名后缀就是该档的理论得分
  T1 廊桥分配 (P7913)  airport_20.cpp  / airport_40.cpp  / airport_100.cpp
  T2 括号序列 (P7914)  bracket_15.cpp / bracket_65.cpp / bracket_75.cpp / bracket_100.cpp
  T3 回文     (P7915)  palin_28.cpp   / palin_40.cpp   / palin_60.cpp   / palin_100.cpp
  T4 交通规划 (P7916)  traffic_40.cpp / traffic_60.cpp / traffic_80.cpp / traffic_100.cpp

  几处容易混的地方：
    bracket_75.cpp  是"65 分档 + 整串只有 ? 的一维 DP（测试点 14~15）"合在一个文件里，
                    读入后按"是否全是 ?"分派，所以它不是 65 分档的替代品，而是它的超集。
    palin_40.cpp    枚举前一半 2^n 种操作（后一半由回文条件唯一确定），n <= 20 有效。
    traffic_40/60   是同一份 Dinic，唯一区别是 MAXV/MAXE/权值表的大小；
                    40 分档在 n,m = 100 时会数组越界直接 RE。
    traffic_80.cpp  按 k 分派：k <= 2 走对偶图 Dijkstra，k > 2 回退 Dinic。

test/  对拍与验证用的独立程序
  gen_airport.cpp  gen_airport_big.cpp          T1 生成器（随机时刻 / 大测试）
  bracket_brute.cpp  gen_bracket.cpp            T2 暴力判定 + 生成器
  palin_brute.cpp  gen_palin.cpp                T3 暴力枚举 + 生成器
  gen_palin_sol.cpp  gen_palin_big.cpp          T3 "保证有解"的构造器 / 大规模
  gen_palin_T10.cpp                             T3 多组小数据（模拟 28 分档的测试结构）
  check_palin.cpp                               T3 单点检查器：验证输出是合法回文
  traffic_brute.cpp  gen_traffic.cpp            T4 暴力枚举 2^(nm) 种染色 + 生成器
  gen_traffic_T.cpp  gen_traffic_alt.cpp        T4 多询问 / 严格交替色
  gen_traffic_k2.cpp  gen_traffic_big.cpp       T4 k=2 专项 / 大规模

各题的"暴力"拿谁当基准
----------------------
  T1  code/airport_20.cpp   —— 枚举 n 个廊桥的每一种分配，各自模拟，本身就是暴力
  T2  test/bracket_brute.cpp —— 枚举所有 '?' 的填法，再按题面三条规则递归判定
  T3  test/palin_brute.cpp   —— 枚举 2^(2n) 个操作串；用 check_palin.cpp 逐位校验
  T4  test/traffic_brute.cpp —— 枚举 2^(nm) 种染色，取最小代价

怎么对拍（以 T1 为例，其余三题把文件换掉即可）
----------------------------------------------
    g++ -O2 -std=c++14 -o gen   test/gen_airport.cpp
    g++ -O2 -std=c++14 -o brute code/airport_20.cpp
    g++ -O2 -std=c++14 -o a40   code/airport_40.cpp
    g++ -O2 -std=c++14 -o a100  code/airport_100.cpp

    for i in $(seq 1 100); do
      ./gen > in.txt
      ./brute < in.txt > o0.txt
      ./a40   < in.txt > o1.txt
      ./a100  < in.txt > o2.txt
      cmp -s o0.txt o1.txt && cmp -s o0.txt o2.txt || { echo "WA on $i"; break; }
    done

T2/T3/T4 同理。生成器的参数（数据规模、颜色数、问号比例、组数）都在各 gen_*.cpp 的
main 里用常量写死，需要别的规模直接改那几个常量重新编译。

本机实测（Apple M 系列，比 CCF 评测机快 2~3 倍，看时间请打折）
--------------------------------------------------------------
  airport_20.cpp    n=m=100                     < 0.01s
  airport_40.cpp    n=m=5000                      0.27s
  airport_100.cpp   n=m=1e5                       0.02s
  bracket_15.cpp    n=15 全 '?'                   0.12s
  bracket_65.cpp    n=100                         0.01s   （n=500 -> 1.73s 超时，正是它只能拿 65 分的原因）
  bracket_100.cpp   n=500 全 '?'                  0.05s
  palin_28.cpp      T=10, n=10                    0.50s
  palin_60.cpp      n=5e5                        14.65s   （超时）
  palin_100.cpp     n=5e5                         0.04s
  traffic_40.cpp    n=m=18, k=50                  0.01s
  traffic_70.cpp    n=m=500, T=25, k=2            0.36s
  traffic_100.cpp   n=m=500, k=50 交替色          1.22s

对拍规模：T1 450 组、T2 740 组、T3 850 组、T4 900 组，全部通过。
