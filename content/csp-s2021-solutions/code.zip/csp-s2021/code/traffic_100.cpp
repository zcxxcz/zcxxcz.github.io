// CSP-S 2021 T4 交通规划 —— 100 分
// 平面图最小割 -> 对偶图最短路；多色时按"颜色变化处"配对 + 区间 DP。
//
// 建模：
//   把原网格的每个小方格看成一个"内部面"(共 (n-1)(m-1) 个)，对偶边权 = 原边权。
//   外部面被 k 个附加点所在的射线切成 k 个"扇区"，扇区 s 从射线 pts[s] 顺时针到 pts[s+1]，
//   它覆盖的那段边界上的每条边界边，都在对偶图里连一条边到边界内侧的内部面。
//   相邻扇区之间隔着一条射线，通过该射线上附加点的边（权 x3）相连。
//   于是"把黑附加点和白附加点分开的最小割" = 对偶图上若干条互不相交路径的长度和。
//
// 求法：
//   只有颜色发生变化的扇区（左端颜色 != 右端颜色）才需要被割线穿过，这样的扇区有偶数个。
//   设它们按环序为 0..q-1，类型 t[i]（0->1 或 1->0）。配对必须"类型相反"，且最优解里
//   各条路径两两不相交 => 合法的配对就是环上的括号匹配 => 破环为链后区间 DP。
#include <bits/stdc++.h>
using namespace std;

const int MAXN = 505;
const int MAXV = MAXN * MAXN + 64;
const long long INF = (long long)1e18;

int n, m, T;
int X1[MAXN][MAXN];   // X1[i][j]: (i,j)-(i+1,j) 竖直边
int X2[MAXN][MAXN];   // X2[i][j]: (i,j)-(i,j+1) 水平边
int V0;               // 内部面个数

struct E { int to, w; };
vector<E> g[MAXV];

inline void addE(int u, int v, int w) {
    g[u].push_back({v, w});
    g[v].push_back({u, w});
}
inline int fid(int i, int j) { return (i - 1) * (m - 1) + j; }   // i in [1,n-1], j in [1,m-1]

int posF[MAXN * 4];   // 每个"位置"对应的内部面（0 = 角点，没有边界边）
int posW[MAXN * 4];

long long dist[MAXV];
int seen[MAXV], seenTag = 0;
typedef pair<long long, int> pli;

void dijkstra(int src, int V) {
    ++seenTag;
    for (int i = 1; i <= V; i++) dist[i] = INF;
    priority_queue<pli, vector<pli>, greater<pli> > pq;
    dist[src] = 0;
    pq.push({0, src});
    while (!pq.empty()) {
        pli t = pq.top(); pq.pop();
        int u = t.second;
        if (seen[u] == seenTag && dist[u] < t.first) continue;
        seen[u] = seenTag;
        for (size_t i = 0; i < g[u].size(); i++) {
            int v = g[u][i].to, w = g[u][i].w;
            if (dist[u] + w < dist[v]) { dist[v] = dist[u] + w; pq.push({dist[v], v}); }
        }
    }
}

int main() {
    if (scanf("%d %d %d", &n, &m, &T) != 3) return 0;
    for (int i = 1; i <= n - 1; i++)
        for (int j = 1; j <= m; j++) scanf("%d", &X1[i][j]);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m - 1; j++) scanf("%d", &X2[i][j]);

    V0 = (n - 1) * (m - 1);
    // 内部面之间的对偶边
    for (int i = 1; i <= n - 1; i++)
        for (int j = 1; j <= m - 1; j++) {
            if (i + 1 <= n - 1) addE(fid(i, j), fid(i + 1, j), X2[i + 1][j]);
            if (j + 1 <= m - 1) addE(fid(i, j), fid(i, j + 1), X1[i][j + 1]);
        }

    // 射线编号（0-indexed）：上 0..m-1，右 m..m+n-1，下 m+n..2m+n-1，左 2m+n..2m+2n-1
    // 位置 p 表示"射线 p 与射线 p+1 之间"的那段边界
    int N = 2 * m + 2 * n;
    for (int p = 0; p < N; p++) { posF[p] = 0; posW[p] = 0; }
    for (int p = 0; p <= m - 2; p++) { posF[p] = fid(1, p + 1); posW[p] = X2[1][p + 1]; }        // 上
    for (int p = m; p <= m + n - 2; p++) { int i = p - m + 1; posF[p] = fid(i, m - 1); posW[p] = X1[i][m]; } // 右
    for (int p = m + n; p <= 2 * m + n - 2; p++) { int c = 2 * m + n - p; posF[p] = fid(n - 1, c - 1); posW[p] = X2[n][c - 1]; } // 下
    for (int p = 2 * m + n; p <= 2 * m + 2 * n - 2; p++) { int r = 2 * m + 2 * n - p; posF[p] = fid(r - 1, 1); posW[p] = X1[r - 1][1]; } // 左

    vector<int> pp, x3, col;
    vector<int> dynBase;          // 动态结点，每轮清空它们的边
    vector<int> touched;          // 被加过"指向动态结点"的边的内部面，每轮要把这些边删掉
    while (T--) {
        // 清掉上一轮挂在内部面上的动态边
        for (size_t i = 0; i < touched.size(); i++) {
            int f = touched[i];
            size_t w = 0;
            for (size_t j = 0; j < g[f].size(); j++)
                if (g[f][j].to <= V0) g[f][w++] = g[f][j];
            g[f].resize(w);
        }
        touched.clear();
        for (size_t i = 0; i < dynBase.size(); i++) g[dynBase[i]].clear();
        dynBase.clear();

        int k; scanf("%d", &k);
        pp.resize(k); x3.resize(k); col.resize(k);
        for (int i = 0; i < k; i++) {
            scanf("%d %d %d", &x3[i], &pp[i], &col[i]);
            pp[i]--;                // 转 0-indexed
        }
        // 按射线编号排序（环序）
        vector<int> ord(k);
        for (int i = 0; i < k; i++) ord[i] = i;
        sort(ord.begin(), ord.end(), [&](int a, int b) { return pp[a] < pp[b]; });
        vector<int> P(k), C(k), W(k);
        for (int i = 0; i < k; i++) { P[i] = pp[ord[i]]; C[i] = col[ord[i]]; W[i] = x3[ord[i]]; }

        int V = V0 + k;
        for (int s = 0; s < k; s++) { int u = V0 + 1 + s; g[u].clear(); dynBase.push_back(u); }

        // 扇区 s：从射线 P[s] 顺时针到射线 P[(s+1)%k]
        for (int s = 0; s < k; s++) {
            int u = V0 + 1 + s;
            int a = P[s], b = P[(s + 1) % k];
            int t = a;
            while (t != b) {
                if (posF[t]) { addE(u, posF[t], posW[t]); touched.push_back(posF[t]); }
                t = (t + 1) % N;
            }
        }
        // 相邻扇区之间：穿过射线上附加点的边
        for (int i = 0; i < k; i++) {
            int prev = (i - 1 + k) % k;
            addE(V0 + 1 + prev, V0 + 1 + i, W[i]);
        }

        // 收集"颜色变化"的扇区
        vector<int> node;   // 对偶图结点
        vector<int> typ;    // 0: c[s]=0,c[s+1]=1   1: c[s]=1,c[s+1]=0
        for (int s = 0; s < k; s++) {
            int c1 = C[s], c2 = C[(s + 1) % k];
            if (c1 != c2) { node.push_back(V0 + 1 + s); typ.push_back(c1 == 0 ? 0 : 1); }
        }
        int q = (int)node.size();
        if (q == 0) { puts("0"); continue; }

        // 两两最短路
        vector<vector<long long> > D(q, vector<long long>(q, INF));
        for (int i = 0; i < q; i++) {
            dijkstra(node[i], V);
            for (int j = 0; j < q; j++) D[i][j] = dist[node[j]];
        }

        // 环上区间 DP：破环为链，答案取长度 q 的窗口最小值
        int L = 2 * q;
        vector<vector<long long> > f(L + 1, vector<long long>(L + 1, INF));
        for (int len = 2; len <= q; len += 2) {
            for (int l = 0; l + len - 1 < L; l++) {
                int r = l + len - 1;
                long long best = INF;
                if (typ[l % q] != typ[r % q]) {
                    long long inner = (len == 2) ? 0 : f[l + 1][r - 1];
                    if (inner < INF && D[l % q][r % q] < INF) best = min(best, inner + D[l % q][r % q]);
                }
                for (int kk = l + 1; kk < r; kk += 2)
                    if (f[l][kk] < INF && f[kk + 1][r] < INF) best = min(best, f[l][kk] + f[kk + 1][r]);
                f[l][r] = best;
            }
        }
        long long ans = INF;
        for (int l = 0; l < q; l++) ans = min(ans, f[l][l + q - 1]);
        printf("%lld\n", ans);
    }
    return 0;
}
