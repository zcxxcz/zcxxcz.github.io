// CSP-S 2021 T3 回文 —— 60 分档（测试点 1~15，n <= 1000）
// 思路与正解完全一致（四指针同时定第 i / 第 2n+1-i 次操作），
// 但用 vector 保存两段并在取数时 erase(begin())，单次 O(n) -> 总 O(n^2)。
// n <= 1000 时约 1e6 次搬移，秒过；n = 5e5 时约 2.5e11，必然超时。
#include <bits/stdc++.h>
using namespace std;

int n;
vector<int> A;
vector<int> other_pos;

bool build(vector<int> L, vector<int> R, char first, string &ans) {
    ans.assign(2 * n, '?');
    ans[0] = first;
    ans[2 * n - 1] = 'L';
    for (int i = 1; i < n; i++) {
        int j = 2 * n - 1 - i;
        bool okL = !L.empty(), okR = !R.empty();
        if (L.size() >= 2 && L.front() == L.back()) {                    // L 左端 + L 右端
            ans[i] = 'L'; ans[j] = 'L';
            L.erase(L.begin()); L.pop_back();
        } else if (okL && okR && L.front() == R.front()) {               // L 左端 + R 左端
            ans[i] = 'L'; ans[j] = 'R';
            L.erase(L.begin()); R.erase(R.begin());
        } else if (okL && okR && R.back() == L.back()) {                 // R 右端 + L 右端
            ans[i] = 'R'; ans[j] = 'L';
            R.pop_back(); L.pop_back();
        } else if (R.size() >= 2 && R.back() == R.front()) {             // R 右端 + R 左端
            ans[i] = 'R'; ans[j] = 'R';
            R.pop_back(); R.erase(R.begin());
        } else return false;
    }
    return true;
}

void solve() {
    scanf("%d", &n);
    A.assign(2 * n, 0);
    for (int i = 0; i < 2 * n; i++) scanf("%d", &A[i]);

    vector<int> firstpos(n + 1, -1);
    other_pos.assign(2 * n, -1);
    for (int i = 0; i < 2 * n; i++) {
        if (firstpos[A[i]] == -1) firstpos[A[i]] = i;
        else { other_pos[firstpos[A[i]]] = i; other_pos[i] = firstpos[A[i]]; }
    }

    string ans1, ans2;
    bool ok1 = false, ok2 = false;
    {
        int pos = other_pos[0];
        if (pos > 0) {
            vector<int> L(A.begin() + 1, A.begin() + pos);
            vector<int> R(A.begin() + pos + 1, A.end());
            ok1 = build(L, R, 'L', ans1);
        }
    }
    {
        int pos = other_pos[2 * n - 1];
        if (pos < 2 * n - 1) {
            vector<int> L(A.begin(), A.begin() + pos);
            vector<int> R(A.begin() + pos + 1, A.end() - 1);
            ok2 = build(L, R, 'R', ans2);
        }
    }
    if (!ok1 && !ok2) puts("-1");
    else if (ok1 && ok2) puts((ans1 < ans2 ? ans1 : ans2).c_str());
    else puts((ok1 ? ans1 : ans2).c_str());
}

int main() {
    int T; scanf("%d", &T);
    while (T--) solve();
    return 0;
}
