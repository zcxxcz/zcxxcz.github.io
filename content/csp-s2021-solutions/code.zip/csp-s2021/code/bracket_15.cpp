// CSP-S 2021 T2 括号序列 —— 15 分档（测试点 1~3，n <= 15）
// 做法：直接枚举每个 '?' 填 '('/')'/'*'，每得到完整串用"题面 3 条规则"的递归判定检查。
// 为了不真的跑到 3^n，加了 4 条必要剪枝（都是合法串必须满足的）：
//   1. 任意前缀里 '(' 的个数不少于 ')' 的个数；
//   2. 连续的 '*' 不超过 k 个；
//   3. 第一个字符不能是 ')'，最后一个字符必须是 ')'；
//   4. 剩下的位置不够把未匹配的 '(' 全部闭合时直接回溯。
// 判定函数 V(l,r) 直接照抄题面规则（带记忆化），与后面的 DP 完全独立。
#include <bits/stdc++.h>
using namespace std;

int n, K;
char s[64], t[64];
long long ans = 0;
int vis[64][64];
bool val[64][64];

inline bool isStar(int l, int r) {
    if (l > r || r - l + 1 > K) return false;
    for (int i = l; i <= r; i++) if (t[i] != '*') return false;
    return true;
}

// [l,r] 是否是"符合规范的超级括号序列"
bool V(int l, int r) {
    if (l > r) return false;
    if (vis[l][r]) return val[l][r];
    vis[l][r] = 1;
    bool res = false;
    if (r == l + 1 && t[l] == '(' && t[r] == ')') res = true;                  // ()
    if (!res && t[l] == '(' && t[r] == ')' && isStar(l + 1, r - 1)) res = true; // (S)
    if (!res)                                                                  // AB
        for (int m = l; m < r && !res; m++) if (V(l, m) && V(m + 1, r)) res = true;
    if (!res)                                                                  // ASB
        for (int m1 = l; m1 < r && !res; m1++) {
            if (!V(l, m1)) continue;
            for (int m2 = m1 + 1; m2 < r; m2++)
                if (isStar(m1 + 1, m2 - 1) && V(m2, r)) { res = true; break; }
        }
    if (!res && t[l] == '(' && t[r] == ')' && V(l + 1, r - 1)) res = true;      // (A)
    if (!res && t[l] == '(' && t[r] == ')')                                    // (SA)
        for (int m = l + 1; m < r && !res; m++) if (isStar(l + 1, m) && V(m + 1, r - 1)) res = true;
    if (!res && t[l] == '(' && t[r] == ')')                                    // (AS)
        for (int m = l + 1; m < r && !res; m++) if (V(l + 1, m) && isStar(m + 1, r - 1)) res = true;
    val[l][r] = res;
    return res;
}

void dfs(int p, int bal, int star) {   // bal: 未匹配的 '(' 数, star: 当前连续 '*' 数
    if (bal > n - p) return;                         // 剩下的位置不够闭合
    if (p == n) {
        if (bal != 0 || t[n - 1] != ')') return;     // 合法串必须以 ')' 结尾
        memset(vis, 0, sizeof vis);
        if (V(0, n - 1)) ans++;
        return;
    }
    char lo = '(', hi = ')';
    char cand[3] = { '(', ')', '*' };
    for (int id = 0; id < 3; id++) {
        char c = cand[id];
        if (s[p] != '?' && s[p] != c) continue;
        if (p == 0 && c == ')') continue;            // 不能以 ')' 开头
        if (c == ')' && bal == 0) continue;          // 无括号可匹配
        if (c == '*' && star + 1 > K) continue;      // 星串超长
        t[p] = c;
        dfs(p + 1, c == '(' ? bal + 1 : (c == ')' ? bal - 1 : bal), c == '*' ? star + 1 : 0);
    }
}

int main() {
    if (scanf("%d %d %s", &n, &K, s) != 3) return 0;
    dfs(0, 0, 0);
    printf("%lld\n", ans % 1000000007LL);
    return 0;
}
