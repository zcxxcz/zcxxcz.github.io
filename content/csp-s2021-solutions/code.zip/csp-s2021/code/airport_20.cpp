// CSP-S 2021 T1 廊桥分配 —— 20 分档（n,m1+m2 <= 100）
// 做法：枚举分给国内区的廊桥数 x = 0..n，两边分别 O(m*min(x,m)) 暴力模拟。
// 复杂度 O(n * m * n)，在 n,m <= 100 时约 1e6 次操作。
#include <bits/stdc++.h>
using namespace std;

int n, m1, m2;
struct Fl { int a, b; };           // a: 抵达时刻, b: 离开时刻
vector<Fl> u, v;                   // 国内 / 国际航班

bool cmpA(const Fl &x, const Fl &y) { return x.a < y.a; }

// t 已按抵达时刻升序。k 个廊桥时能停靠的航班数。
int calc(const vector<Fl> &t, int k) {
    if (k == 0) return 0;
    vector<int> fre(k, 0);         // fre[i] = 第 i 个廊桥下次空闲的时刻（0 表示一直空着）
    int c = 0;
    for (const auto &f : t) {
        for (int i = 0; i < k; i++) {
            if (fre[i] < f.a) {    // 时刻互不相同，等价于 <=
                fre[i] = f.b;      // 占用到 b 时刻
                c++;
                break;             // 有桥就停，"先到先得"，编号不影响结果
            }
        }
    }
    return c;
}

int main() {
    if (scanf("%d %d %d", &n, &m1, &m2) != 3) return 0;
    u.resize(m1); v.resize(m2);
    for (auto &x : u) scanf("%d %d", &x.a, &x.b);
    for (auto &x : v) scanf("%d %d", &x.a, &x.b);
    sort(u.begin(), u.end(), cmpA);
    sort(v.begin(), v.end(), cmpA);

    int ans = 0;
    for (int x = 0; x <= n; x++) {
        int cur = calc(u, x) + calc(v, n - x);
        if (cur > ans) ans = cur;
    }
    printf("%d\n", ans);
    return 0;
}
