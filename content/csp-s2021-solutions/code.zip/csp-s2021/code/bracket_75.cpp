// CSP-S 2021 T2 括号序列 —— 75 分档
//   覆盖：测试点 1~13（n <= 100，O(n^4) 区间 DP）
//      + 测试点 14~15（n = 500，但整串只由 '?' 组成）
// 关键：14~15 的 n 同样是 500，用 O(n^4) 必超时；但"整串都是 '?'"时，
//   填法数量只跟长度 n 和 k 有关，跟具体字符无关 —— 一维的"按长度计数"DP 就够，
//   O(n^2) 跑完，30 行代码换 10 分。
//   提交策略：读入后判断是否全是 '?'，是就走一维 DP（分支一），否则走 O(n^4)（分支二）。
#include <bits/stdc++.h>
using namespace std;

const int MOD = 1000000007;
int n, K;
char s[505];

// ===================== 分支一：整串只由 '?' 组成 =====================
// 沿用块分解的思路，但因为没有具体字符，"是不是合法串"只取决于长度。
//   f[i] : 长度 i 的合法串个数
//   h[i] : 长度 i 的"单个括号块" (X) 的个数
//   q[i] : 长度 i 的"块 + 非空星尾" (X)S 的个数
long long f[505], h[505], q[505];

void solveAllQ() {
    f[0] = f[1] = 0;                 // 空串不算合法串（只在 (A) 里用，而 A 非空）
    for (int i = 2; i <= n; i++) {
        int c = i - 2;                              // 最外层括号内部的长度
        long long hv = 0;
        if (c == 0) hv += 1;                        // ()
        if (c >= 1 && c <= K) hv += 1;              // (S)，S 非空且长度 <= k
        if (c >= 2) hv += f[c];                     // (A)
        int lim = min(K, c - 2);                    // (SA) 与 (AS)
        for (int t = 1; t <= lim; t++) hv += 2 * f[c - t] % MOD;
        h[i] = hv % MOD;

        long long qv = 0;                           // (X) 后面接长度 1..k 的星串
        for (int j = 2; j <= i - 1; j++)
            if (i - j >= 1 && i - j <= K) qv += h[j];
        q[i] = qv % MOD;

        long long fv = h[i];                        // 整串就是一块（不能以星结尾）
        for (int j = 2; j <= i - 2; j++)            // 第一块（可带星尾）+ 剩下的合法串
            fv += (h[j] + q[j]) % MOD * f[i - j] % MOD;
        f[i] = fv % MOD;
    }
    printf("%lld\n", f[n] % MOD);
}

// ===================== 分支二：普通串，O(n^4) =====================
long long E[505][505], L[505][505];
bool Sg[505][505];

inline bool cOpen(char c) { return c == '(' || c == '?'; }
inline bool cClose(char c) { return c == ')' || c == '?'; }
inline bool cStar(char c) { return c == '*' || c == '?'; }

void solveGeneral() {
    for (int i = 1; i <= n; i++) {
        bool all = true;
        for (int j = i; j <= n; j++) {
            if (!cStar(s[j])) all = false;
            Sg[i][j] = all && (j - i + 1 <= K);
        }
    }

    for (int len = 1; len <= n; len++) {
        for (int i = 1; i + len - 1 <= n; i++) {
            int j = i + len - 1;

            long long l = 0;
            if (len >= 2 && cOpen(s[i]) && cClose(s[j])) {
                int a = i + 1, b = j - 1;
                if (len == 2) l = 1;
                else {
                    l += Sg[a][b];
                    l += E[a][b];
                    for (int m = a; m < b; m++) {
                        l += Sg[a][m] * E[m + 1][b] % MOD;
                        l += E[a][m] * Sg[m + 1][b] % MOD;
                    }
                }
                l %= MOD;
            }
            L[i][j] = l;

            long long e = L[i][j];
            for (int a = i; a < j; a++) {
                if (!L[i][a]) continue;
                for (int b = a; b < j; b++) {
                    long long mid = (b == a) ? 1 : (Sg[a + 1][b] ? 1 : 0);
                    if (!mid || !E[b + 1][j]) continue;
                    e += L[i][a] * mid % MOD * E[b + 1][j] % MOD;
                }
            }
            E[i][j] = e % MOD;
        }
    }
    printf("%lld\n", E[1][n] % MOD);
}

int main() {
    if (scanf("%d %d %s", &n, &K, s + 1) != 3) return 0;

    bool allQ = true;
    for (int i = 1; i <= n; i++) if (s[i] != '?') { allQ = false; break; }

    if (allQ) solveAllQ();
    else solveGeneral();
    return 0;
}
