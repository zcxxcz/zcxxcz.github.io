// CSP-S 2021 T2 括号序列 —— 100 分（n <= 500）
// 关键观察：任何"符合规范的超级括号序列"都以 '(' 开头、以 ')' 结尾。
//   所以整串可以唯一地切成若干"块"，每块形如  ( X )  或  ( X ) S
//   其中 X ∈ { 空, S, A, SA, AS }（A 为合法串，S 为非空且长度 <= k 的星串）。
// 记：
//   Sg[i][j] : [i,j] 本身是一个合法星串（非空、长度 <= k、全是 '*' 或 '?'）
//   L[i][j]  : [i,j] 恰好是"一块括号" ( X )
//   N[i][j]  : [i,j] 是"一块括号 + 尾部星串" ( X ) S
//   P[i][j]  : L + N（"一个块"，可能带星尾）
//   E[i][j]  : [i,j] 是合法串（若干块拼起来）
// 转移见下方注释。复杂度 O(n^3)。
#include <bits/stdc++.h>
using namespace std;

const int MOD = 1000000007;
int n, K;
char s[505];
long long E[505][505], L[505][505], Nn[505][505], P[505][505];
bool Sg[505][505];

inline bool cOpen(char c) { return c == '(' || c == '?'; }
inline bool cClose(char c) { return c == ')' || c == '?'; }
inline bool cStar(char c) { return c == '*' || c == '?'; }

int main() {
    if (scanf("%d %d %s", &n, &K, s + 1) != 3) return 0;

    // 预处理星串
    for (int i = 1; i <= n; i++) {
        bool all = true;
        for (int j = i; j <= n; j++) {
            if (!cStar(s[j])) all = false;
            Sg[i][j] = all && (j - i + 1 <= K);
        }
    }

    for (int len = 1; len <= n; len++) {
        for (int i = 1; i + len - 1 <= n; i++) {
            int j = i + len - 1;
            long long l = 0, nn = 0, e = 0;

            // ---- L[i][j]：最外层一对括号恰好包住 [i,j] ----
            if (len >= 2 && cOpen(s[i]) && cClose(s[j])) {
                int a = i + 1, b = j - 1;
                if (len == 2) l = 1;                       // ()
                else {
                    l += Sg[a][b];                         // (S)
                    l += E[a][b];                          // (A)
                    for (int m = a; m < b; m++) {
                        l += Sg[a][m] * E[m + 1][b] % MOD;  // (SA)：前面星串，后面合法串
                        l += E[a][m] * Sg[m + 1][b] % MOD;  // (AS)：前面合法串，后面星串
                    }
                }
                l %= MOD;
            }
            L[i][j] = l % MOD;

            // ---- N[i][j]：(X) 后接一段非空星串 ----
            for (int m = i + 1; m < j; m++)
                if (L[i][m] && Sg[m + 1][j])
                    nn += L[i][m] * Sg[m + 1][j] % MOD;
            Nn[i][j] = nn % MOD;

            P[i][j] = (L[i][j] + Nn[i][j]) % MOD;

            // ---- E[i][j]：合法串必须以 ')' 结尾，所以不能停在"带星尾的块"上 ----
            // 只有单个括号块 L 可以直接结束；(X)S 后面必须再接块
            e = L[i][j];
            for (int m = i; m < j; m++)
                if (P[i][m] && E[m + 1][j])
                    e += P[i][m] * E[m + 1][j] % MOD;
            E[i][j] = e % MOD;
        }
    }
    printf("%lld\n", E[1][n] % MOD);
    return 0;
}
