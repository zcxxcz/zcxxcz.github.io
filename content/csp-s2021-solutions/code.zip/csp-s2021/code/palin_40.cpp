// CSP-S 2021 T3 回文 —— 40 分档（测试点 1~10，n <= 20）
// 思路（比 28 分档的 2^(2n) 枚举少枚举一半）：
//   b 是回文 => 第 j 次取出的数必须等于第 2n-1-j 次取出的数。
//   也就是说，只要前 n 次操作（L/R）定下来，后 n 次要取的值就唯一确定了 ——
//   正好是前 n 个值的逆序。
//   于是 DFS 枚举 2^n 种前一半操作（先试 L，保证找到的就是字典序最小），
//   再把剩下的区间用"两端取数"去凑那个逆序序列，第一次成功即为答案。
// 为什么只能拿 40 分：2^n 枚举，n <= 20 时 10^6 级别可以接受，n = 1000 时 2^1000 完全不可能。
//   （60 分档用的是"每轮四种组合按字典序试"的贪心，O(n^2)；100 分档是 O(n)。）
#include <bits/stdc++.h>
using namespace std;

int n;
vector<int> a, b, need;
string pre, ans;
bool found;

// 从区间 [l,r] 里按 need[i..n-1] 的顺序取数（每次只能取左端或右端），字典序优先 L。
bool takeRest(int l, int r, int i, string &suf) {
    if (i == n) return true;
    if (l > r) return false;
    if (a[l] == need[i]) {
        suf += 'L';
        if (takeRest(l + 1, r, i + 1, suf)) return true;
        suf.pop_back();
    }
    if (r != l && a[r] == need[i]) {
        suf += 'R';
        if (takeRest(l, r - 1, i + 1, suf)) return true;
        suf.pop_back();
    }
    return false;
}

void dfs(int i, int l, int r) {     // 前 i 次操作已定，剩余区间 [l,r]
    if (found) return;
    if (i == n) {
        for (int j = 0; j < n; j++) need[j] = b[n - 1 - j];   // 后一半要取的值（逆序）
        string suf;
        if (takeRest(l, r, 0, suf)) { ans = pre + suf; found = true; }
        return;
    }
    b[i] = a[l]; pre += 'L';        // 先试 L，保证字典序最小
    dfs(i + 1, l + 1, r);
    pre.pop_back();
    if (found) return;
    b[i] = a[r]; pre += 'R';
    dfs(i + 1, l, r - 1);
    pre.pop_back();
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    while (T--) {
        scanf("%d", &n);
        a.assign(2 * n, 0);
        b.assign(n, 0);
        need.assign(n, 0);
        for (int i = 0; i < 2 * n; i++) scanf("%d", &a[i]);
        pre.clear(); ans.clear(); found = false;
        dfs(0, 0, 2 * n - 1);
        if (!found) puts("-1");
        else puts(ans.c_str());
    }
    return 0;
}
