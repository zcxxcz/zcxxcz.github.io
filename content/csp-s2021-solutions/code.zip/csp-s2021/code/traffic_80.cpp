// CSP-S 2021 T4 交通规划 —— 80 分档（测试点 1~16）
//   60 分档的 Dinic（测试点 1~12，n,m <= 100）
// + 对偶图最短路处理 k <= 2（测试点 3~5、9~10、13~16，其中 13~16 的 n,m 到 500）
// 提交时按 k 分派：
//   k <= 2  -> 对偶图 Dijkstra，O(nm log nm)，n,m = 500 也只要 0.3s；
//   k > 2   -> 回退 Dinic 最小割（只对 n,m <= 100 有效，也就是测试点 1~12 里的 k>2 那几个点）。
// k > 2 且 n,m 很大（测试点 17~20）这份代码直接输出 0 放弃 —— 那是 100 分档的活。
#include <bits/stdc++.h>
using namespace std;

const int MAXN = 505;
const long long INF = (long long)1e18;

int n, m, T;
int X1[MAXN][MAXN], X2[MAXN][MAXN];       // X1: 竖直边 (i,j)-(i+1,j)   X2: 水平边 (i,j)-(i,j+1)
int V0;                                    // 内部面的个数 (n-1)(m-1)

// ===================== 对偶图（k <= 2）=====================
const int MAXVD = MAXN * MAXN + 64;
struct E { int to, w; };
vector<E> g[MAXVD];
inline void addE(int u, int v, int w) { g[u].push_back({v, w}); g[v].push_back({u, w}); }
inline int fid(int i, int j) { return (i - 1) * (m - 1) + j; }

int posF[MAXN * 4], posW[MAXN * 4];       // 位置 p（射线 p 与 p+1 之间的边界）-> 内侧的面 / 边权
long long dist[MAXVD];

void dijkstra(int s, int V) {
    for (int i = 1; i <= V; i++) dist[i] = INF;
    priority_queue<pair<long long, int>, vector<pair<long long, int> >, greater<pair<long long, int> > > pq;
    dist[s] = 0; pq.push({0, s});
    while (!pq.empty()) {
        pair<long long, int> t = pq.top(); pq.pop();
        int u = t.second;
        if (dist[u] < t.first) continue;
        for (size_t i = 0; i < g[u].size(); i++) {
            int v = g[u][i].to, w = g[u][i].w;
            if (dist[u] + w < dist[v]) { dist[v] = dist[u] + w; pq.push({dist[v], v}); }
        }
    }
}

// ===================== Dinic（k > 2 且 n,m <= 100）=====================
const int MAXVF = 10010;
const int MAXEF = 200000;
int head[MAXVF], nxt[MAXEF], to[MAXEF], cap[MAXEF], ecnt;

inline void addEdge(int u, int v, int c) {
    to[ecnt] = v; cap[ecnt] = c; nxt[ecnt] = head[u]; head[u] = ecnt++;
    to[ecnt] = u; cap[ecnt] = 0; nxt[ecnt] = head[v]; head[v] = ecnt++;
}
inline void addUndir(int u, int v, int c) {          // 双向各 c
    to[ecnt] = v; cap[ecnt] = c; nxt[ecnt] = head[u]; head[u] = ecnt++;
    to[ecnt] = u; cap[ecnt] = c; nxt[ecnt] = head[v]; head[v] = ecnt++;
}

int rayNode(int p) {                                 // 射线编号(1-indexed) -> 格点(0-indexed)
    if (p <= m) return (p - 1);
    if (p <= m + n) return (p - m - 1) * m + (m - 1);
    if (p <= 2 * m + n) { int i = p - (m + n); return (n - 1) * m + (m - i); }
    int i = p - (2 * m + n); return (n - i) * m;
}

int level[MAXVF], iter_[MAXVF];
bool bfs(int s, int t, int V) {
    for (int i = 0; i < V; i++) level[i] = -1;
    queue<int> q; q.push(s); level[s] = 0;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int e = head[u]; e != -1; e = nxt[e])
            if (cap[e] > 0 && level[to[e]] < 0) { level[to[e]] = level[u] + 1; q.push(to[e]); }
    }
    return level[t] >= 0;
}
int dfsflow(int u, int t, int f) {
    if (u == t) return f;
    for (int &e = iter_[u]; e != -1; e = nxt[e]) {
        int v = to[e];
        if (cap[e] > 0 && level[v] == level[u] + 1) {
            int d = dfsflow(v, t, min(f, cap[e]));
            if (d > 0) { cap[e] -= d; cap[e ^ 1] += d; return d; }
        }
    }
    return 0;
}
long long dinic(int s, int t, int V) {
    long long flow = 0;
    while (bfs(s, t, V)) {
        for (int i = 0; i < V; i++) iter_[i] = head[i];
        int f;
        while ((f = dfsflow(s, t, INT_MAX)) > 0) flow += f;
    }
    return flow;
}

// 用最小割求一个询问（k 个附加点），ray/c 都是 1-indexed 的射线编号，w 是附加边权
long long solveByCut(const vector<int> &ray, const vector<int> &col, const vector<int> &w) {
    int k = (int)ray.size();
    int V = n * m + 2, S = n * m, TT = n * m + 1;
    ecnt = 0;
    for (int i = 0; i < V; i++) head[i] = -1;
    for (int i = 1; i <= n - 1; i++)
        for (int j = 1; j <= m; j++)
            addUndir((i - 1) * m + (j - 1), i * m + (j - 1), X1[i][j]);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m - 1; j++)
            addUndir((i - 1) * m + (j - 1), (i - 1) * m + j, X2[i][j]);
    for (int i = 0; i < k; i++) {
        int u = rayNode(ray[i]);
        if (col[i] == 1) addEdge(S, u, w[i]);     // 黑：源侧
        else addEdge(u, TT, w[i]);                // 白：汇侧
    }
    return dinic(S, TT, V);
}

int main() {
    if (scanf("%d %d %d", &n, &m, &T) != 3) return 0;
    for (int i = 1; i <= n - 1; i++) for (int j = 1; j <= m; j++) scanf("%d", &X1[i][j]);
    for (int i = 1; i <= n; i++) for (int j = 1; j <= m - 1; j++) scanf("%d", &X2[i][j]);

    // 建对偶图：内部面之间的边
    V0 = (n - 1) * (m - 1);
    for (int i = 1; i <= n - 1; i++)
        for (int j = 1; j <= m - 1; j++) {
            if (i + 1 <= n - 1) addE(fid(i, j), fid(i + 1, j), X2[i + 1][j]);
            if (j + 1 <= m - 1) addE(fid(i, j), fid(i, j + 1), X1[i][j + 1]);
        }

    // 边界位置 p  ->  内侧的面 / 边权
    int N = 2 * m + 2 * n;
    for (int p = 0; p < N; p++) { posF[p] = 0; posW[p] = 0; }
    for (int p = 0; p <= m - 2; p++) { posF[p] = fid(1, p + 1); posW[p] = X2[1][p + 1]; }
    for (int p = m; p <= m + n - 2; p++) { int i = p - m + 1; posF[p] = fid(i, m - 1); posW[p] = X1[i][m]; }
    for (int p = m + n; p <= 2 * m + n - 2; p++) { int c = 2 * m + n - p; posF[p] = fid(n - 1, c - 1); posW[p] = X2[n][c - 1]; }
    for (int p = 2 * m + n; p <= 2 * m + 2 * n - 2; p++) { int r = 2 * m + 2 * n - p; posF[p] = fid(r - 1, 1); posW[p] = X1[r - 1][1]; }

    vector<int> touched;
    while (T--) {
        // 清掉上一轮挂在内部面上的动态边
        for (size_t i = 0; i < touched.size(); i++) {
            int f = touched[i];
            size_t wq = 0;
            for (size_t j = 0; j < g[f].size(); j++)
                if (g[f][j].to <= V0) g[f][wq++] = g[f][j];
            g[f].resize(wq);
        }
        touched.clear();
        g[V0 + 1].clear(); g[V0 + 2].clear();

        int k; scanf("%d", &k);
        vector<int> P(k), C(k), W(k);
        for (int i = 0; i < k; i++) { scanf("%d %d %d", &W[i], &P[i], &C[i]); P[i]--; }

        if (k <= 2) {
            if (k == 1) { puts("0"); continue; }
            if (P[0] > P[1]) { swap(P[0], P[1]); swap(C[0], C[1]); swap(W[0], W[1]); }
            if (C[0] == C[1]) { puts("0"); continue; }       // 同色：全染同色，代价 0
            int V = V0 + 2;
            int a = P[0], b = P[1];
            int t = a;
            while (t != b) { if (posF[t]) { addE(V0 + 1, posF[t], posW[t]); touched.push_back(posF[t]); } t = (t + 1) % N; }
            t = b;
            while (t != a) { if (posF[t]) { addE(V0 + 2, posF[t], posW[t]); touched.push_back(posF[t]); } t = (t + 1) % N; }
            addE(V0 + 1, V0 + 2, W[1]);      // 经过射线 P[1] 上的附加点
            addE(V0 + 1, V0 + 2, W[0]);      // 经过射线 P[0] 上的附加点
            dijkstra(V0 + 1, V);
            printf("%lld\n", dist[V0 + 2]);
        } else {
            if ((long long)n * m > 10000) { puts("0"); continue; }   // 网格太大，Dinic 撑不住
            vector<int> ray(k), col(k), w(k);
            for (int i = 0; i < k; i++) { ray[i] = P[i] + 1; col[i] = C[i]; w[i] = W[i]; }
            printf("%lld\n", solveByCut(ray, col, w));
        }
    }
    return 0;
}
