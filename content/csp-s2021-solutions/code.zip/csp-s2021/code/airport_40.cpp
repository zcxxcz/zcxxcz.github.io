// CSP-S 2021 T1 廊桥分配 —— 40 分档（n,m1+m2 <= 5000）
// 做法：仍然枚举 x，但单次模拟从 O(m*n) 降到 O(m log m)：
//   用一个小根堆存"正在占用廊桥的飞机离开时刻"，离开时刻 < 当前抵达时刻的弹出，
//   堆里剩下的个数就是"被占用的廊桥数"，它小于 k 就说明还有空桥。
// 复杂度 O(n * m log m)。
#include <bits/stdc++.h>
using namespace std;

int n, m1, m2;
struct Fl { int a, b; };
vector<Fl> u, v;

bool cmpA(const Fl &x, const Fl &y) { return x.a < y.a; }

int calc(const vector<Fl> &t, int k) {
    if (k == 0) return 0;
    priority_queue<int, vector<int>, greater<int> > q;   // 占用中的离开时刻
    int c = 0;
    for (const auto &f : t) {
        while (!q.empty() && q.top() < f.a) q.pop();     // 已经飞走的释放
        if ((int)q.size() < k) { q.push(f.b); c++; }     // 还有空桥
    }
    return c;
}

int main() {
    if (scanf("%d %d %d", &n, &m1, &m2) != 3) return 0;
    u.resize(m1); v.resize(m2);
    for (auto &x : u) scanf("%d %d", &x.a, &x.b);
    for (auto &x : v) scanf("%d %d", &x.a, &x.b);
    sort(u.begin(), u.end(), cmpA);
    sort(v.begin(), v.end(), cmpA);

    int ans = 0;
    for (int x = 0; x <= n; x++) {
        int cur = calc(u, x) + calc(v, n - x);
        if (cur > ans) ans = cur;
    }
    printf("%d\n", ans);
    return 0;
}
