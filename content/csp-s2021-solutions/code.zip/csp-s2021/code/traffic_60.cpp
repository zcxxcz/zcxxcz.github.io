// CSP-S 2021 T4 交通规划 —— 60 分档（测试点 1~12，n,m <= 100）
// 和 40 分档是同一份 Dinic 最小割，唯一的区别是把点/边数组开大：
//   MAXV 400 -> 10010，MAXE 8000 -> 200000，格点权值表 32x32 -> 505x505。
// 为什么值得单独写一段：我第一版就是因为数组只开了 32x32、MAXV 只有 400，
//   一到 n,m = 100（10002 个点）就下标越界直接 RE，看上去像"Dinic 在网格图上跑不动"，
//   其实是自己的锅。放大数组后实测 n,m = 100、k = 50：单次询问 0.02s。
// n,m <= 100 时结点数 <= 10002、边数 <= 4e4，Dinic 完全够用；
//   n,m = 500 时结点 2.5e5，才会真的跑不动（那要靠对偶图，见 80/100 分档）。
#include <bits/stdc++.h>
using namespace std;

const int MAXV = 10010;
const int MAXE = 200000;
int n, m, T;
int X1[505][505], X2[505][505];
int rayNode(int p) {                       // 射线 -> 格点（0-indexed）
    if (p <= m) return (p - 1);
    if (p <= m + n) return (p - m - 1) * m + (m - 1);
    if (p <= 2 * m + n) { int i = p - (m + n); return (n - 1) * m + (m - i); }
    int i = p - (2 * m + n); return (n - i) * m;
}

int head[MAXV], nxt[MAXE], to[MAXE], cap[MAXE], ecnt;
inline void addEdge(int u, int v, int c) {
    to[ecnt] = v; cap[ecnt] = c; nxt[ecnt] = head[u]; head[u] = ecnt++;
    to[ecnt] = u; cap[ecnt] = 0; nxt[ecnt] = head[v]; head[v] = ecnt++;
}
inline void addUndir(int u, int v, int c) {   // 双向各 c
    to[ecnt] = v; cap[ecnt] = c; nxt[ecnt] = head[u]; head[u] = ecnt++;
    to[ecnt] = u; cap[ecnt] = c; nxt[ecnt] = head[v]; head[v] = ecnt++;
}

int level[MAXV], iter[MAXV];
bool bfs(int s, int t, int V) {
    for (int i = 0; i < V; i++) level[i] = -1;
    queue<int> q; q.push(s); level[s] = 0;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int e = head[u]; e != -1; e = nxt[e])
            if (cap[e] > 0 && level[to[e]] < 0) { level[to[e]] = level[u] + 1; q.push(to[e]); }
    }
    return level[t] >= 0;
}
int dfs(int u, int t, int f) {
    if (u == t) return f;
    for (int &e = iter[u]; e != -1; e = nxt[e]) {
        int v = to[e];
        if (cap[e] > 0 && level[v] == level[u] + 1) {
            int d = dfs(v, t, min(f, cap[e]));
            if (d > 0) { cap[e] -= d; cap[e ^ 1] += d; return d; }
        }
    }
    return 0;
}
long long dinic(int s, int t, int V) {
    long long flow = 0;
    while (bfs(s, t, V)) {
        for (int i = 0; i < V; i++) iter[i] = head[i];
        int f;
        while ((f = dfs(s, t, INT_MAX)) > 0) flow += f;
    }
    return flow;
}

int main() {
    if (scanf("%d %d %d", &n, &m, &T) != 3) return 0;
    for (int i = 1; i <= n - 1; i++) for (int j = 1; j <= m; j++) scanf("%d", &X1[i][j]);
    for (int i = 1; i <= n; i++) for (int j = 1; j <= m - 1; j++) scanf("%d", &X2[i][j]);

    while (T--) {
        int k; scanf("%d", &k);
        int V = n * m + 2, S = n * m, TT = n * m + 1;
        ecnt = 0;
        for (int i = 0; i < V; i++) head[i] = -1;
        for (int i = 1; i <= n - 1; i++) for (int j = 1; j <= m; j++)
            addUndir((i - 1) * m + (j - 1), i * m + (j - 1), X1[i][j]);
        for (int i = 1; i <= n; i++) for (int j = 1; j <= m - 1; j++)
            addUndir((i - 1) * m + (j - 1), (i - 1) * m + j, X2[i][j]);
        for (int i = 0; i < k; i++) {
            int x3, p, c; scanf("%d %d %d", &x3, &p, &c);
            int u = rayNode(p);
            if (c == 1) addEdge(S, u, x3);     // 黑：源侧
            else addEdge(u, TT, x3);           // 白：汇侧
        }
        printf("%lld\n", dinic(S, TT, V));
    }
    return 0;
}
