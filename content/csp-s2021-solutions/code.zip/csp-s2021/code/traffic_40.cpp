// CSP-S 2021 T4 交通规划 —— 40 分档（测试点 1~8，n,m <= 18）
// 直接建最小割模型：
//   把每个格点当结点，源 S 代表"黑"，汇 T 代表"白"。
//   对每条网格边 (u,v,w) 加两条有向边 u->v、v->u 容量 w；
//   黑附加点：S -> u 容量 w（u 若被染白，这条边就被割）
//   白附加点：u -> T 容量 w（u 若被染黑，这条边就被割）
//   答案就是 S-T 最小割 = 最大流。
// n,m <= 18 时结点数 <= 324，单次 Dinic 足够快。
#include <bits/stdc++.h>
using namespace std;

const int MAXV = 400;
const int MAXE = 8000;
int n, m, T;
int X1[32][32], X2[32][32];
int rayNode(int p) {                       // 射线 -> 格点（0-indexed）
    if (p <= m) return (p - 1);
    if (p <= m + n) return (p - m - 1) * m + (m - 1);
    if (p <= 2 * m + n) { int i = p - (m + n); return (n - 1) * m + (m - i); }
    int i = p - (2 * m + n); return (n - i) * m;
}

int head[MAXV], nxt[MAXE], to[MAXE], cap[MAXE], ecnt;
inline void addEdge(int u, int v, int c) {
    to[ecnt] = v; cap[ecnt] = c; nxt[ecnt] = head[u]; head[u] = ecnt++;
    to[ecnt] = u; cap[ecnt] = 0; nxt[ecnt] = head[v]; head[v] = ecnt++;
}
inline void addUndir(int u, int v, int c) {   // 双向各 c
    to[ecnt] = v; cap[ecnt] = c; nxt[ecnt] = head[u]; head[u] = ecnt++;
    to[ecnt] = u; cap[ecnt] = c; nxt[ecnt] = head[v]; head[v] = ecnt++;
}

int level[MAXV], iter[MAXV];
bool bfs(int s, int t, int V) {
    for (int i = 0; i < V; i++) level[i] = -1;
    queue<int> q; q.push(s); level[s] = 0;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int e = head[u]; e != -1; e = nxt[e])
            if (cap[e] > 0 && level[to[e]] < 0) { level[to[e]] = level[u] + 1; q.push(to[e]); }
    }
    return level[t] >= 0;
}
int dfs(int u, int t, int f) {
    if (u == t) return f;
    for (int &e = iter[u]; e != -1; e = nxt[e]) {
        int v = to[e];
        if (cap[e] > 0 && level[v] == level[u] + 1) {
            int d = dfs(v, t, min(f, cap[e]));
            if (d > 0) { cap[e] -= d; cap[e ^ 1] += d; return d; }
        }
    }
    return 0;
}
long long dinic(int s, int t, int V) {
    long long flow = 0;
    while (bfs(s, t, V)) {
        for (int i = 0; i < V; i++) iter[i] = head[i];
        int f;
        while ((f = dfs(s, t, INT_MAX)) > 0) flow += f;
    }
    return flow;
}

int main() {
    if (scanf("%d %d %d", &n, &m, &T) != 3) return 0;
    for (int i = 1; i <= n - 1; i++) for (int j = 1; j <= m; j++) scanf("%d", &X1[i][j]);
    for (int i = 1; i <= n; i++) for (int j = 1; j <= m - 1; j++) scanf("%d", &X2[i][j]);

    while (T--) {
        int k; scanf("%d", &k);
        int V = n * m + 2, S = n * m, TT = n * m + 1;
        ecnt = 0;
        for (int i = 0; i < V; i++) head[i] = -1;
        for (int i = 1; i <= n - 1; i++) for (int j = 1; j <= m; j++)
            addUndir((i - 1) * m + (j - 1), i * m + (j - 1), X1[i][j]);
        for (int i = 1; i <= n; i++) for (int j = 1; j <= m - 1; j++)
            addUndir((i - 1) * m + (j - 1), (i - 1) * m + j, X2[i][j]);
        for (int i = 0; i < k; i++) {
            int x3, p, c; scanf("%d %d %d", &x3, &p, &c);
            int u = rayNode(p);
            if (c == 1) addEdge(S, u, x3);     // 黑：源侧
            else addEdge(u, TT, x3);           // 白：汇侧
        }
        printf("%lld\n", dinic(S, TT, V));
    }
    return 0;
}
