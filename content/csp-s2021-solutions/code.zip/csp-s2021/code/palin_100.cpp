// CSP-S 2021 T3 回文 —— 100 分（n <= 5e5, sum n <= 5e5）
// 观察：第一个取的数 v 一定是 a[1] 或 a[2n]；它的另一次出现位置 pos 必然是最后一个取的数。
// 于是 v 的两次出现把整个序列切成左右两段 L = [l1,r1]、R = [l2,r2]。
// 之后每一步同时确定"第 i 次"和"第 2n+1-i 次"两个操作：
//   第 i 次只能在 L 的左端或 R 的右端取；第 2n+1-i 次只能在 L 的右端或 R 的左端取；
//   两者数值必须相同。四种组合按字典序（先比第 i 位，再比第 2n+1-i 位）依次尝试：
//     (L左, L右) -> "LL"    (L左, R左) -> "LR"    (R右, L右) -> "RL"    (R右, R左) -> "RR"
// 取 L 段任何元素都是"从左边剥"记 'L'，取 R 段任何元素都是"从右边剥"记 'R'。
// 两个起点各跑一遍，取字典序小的答案。复杂度 O(n)。
#include <bits/stdc++.h>
using namespace std;

const int MAXN = 500005;
int n, a[2 * MAXN];
int other_pos[2 * MAXN];
char ans[2 * MAXN + 1];

bool build(int l1, int r1, int l2, int r2, char first) {
    ans[0] = first;
    ans[2 * n - 1] = 'L';
    for (int i = 1; i < n; i++) {
        int j = 2 * n - 1 - i;
        if (l1 < r1 && a[l1] == a[r1]) {                      // (L左端, L右端) -> L L
            ans[i] = 'L'; ans[j] = 'L'; l1++; r1--;
        } else if (l1 <= r1 && l2 <= r2 && a[l1] == a[l2]) {   // (L左端, R左端) -> L R
            ans[i] = 'L'; ans[j] = 'R'; l1++; l2++;
        } else if (l1 <= r1 && l2 <= r2 && a[r2] == a[r1]) {   // (R右端, L右端) -> R L
            ans[i] = 'R'; ans[j] = 'L'; r2--; r1--;
        } else if (l2 < r2 && a[r2] == a[l2]) {                // (R右端, R左端) -> R R
            ans[i] = 'R'; ans[j] = 'R'; r2--; l2++;
        } else return false;
    }
    ans[2 * n] = 0;
    return true;
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    while (T--) {
        scanf("%d", &n);
        for (int i = 0; i < 2 * n; i++) scanf("%d", &a[i]);
        for (int i = 0; i < 2 * n; i++) other_pos[i] = -1;
        static int firstpos[MAXN];
        for (int v = 1; v <= n; v++) firstpos[v] = -1;
        for (int i = 0; i < 2 * n; i++) {
            if (firstpos[a[i]] == -1) firstpos[a[i]] = i;
            else { other_pos[firstpos[a[i]]] = i; other_pos[i] = firstpos[a[i]]; }
        }
        static char buf1[2 * MAXN + 1], buf2[2 * MAXN + 1];
        bool ok1 = false, ok2 = false;
        {
            int pos = other_pos[0];
            if (pos > 0 && build(1, pos - 1, pos + 1, 2 * n - 1, 'L')) { ok1 = true; memcpy(buf1, ans, 2 * n + 1); }
        }
        {
            int pos = other_pos[2 * n - 1];
            if (pos < 2 * n - 1 && build(0, pos - 1, pos + 1, 2 * n - 2, 'R')) { ok2 = true; memcpy(buf2, ans, 2 * n + 1); }
        }
        if (!ok1 && !ok2) puts("-1");
        else if (ok1 && ok2) puts(strcmp(buf1, buf2) <= 0 ? buf1 : buf2);
        else puts(ok1 ? buf1 : buf2);
    }
    return 0;
}
