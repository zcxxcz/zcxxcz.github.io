// CSP-S 2021 T3 回文 —— 28 分档（测试点 1~7，n <= 10）
// 直接枚举全部 2^(2n-1) 种操作串，模拟出 b 并检查是否回文，取字典序最小者。
// n <= 10 时 2^19 = 5e5，配 T <= 10 也能跑。
#include <bits/stdc++.h>
using namespace std;

int n, a[64];
string best;
bool has;

void check(const string &ops) {
    int l = 0, r = 2 * n - 1;
    static int b[64];
    for (int i = 0; i < 2 * n; i++) b[i] = (ops[i] == 'L') ? a[l++] : a[r--];
    for (int i = 0; i < n; i++) if (b[i] != b[2 * n - 1 - i]) return;
    if (!has || ops < best) { best = ops; has = true; }
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    while (T--) {
        scanf("%d", &n);
        for (int i = 0; i < 2 * n; i++) scanf("%d", &a[i]);
        has = false; best.clear();
        string ops(2 * n, 'L');
        for (long long m = 0; m < (1LL << (2 * n)); m++) {
            for (int i = 0; i < 2 * n; i++) ops[i] = (m >> i & 1) ? 'R' : 'L';
            check(ops);
        }
        if (!has) puts("-1");
        else puts(best.c_str());
    }
    return 0;
}
