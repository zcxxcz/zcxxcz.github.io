// CSP-S 2021 T1 廊桥分配 —— 100 分（n, m1+m2 <= 1e5）
// 核心：把"n 个廊桥怎么分"变成"第 k 个廊桥服务了几架飞机"。
//   先假装廊桥无限多，给每架飞机分配一个编号，编号 = 它用的是"第几个"廊桥。
//   记 cnt[k] 为编号 k 的廊桥服务的飞机数，则"恰好给 k 个廊桥"时能停的架数
//   f[k] = cnt[1] + cnt[2] + ... + cnt[k]（前缀和）。
// 答案 = max_{x=0..n} f1[x] + f2[n-x]。
// 复杂度 O((m1+m2) log(m1+m2))。
#include <bits/stdc++.h>
using namespace std;

int n, m1, m2;
struct Fl { int a, b; };
vector<Fl> u, v;

bool cmpA(const Fl &x, const Fl &y) { return x.a < y.a; }

// 返回 s，s[k] = "给 k 个廊桥时能停靠的飞机数"，k = 0 .. 最大用到的编号
vector<long long> solve(const vector<Fl> &t) {
    // occ: (离开时刻, 廊桥编号)，按离开时刻小根堆；idle: 空闲廊桥编号小根堆
    priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > occ;
    priority_queue<int, vector<int>, greater<int> > idle;
    vector<long long> cnt(1, 0);        // cnt[k]，1-indexed，cnt[0] 占位
    int mx = 0;
    for (const auto &f : t) {
        while (!occ.empty() && occ.top().first < f.a) {
            idle.push(occ.top().second); // 飞机飞走，廊桥回收
            occ.pop();
        }
        int id;
        if (!idle.empty()) { id = idle.top(); idle.pop(); }
        else { id = ++mx; cnt.push_back(0); }   // 没有空桥 -> 虚拟开一个新编号
        cnt[id]++;
        occ.push(make_pair(f.b, id));
    }
    for (size_t i = 1; i < cnt.size(); i++) cnt[i] += cnt[i - 1];
    return cnt;                          // cnt[k] = f(k)
}

int main() {
    if (scanf("%d %d %d", &n, &m1, &m2) != 3) return 0;
    u.resize(m1); v.resize(m2);
    for (auto &x : u) scanf("%d %d", &x.a, &x.b);
    for (auto &x : v) scanf("%d %d", &x.a, &x.b);
    sort(u.begin(), u.end(), cmpA);
    sort(v.begin(), v.end(), cmpA);

    vector<long long> f1 = solve(u), f2 = solve(v);
    // 取第 k 个值；k 超过数组范围说明廊桥多到能把所有飞机都停下，饱和
    auto get = [](const vector<long long> &s, int k) -> long long {
        if (k >= (int)s.size()) return s.back();
        return s[k];
    };

    long long ans = 0;
    for (int x = 0; x <= n; x++) {
        long long cur = get(f1, x) + get(f2, n - x);
        if (cur > ans) ans = cur;
    }
    printf("%lld\n", ans);
    return 0;
}
