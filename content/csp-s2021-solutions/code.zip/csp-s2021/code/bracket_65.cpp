// CSP-S 2021 T2 括号序列 —— 65 分档（测试点 1~13，n <= 100）
// 状态定义与正解完全相同，只是 E 的转移写成"第一块 [i,a] + 中间星串 [a+1,b] + 剩余 [b+1,j]"的三层枚举，
// 复杂度 O(n^4)。n <= 100 时约 4e6 次，n = 500 时约 2.6e9 次，会超时。
#include <bits/stdc++.h>
using namespace std;

const int MOD = 1000000007;
int n, K;
char s[505];
long long E[505][505], L[505][505];
bool Sg[505][505];

inline bool cOpen(char c) { return c == '(' || c == '?'; }
inline bool cClose(char c) { return c == ')' || c == '?'; }
inline bool cStar(char c) { return c == '*' || c == '?'; }

int main() {
    if (scanf("%d %d %s", &n, &K, s + 1) != 3) return 0;

    for (int i = 1; i <= n; i++) {
        bool all = true;
        for (int j = i; j <= n; j++) {
            if (!cStar(s[j])) all = false;
            Sg[i][j] = all && (j - i + 1 <= K);
        }
    }

    for (int len = 1; len <= n; len++) {
        for (int i = 1; i + len - 1 <= n; i++) {
            int j = i + len - 1;

            // ---- L[i][j]：一对括号恰好包住 [i,j] ----
            long long l = 0;
            if (len >= 2 && cOpen(s[i]) && cClose(s[j])) {
                int a = i + 1, b = j - 1;
                if (len == 2) l = 1;
                else {
                    l += Sg[a][b];
                    l += E[a][b];
                    for (int m = a; m < b; m++) {
                        l += Sg[a][m] * E[m + 1][b] % MOD;
                        l += E[a][m] * Sg[m + 1][b] % MOD;
                    }
                }
                l %= MOD;
            }
            L[i][j] = l;

            // ---- E[i][j]：三元枚举（块 / 星串 / 剩余）----
            long long e = L[i][j];
            for (int a = i; a < j; a++) {
                if (!L[i][a]) continue;
                for (int b = a; b < j; b++) {
                    long long mid;
                    if (b == a) mid = 1;
                    else mid = Sg[a + 1][b] ? 1 : 0;
                    if (!mid) continue;
                    if (!E[b + 1][j]) continue;
                    e += L[i][a] * mid % MOD * E[b + 1][j] % MOD;
                }
            }
            E[i][j] = e % MOD;
        }
    }
    printf("%lld\n", E[1][n] % MOD);
    return 0;
}
